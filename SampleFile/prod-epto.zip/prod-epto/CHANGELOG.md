# Change Log

Latest Version - `1.4.0`

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).

## [1.4.0] - 2023-10-10

### Changed

- Added more options for sagemaker preprocessing

## [1.3.0] - 2023-10-10

### Added

- Added new analytics etl role

## [1.2.0] - 2023-10-10

### Added

- Added new tf variable to ETL glue template for prefix

## [1.1.0] - 2023-10-09

Sonarqube updates

### Added

- Added `sonar-project.properties`.

### Changed

- Removed version.md. Changelog will contain latest version.

## [1.0.0] - 2023-10-06

Here we would have the update steps for 1.0.0 for people to follow.

### Fixed

- [TFSEC Updates](https://github.com/MSIL-Analytics-ACE/template-bu-use-case-dapm-framework/pull/1)
  PATCH secure terraform code as per tfsec report

---

## [Example] - yyyy-mm-dd

Here we write upgrading notes for brands. It's a team effort to make them as
straightforward as possible.

### Added

- [PROJECTNAME-XXXX](http://tickets.projectname.com/browse/PROJECTNAME-XXXX)
  MINOR Ticket title goes here.
- [PROJECTNAME-YYYY](http://tickets.projectname.com/browse/PROJECTNAME-YYYY)
  PATCH Ticket title goes here.

### Changed

- [PROJECTNAME-XXXX](http://tickets.projectname.com/browse/PROJECTNAME-XXXX)
  MINOR Ticket title goes here.
- [PROJECTNAME-YYYY](http://tickets.projectname.com/browse/PROJECTNAME-YYYY)
  PATCH Ticket title goes here.

### Fixed

- [PROJECTNAME-XXXX](http://tickets.projectname.com/browse/PROJECTNAME-XXXX)
  MINOR Ticket title goes here.
- [PROJECTNAME-YYYY](http://tickets.projectname.com/browse/PROJECTNAME-YYYY)
  PATCH Ticket title goes here.
