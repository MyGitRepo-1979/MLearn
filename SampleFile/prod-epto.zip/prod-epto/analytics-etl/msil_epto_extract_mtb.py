from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
import awswrangler as wr
import sys
import boto3
import pandas as pd
import io
import pyarrow as pa
import pyarrow.parquet as pq
from io import BytesIO
from datetime import datetime, timedelta
import pytz

from ddls import MTB_ATHENA_TABLE
from ddls import MTB_ATHENA_TABLE_LOCATION

## @params: [JOB_NAME]
args = getResolvedOptions(sys.argv, ["JOB_NAME", "config_bucket", "config_key","account_id"])
s3_bucket = args["config_bucket"]
config_key = args["config_key"]
catalog_name = "AwsDataCatalog"
base_table_name = args["config_bucket"]
account_id = args["account_id"]

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

# Import the python scripts from common_resource.zip folder which contains common functions and SQL queries.
from common_execute_functions import CommonExecuteFunctions
cef = CommonExecuteFunctions()

# Read yaml config from S3
params = cef.json_read_from_s3(s3_bucket, config_key)
date_lag = params['date_lag']
topic_name = params['topic_name']
topic_arn = f"arn:aws:sns:ap-south-1:{account_id}:{topic_name}"
log_group_name = params['log_group_name']
db_name = params['db_name']
table_name = params['table_name']
start_date = params['start_date']
end_date = params['end_date']
source_bucket_name = params['source_bucket_name']

start_date = eval(start_date)
end_date = eval(end_date)

if params['start_date'] == '9999':
    start_date= datetime.now() - timedelta(days=date_lag)
    
if params['end_date'] == '9999':
    end_date = datetime.now() - timedelta(days=1)

# # Date range if you want to run for definite period (do not put leading zeros while setting the date)
# start_date = datetime(2023, 12, 12)  # Set the start date
# end_date = datetime(2023, 12, 26)   # Set the end date

# start_date= datetime.now() - timedelta(days=7)
# # Current date for regular run with a lag of one day as file is processed for previous day
# current_date = datetime.now() - timedelta(days=1)
# end_date= current_date
out_bucket_name = s3_bucket

delimiter=','
required_cols = ['Engine No', 'Bench No','Engine Code','Engine Spec', 'Serial No', 'Result' ,'Operator', 'M1_Trq', 'M1_Trq.1', 'M2_Cyl1', 'M2_Cyl2', 'M2_Cyl3', 'M2_Cyl4', 'M2_OilPrs', 'M2_Crank', 'M2_IN-Cam', 'M2_EX-Cam', 'M3_OilPrs', 'M4_OilPrs']

mtb_column_mapping = {'Engine No': 'engine_no', 'Bench No': 'bench_no', 'Engine Code': 'engine_code', 'Engine Spec': 'engine_spec', \
                'Serial No': 'serial_no', 'Result': 'result', 'Operator': 'operator', 'M1_Trq': 'm1_trq', 'M1_Trq.1': 'm1_trq_1', \
                'M2_Cyl1': 'm2_cyl1', 'M2_Cyl2': 'm2_cyl2', 'M2_Cyl3': 'm2_cyl3', 'M2_Cyl4': 'm2_cyl4', 'M2_OilPrs': 'm2_oilprs', \
                'M2_Crank': 'm2_crank', 'M2_IN-Cam': 'm2_in_cam','M2_EX-Cam': 'm2_ex_cam', 'M3_OilPrs': 'm3_oilprs','M4_OilPrs': 'm4_oilprs'}

mtb_no_list = ['01','02','03','04']


#Log group & stream 

# Specify the time zone (IST)
ist = pytz.timezone('Asia/Kolkata')
# Get the current time in IST
date_today = datetime.now(ist).strftime("%Y%m%d%H%M")

cef.create_log_group(log_group_name)

log_stream_name = f'msil_mtb_data_{date_today}'
print(f"log_stream_name for current job run: {log_stream_name}")

#initialize logger
logger = cef.init_cloudwatch_logger(log_group_name, log_stream_name)

# Create an S3 client
s3_client = boto3.client('s3')

# =================== To Create Database =============================
def create_glue_database(database_name, catalog_name):
    # Initialize Glue client
    glue_client = boto3.client('glue')

    # Create a new database
    create_database_response = glue_client.create_database(
        DatabaseInput={
            'Name': database_name,
            'Description': 'Project Database'
        }
    )

    # Check if database creation was successful
    if create_database_response['ResponseMetadata']['HTTPStatusCode'] == 200:
        print(f"Database '{database_name}' created successfully.")
    else:
        print(f"Error creating database: {create_database_response}")

try:
    create_glue_database(db_name, catalog_name)
except:
    pass

####### Create Athena Tables #####

def create_athena_table(database, bucket_name, table_query, location):

    # Create Athena client
    athena_client = boto3.client('athena')

    # Submit the query to Athena
    response = athena_client.start_query_execution(
        QueryString=table_query,
        QueryExecutionContext={'Database': database},
        ResultConfiguration={'OutputLocation': location}
    )
    # Print the query execution ID
    print(f"Query Execution ID: {response['QueryExecutionId']}")

create_athena_table(db_name, s3_bucket, eval(f'f"{MTB_ATHENA_TABLE}"'),
                    eval(MTB_ATHENA_TABLE_LOCATION))

def delete_txt_files(bucket_name, folder_path):
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(bucket_name)
    # List all objects in the specified folder path
    for obj in bucket.objects.filter(Prefix=folder_path):
        # Check if the object ends with ".csv" and delete it
        if obj.key.endswith('.txt'):
            print(f"Deleting extra text files {obj.key}")
            obj.delete()
    
def list_s3_objects(bucket_name, prefix):
    # Create an S3 client
    s3_client = boto3.client('s3')

    # List objects in the bucket
    response = s3_client.list_objects_v2(
        Bucket=bucket_name,
        Prefix=prefix
    )

    # Check for the 'Contents' key in the response
    if 'Contents' in response:
        objects = response['Contents']
        for obj in objects:
            print(f"Object: {obj['Key']} ({obj['Size']} bytes)")
    else:
        print("No objects found in the specified bucket and prefix.")
        
def read_csv_file(bucket_name,object_key,delimiter=','):

    # Initialize the S3 client
    s3 = boto3.client('s3')
    
    # Retrieve the CSV file from S3
    response = s3.get_object(Bucket=bucket_name, Key=object_key)
    
    # Create a DataFrame from the CSV content
    df = pd.read_csv(response["Body"], sep=delimiter,encoding='ISO-8859-1', dtype=str)
    
    return df

def read_csv_spark (bucket_name, object_key):
    df = spark.read.csv(f"s3://{bucket_name}/{object_key}", header=True, inferSchema=True)
    df.show()
    
def write_pandas_df_parquet(df, bucket_name, s3_folder_path):
    wr.s3.to_parquet(
        df=df,
        path=f"s3://{bucket_name}/{s3_folder_path}"
    )

def generate_date_list(start_date, end_date):
    
    date_list = []
    current_date = start_date
    while current_date <= end_date:
        date_list.append(current_date.strftime('%Y%m%d'))
        current_date += timedelta(days=1)
    print(f"Executing for given date_list: {date_list}")
    
    return date_list
    
def execute_mtb_func(s3_client, mtb_no, date):
    
    partition_year= date[:4]
    partition_month= date[4:6]
    
    source_path = f"my_drive/data/engine_testing_performance/01_MTB{mtb_no}/{date}/01_MTB{mtb_no}-{date}.csv"
    out_path = f"extracted_data/mtb_full_data/01_MTB{mtb_no}/{date}/01_MTB{mtb_no}-{date}.parquet"
    out_path_mtb = f"extracted_data/mtb_athena_table_data_v1/mtbfile=01_MTB{mtb_no}/partition_year={partition_year}/partition_month={partition_month}/partition_date={date}/01_MTB{mtb_no}-{date}.parquet"  
    
    print(f"source_path:{source_path}")
    print(f"out_path:{out_path}")
    print(f"out_path_mtb:{out_path_mtb}")
    
    response = s3_client.list_objects_v2(
                Bucket=source_bucket_name,
                Prefix=source_path
            )

    if 'Contents' in response:
        #read data from s3
        df = read_csv_file(source_bucket_name, source_path, delimiter)
        df_mtb = df[required_cols]
        df_mtb.rename(columns=mtb_column_mapping, inplace=True)
        
        #write df to s3
        write_pandas_df_parquet(df, out_bucket_name, out_path)
        write_pandas_df_parquet(df_mtb, out_bucket_name, out_path_mtb)
            
    return True
    
def refresh_athena_table():
    sql_query = f"MSCK REPAIR TABLE {db_name}.{table_name}"
    
    wr.athena.read_sql_query(
        sql=sql_query,
        boto3_session=boto3.session.Session(),
        database=db_name,
        ctas_approach=False,
        )
    
def create_sns_topic(topic_name):
    # Initialize the SNS client
    sns_client = boto3.client('sns')
    
    try:
        # Create the SNS topic
        response = sns_client.create_topic(Name=topic_name)
        topic_arn = response['TopicArn']
        print(f"SNS Topic '{topic_name}' created with ARN: {topic_arn}")
    except:
        pass
    
def send_sns_notification(topic_arn, message, subject):
    # Initialize the SNS client
    sns_client = boto3.client('sns')
        
    # Publish the message to the specified SNS topic with a subject
    response = sns_client.publish(TopicArn=topic_arn, Message=message, Subject=subject)

    # Print the MessageId of the published message
    message_id = response['MessageId']
    print(f"Message published successfully with MessageId: {message_id}")


if __name__ == "__main__":
    # main function starts
    logger.info(f"Main Function starting")
    
    create_sns_topic(topic_name)
    
    # get date list
    date_list = generate_date_list(start_date, end_date)
    
    # Function for copy mtb data
    for mtb_no in mtb_no_list:
        for date in date_list:
            execute_mtb_func(s3_client, mtb_no, date)
            logger.info(f"Successfull execution for MTB_no {mtb_no} and date {date}")
            
    # Refresh Athena Table
    refresh_athena_table()

    #delete s3 txt files
    mtb_path = "extracted_data/mtb_athena_table_data_v1/"
    delete_txt_files(s3_bucket, mtb_path)

    # send send_sns_notification
    message = f'MTB job is Successfull. Data is updated from {start_date} to {end_date}'
    subject = f'MTB job completed on {date_today}'
    send_sns_notification(topic_arn, message, subject)
    