import sys
import pytz
import boto3
from datetime import datetime
from dateutil.relativedelta import relativedelta
from awsglue.utils import getResolvedOptions

from ddls import ASSEMBLY_CRANK_TABLE
from ddls import ASSEMBLY_CRANK_TABLE_LOCATION
from ddls import MACHINING_CYLINDER_HEAD_CAM_BORE_TABLE
from ddls import MACHINING_CYLINDER_HEAD_CAM_BORE_TABLE_LOCATION
from ddls import MACHINING_CYLINDER_BLOCK_BORE_TABLE
from ddls import MACHINING_CYLINDER_BLOCK_BORE_TABLE_LOCATION
from ddls import MACHINING_CAM_SHAFT_ROTOR_TABLE
from ddls import MACHINING_CAM_SHAFT_ROTOR_TABLE_LOCATION
from ddls import MACHINING_CYLINDER_BORE_JR_TABLE
from ddls import MACHINING_CYLINDER_BORE_JR_TABLE_LOCATION
from ddls import MACHINING_CRANK_SHAFT_MEASUREMENT_TABLE
from ddls import MACHINING_CRANK_SHAFT_MEASUREMENT_TABLE_LOCATION
from ddls import MACHINING_CAM_SHAFT_MEASUREMENT_TABLE
from ddls import MACHINING_CAM_SHAFT_MEASUREMENT_TABLE_LOCATION
from ddls import MACHINING_CYLINDER_BORE_JR_MAPPING_TABLE
from ddls import MACHINING_CYLINDER_BORE_JR_MAPPING_TABLE_LOCATION

# Get config_bucket and config_key from argument.
args = getResolvedOptions(sys.argv, ["config_bucket", "config_key", "account_id"])
s3_bucket = args["config_bucket"]
config_key = args["config_key"]
catalog_name = "AwsDataCatalog"
base_table_name = args["config_bucket"]
account_id = args["account_id"]

# Import the python scripts from common_resource.zip folder which contains common functions and SQL queries.
from common_execute_functions import CommonExecuteFunctions
from glue_sql_query_functions import SqlQueryEPTO

cef = CommonExecuteFunctions()
sql_object = SqlQueryEPTO()

# Read yaml config from S3
params = cef.json_read_from_s3(s3_bucket, config_key)

# Get required variables from json config
date_lag = params['date_lag']
partition_year = params['partition_year']
partition_month = params['partition_month']
log_group_name = params['log_group_name']
topic_name = params['topic_name']
topic_arn = f"arn:aws:sns:ap-south-1:{account_id}:{topic_name}"
db_name = params['db_name']
starting_year = params['starting_year']
starting_month = params['starting_month']

print(f"Historical data to be checked from partition year : {starting_year}, partition month : {starting_month}")

# Specify the time zone (IST)
ist = pytz.timezone('Asia/Kolkata')
# Get the current time in IST
date_today = datetime.now(ist).strftime("%Y%m%d%H%M")

#Log group & stream 
cef.create_log_group(log_group_name)
log_stream_name = f'msil_test_etl_{date_today}'
print(f"log_stream_name for current job run: {log_stream_name}")

#initialize logger
logger = cef.init_cloudwatch_logger(log_group_name, log_stream_name)

# Get partition_year and partition_month for which data is to be extracted.
# If partition_year or partition_month is set to default as "9999" in config file, current year and month will be considered with date lag.
if (partition_year == "9999")|(partition_month == "9999"):
    partition_year, partition_month = cef.get_partition_year_month(date_lag)
    
print(f"partition year : {partition_year}")
print(f"partition month : {partition_month}")

# =================== To Create Database =============================
def create_glue_database(database_name, catalog_name):
    # Initialize Glue client
    glue_client = boto3.client('glue')

    # Create a new database
    create_database_response = glue_client.create_database(
        DatabaseInput={
            'Name': database_name,
            'Description': 'Project Database'
        }
    )

    # Check if database creation was successful
    if create_database_response['ResponseMetadata']['HTTPStatusCode'] == 200:
        print(f"Database '{database_name}' created successfully.")
    else:
        print(f"Error creating database: {create_database_response}")

try:
    create_glue_database(db_name, catalog_name)
except:
    pass

####### Create Athena Tables #####

def create_athena_table(database, bucket_name, table_query, location):

    # Create Athena client
    athena_client = boto3.client('athena')

    # Submit the query to Athena
    response = athena_client.start_query_execution(
        QueryString=table_query,
        QueryExecutionContext={'Database': database},
        ResultConfiguration={'OutputLocation': location}
    )
    # Print the query execution ID
    print(f"Query Execution ID: {response['QueryExecutionId']}")

create_athena_table(db_name, s3_bucket, eval(f'f"{ASSEMBLY_CRANK_TABLE}"'),
                    eval(ASSEMBLY_CRANK_TABLE_LOCATION))
create_athena_table(db_name, s3_bucket, eval(f'f"{MACHINING_CYLINDER_HEAD_CAM_BORE_TABLE}"'),
                    eval(MACHINING_CYLINDER_HEAD_CAM_BORE_TABLE_LOCATION))
create_athena_table(db_name, s3_bucket, eval(f'f"{MACHINING_CYLINDER_BLOCK_BORE_TABLE}"'),
                    eval(MACHINING_CYLINDER_BLOCK_BORE_TABLE_LOCATION))
create_athena_table(db_name, s3_bucket, eval(f'f"{MACHINING_CAM_SHAFT_ROTOR_TABLE}"'),
                    eval(MACHINING_CAM_SHAFT_ROTOR_TABLE_LOCATION))
create_athena_table(db_name, s3_bucket, eval(f'f"{MACHINING_CYLINDER_BORE_JR_TABLE}"'),
                    eval(MACHINING_CYLINDER_BORE_JR_TABLE_LOCATION))
create_athena_table(db_name, s3_bucket, eval(f'f"{MACHINING_CRANK_SHAFT_MEASUREMENT_TABLE}"'),
                    eval(MACHINING_CRANK_SHAFT_MEASUREMENT_TABLE_LOCATION))
create_athena_table(db_name, s3_bucket, eval(f'f"{MACHINING_CAM_SHAFT_MEASUREMENT_TABLE}"'),
                    eval(MACHINING_CAM_SHAFT_MEASUREMENT_TABLE_LOCATION))
create_athena_table(db_name, s3_bucket, eval(f'f"{MACHINING_CYLINDER_BORE_JR_MAPPING_TABLE}"'),
                    eval(MACHINING_CYLINDER_BORE_JR_MAPPING_TABLE_LOCATION))
                    


def delete_txt_files(bucket_name, folder_path):
    s3 = boto3.resource('s3')
    bucket = s3.Bucket(bucket_name)
    # List all objects in the specified folder path
    for obj in bucket.objects.filter(Prefix=folder_path):
        # Check if the object ends with ".csv" and delete it
        if obj.key.endswith('.txt'):
            print(f"Deleting extra text files {obj.key}")
            obj.delete()

def create_sns_topic(topic_name):
    # Initialize the SNS client
    sns_client = boto3.client('sns')
    
    try:
        # Create the SNS topic
        response = sns_client.create_topic(Name=topic_name)
        topic_arn = response['TopicArn']
        print(f"SNS Topic '{topic_name}' created with ARN: {topic_arn}")
    except:
        pass
    
def send_sns_notification(topic_arn, message, subject):
    # Initialize the SNS client
    sns_client = boto3.client('sns')
        
    # Publish the message to the specified SNS topic with a subject
    response = sns_client.publish(TopicArn=topic_arn, Message=message, Subject=subject)

    # Print the MessageId of the published message
    message_id = response['MessageId']
    print(f"Message published successfully with MessageId: {message_id}")
    
def generate_month_year_list(start_year, start_month):
    #Generate a list of (year,month) from the specified start_year and start_month
    current_date = datetime.now()
    start_date = datetime(start_year, start_month, 1)
 
    month_year_list = []
 
    while start_date <= current_date:
        year = start_date.year
        month = start_date.month
        year_str = str(year)
        month_str = str(month).zfill(2)
        month_year_list.append((year_str, month_str))
        start_date += relativedelta(months=1)
 
    return month_year_list
    
def check_historical_data(db_name,table_name):
    #Check and return partition_year, partition_month which are not present in historical start_year and start_month
    
    # Generate a list of year, month from specified input excluding current month.
    month_year_list = generate_month_year_list(starting_year, starting_month)
    month_year_list = month_year_list[:-1]
    print(f"month_year_list : {month_year_list}")
    
    # Get partition details for particular table 
    sql_missing_query = f"""SELECT DISTINCT CONCAT(partition_year, ',' , partition_month) AS result FROM  {db_name}.{table_name} """
    
    df = cef.awswrangler_execute_query(sql_missing_query, db_name)
    # Convert partition_data to list
    partition_data = df['result'].to_list()
    # Convert partition_data to a list of tuples
    partition_data_tuples = [(year, month) for year, month in [data.split(',') for data in partition_data]]
    print(f"partitions present for {table_name}: {partition_data_tuples}")
    
    # Compare both the list 
    # Convert lists to sets
    set_month_year_list = set(month_year_list)
    set_partition_data_tuples = set(partition_data_tuples)

    # Find items in listA that are not present in listB
    missing_year_month = set_month_year_list - set_partition_data_tuples
    
    return missing_year_month


def assembly_crank_func():
    """This function is used to extract & process data from all the source defect table for all machined id's.

    Args:
        params (json): Globally defined variable - contains config json
    """
    config = params['assembly_crank_config']
    table_name = config['table_name']
    machine_ids = config['machine_id']
    s3_prefix = config['s3_prefix']
    machine_ids_str = ','.join(["'" + item + "'" for item in machine_ids])
    
    print(f"Number of Machine Id considered for assembly_crank tables : {len(machine_ids)}")
    print(f"Machine Id considered for assembly_crank tables : {machine_ids}")
    
    cef.delete_current_files_s3(s3_bucket, config, partition_year, partition_month)
    
    sql_query_assembly_crank_table = sql_object.get_query_assembly_crank_table(
                machine_ids_str, partition_year, partition_month)
                
    print(sql_query_assembly_crank_table)

    # run query
    cef.awswrangler_execute_query(sql_query_assembly_crank_table, db_name)
    
    logger.info(f"Assembly Crank Table updated")
    
    # Checking Historical data , if not present create it.
    missing_year_month = check_historical_data(db_name,table_name)
    print(f"Missing partitions present for table: {table_name} are {missing_year_month}")
    for year, month in missing_year_month:
        print(f"Executing missing historical records for Table: {table_name}, Year: {year}, Month: {month}")
        sql_query_assembly_crank_table = sql_object.get_query_assembly_crank_table(machine_ids_str, year, month)
        # run query
        cef.awswrangler_execute_query(sql_query_assembly_crank_table, db_name)
        
    #delete generated txt files     
    last_slash_index = s3_prefix.rfind('/')
    path = s3_prefix[:last_slash_index + 1]
    delete_txt_files(s3_bucket, path)
    
    return True

def machining_cylinder_head_cam_bore_func():
    """This function is used to extract & process data from all the source defect table for all machined id's.

    Args:
        params (json): Globally defined variable - contains config json
    """
    config = params['machining_cylinder_head_cam_bore_config']
    table_name = config['table_name']
    machine_ids = config['machine_id']
    s3_prefix = config['s3_prefix']
    machine_ids_str = ','.join(["'" + item + "'" for item in machine_ids])
    
    print(f"Number of Machine Id considered for machining_cylinder_head_cam_bore tables : {len(machine_ids)}")
    print(f"Machine Id considered for machining_cylinder_head_cam_bore tables : {machine_ids}")
    
    cef.delete_current_files_s3(s3_bucket, config, partition_year, partition_month)
    
    sql_query_machining_cylinder_head_cam_bore_table = sql_object.get_query_machining_cylinder_head_cam_bore_table(
                machine_ids_str, partition_year, partition_month)
    
    print(sql_query_machining_cylinder_head_cam_bore_table)
    
    # run query
    cef.awswrangler_execute_query(sql_query_machining_cylinder_head_cam_bore_table, db_name)
    
    logger.info(f"Machining Cylinder Head Cam Bore Table updated")
    
    # Checking Historical data , if not present create it.
    missing_year_month = check_historical_data(db_name, table_name)
    print(f"Missing partitions present for table: {table_name} are {missing_year_month}")
    for year, month in missing_year_month:
        print(f"Executing missing historical records for Table: {table_name}, Year: {year}, Month: {month}")
        sql_query_machining_cylinder_head_cam_bore_table = sql_object.get_query_machining_cylinder_head_cam_bore_table(machine_ids_str, year, month)
        # run query
        cef.awswrangler_execute_query(sql_query_machining_cylinder_head_cam_bore_table, db_name)
        
    #delete generated txt files     
    last_slash_index = s3_prefix.rfind('/')
    path = s3_prefix[:last_slash_index + 1]
    delete_txt_files(s3_bucket, path)
    
    return True
    
def machining_cylinder_block_bore_func():
    """This function is used to extract & process data from all the source defect table for all machined id's.

    Args:
        params (json): Globally defined variable - contains config json
    """
    config = params['machining_cylinder_block_bore_config']
    machine_ids = config['machine_id']
    table_name = config['table_name']
    s3_prefix = config['s3_prefix']
    machine_ids_str = ','.join(["'" + item + "'" for item in machine_ids])
    
    print(f"Number of Machine Id considered for machining_cylinder_block_bore tables : {len(machine_ids)}")
    print(f"Machine Id considered for machining_cylinder_block_bore tables : {machine_ids}")
    
    cef.delete_current_files_s3(s3_bucket, config, partition_year, partition_month)
    
    sql_query_machining_cylinder_block_bore_table = sql_object.get_query_machining_cylinder_block_bore_table(
                machine_ids_str, partition_year, partition_month)
    
    print(sql_query_machining_cylinder_block_bore_table)
    
    # run query
    cef.awswrangler_execute_query(sql_query_machining_cylinder_block_bore_table, db_name)
    logger.info(f"Machining Cylinder Block Bore Table updated")
    
    # Checking Historical data , if not present create it.
    missing_year_month = check_historical_data(db_name, table_name)
    print(f"Missing partitions present for table: {table_name} are {missing_year_month}")
    for year, month in missing_year_month:
        print(f"Executing missing historical records for Table: {table_name}, Year: {year}, Month: {month}")
        sql_query_machining_cylinder_block_bore_table = sql_object.get_query_machining_cylinder_block_bore_table(machine_ids_str, year, month)
        # run query
        cef.awswrangler_execute_query(sql_query_machining_cylinder_block_bore_table, db_name)
        
    #delete generated txt files     
    last_slash_index = s3_prefix.rfind('/')
    path = s3_prefix[:last_slash_index + 1]
    delete_txt_files(s3_bucket, path)
    
    return True
    
def machining_cylinder_bore_jr_func():
    """This function is used to extract & process data from all the source defect table for all machined id's.

    Args:
        params (json): Globally defined variable - contains config json
    """
    config = params['machining_cylinder_bore_jr_config']
    table_name = config['table_name']
    machine_ids = config['machine_id']
    s3_prefix = config['s3_prefix']
    machine_ids_str = ','.join(["'" + item + "'" for item in machine_ids])
    
    print(f"Number of Machine Id considered for machining_cylinder_bore_jr tables : {len(machine_ids)}")
    print(f"Machine Id considered for machining_cylinder_bore_jr tables : {machine_ids}")
    
    cef.delete_current_files_s3(s3_bucket, config, partition_year, partition_month)
    
    sql_query_machining_cylinder_bore_jr_table = sql_object.get_query_machining_cylinder_bore_jr_table(
                machine_ids_str, partition_year, partition_month)
    
    print(sql_query_machining_cylinder_bore_jr_table)
    
    # run query
    cef.awswrangler_execute_query(sql_query_machining_cylinder_bore_jr_table, db_name)
    logger.info(f"Machining Cylinder Bore jr Table updated")
    
    # Checking Historical data , if not present create it.
    missing_year_month = check_historical_data(db_name, table_name)
    print(f"Missing partitions present for table: {table_name} are {missing_year_month}")
    for year, month in missing_year_month:
        print(f"Executing missing historical records for Table: {table_name}, Year: {year}, Month: {month}")
        sql_query_machining_cylinder_bore_jr_table = sql_object.get_query_machining_cylinder_bore_jr_table(machine_ids_str, year, month)
        # run query
        cef.awswrangler_execute_query(sql_query_machining_cylinder_bore_jr_table, db_name)
        
    #delete generated txt files     
    last_slash_index = s3_prefix.rfind('/')
    path = s3_prefix[:last_slash_index + 1]
    delete_txt_files(s3_bucket, path)
    
    return True
    
def machining_cam_shaft_rotor_func():
    """This function is used to extract & process data from all the source defect table for all machined id's.

    Args:
        params (json): Globally defined variable - contains config json
    """
    config = params['machining_cam_shaft_rotor_config']
    table_name = config['table_name']
    machine_ids = config['machine_id']
    s3_prefix = config['s3_prefix']
    machine_ids_str = ','.join(["'" + item + "'" for item in machine_ids])
    
    print(f"Number of Machine Id considered for machining_cam_shaft_rotor tables : {len(machine_ids)}")
    print(f"Machine Id considered for machining_cam_shaft_rotor tables : {machine_ids}")
    
    cef.delete_current_files_s3(s3_bucket, config, partition_year, partition_month)
    
    sql_query_machining_cam_shaft_rotor_table = sql_object.get_query_machining_cam_shaft_rotor_table(
                machine_ids_str, partition_year, partition_month)
    
    print(sql_query_machining_cam_shaft_rotor_table)
    
    # run query
    cef.awswrangler_execute_query(sql_query_machining_cam_shaft_rotor_table, db_name)
    logger.info(f"Machining Cam Shaft Rotor Table updated")
    
    # Checking Historical data , if not present create it.
    missing_year_month = check_historical_data(db_name, table_name)
    print(f"Missing partitions present for table: {table_name} are {missing_year_month}")
    for year, month in missing_year_month:
        print(f"Executing missing historical records for Table: {table_name}, Year: {year}, Month: {month}")
        sql_query_machining_cam_shaft_rotor_table = sql_object.get_query_machining_cam_shaft_rotor_table(machine_ids_str, year, month)
        # run query
        cef.awswrangler_execute_query(sql_query_machining_cam_shaft_rotor_table, db_name)
        
    #delete generated txt files     
    last_slash_index = s3_prefix.rfind('/')
    path = s3_prefix[:last_slash_index + 1]
    delete_txt_files(s3_bucket, path)
    
    return True
    
def machining_cam_shaft_measurement_func():
    """This function is used to extract & process data from all the source defect table for all machined id's.

    Args:
        params (json): Globally defined variable - contains config json
    """
    config = params['machining_cam_shaft_measurement_config']
    table_name = config['table_name']
    machine_ids = config['machine_id']
    s3_prefix = config['s3_prefix']
    machine_ids_str = ','.join(["'" + item + "'" for item in machine_ids])
    
    print(f"Number of Machine Id considered for machining_cam_shaft_measurement tables : {len(machine_ids)}")
    print(f"Machine Id considered for machining_cam_shaft_measurement tables : {machine_ids}")
    
    cef.delete_current_files_s3(s3_bucket, config, partition_year, partition_month)
    
    sql_query_machining_cam_shaft_measurement_table = sql_object.get_query_machining_cam_shaft_measurement_table(
                machine_ids_str, partition_year, partition_month)
    
    print(sql_query_machining_cam_shaft_measurement_table)
    
    # run query
    cef.awswrangler_execute_query(sql_query_machining_cam_shaft_measurement_table, db_name)
    logger.info(f"Machining Cam Shaft Measurement Table updated")
    
    # Checking Historical data , if not present create it.
    missing_year_month = check_historical_data(db_name, table_name)
    print(f"Missing partitions present for table: {table_name} are {missing_year_month}")
    for year, month in missing_year_month:
        print(f"Executing missing historical records for Table: {table_name}, Year: {year}, Month: {month}")
        sql_query_machining_cam_shaft_measurement_table = sql_object.get_query_machining_cam_shaft_measurement_table(machine_ids_str, year, month)
        # run query
        cef.awswrangler_execute_query(sql_query_machining_cam_shaft_measurement_table, db_name)
        
    #delete generated txt files     
    last_slash_index = s3_prefix.rfind('/')
    path = s3_prefix[:last_slash_index + 1]
    delete_txt_files(s3_bucket, path)
    
    return True
    
def machining_crank_shaft_measurement_func():
    """This function is used to extract & process data from all the source defect table for all machined id's.

    Args:
        params (json): Globally defined variable - contains config json
    """
    config = params['machining_crank_shaft_measurement_config']
    table_name = config['table_name']
    machine_ids = config['machine_id']
    s3_prefix = config['s3_prefix']
    machine_ids_str = ','.join(["'" + item + "'" for item in machine_ids])
    
    print(f"Number of Machine Id considered for machining_crank_shaft_measurement tables : {len(machine_ids)}")
    print(f"Machine Id considered for machining_crank_shaft_measurement tables : {machine_ids}")
    
    cef.delete_current_files_s3(s3_bucket, config, partition_year, partition_month)
    
    sql_query_machining_crank_shaft_measurement_table = sql_object.get_query_machining_crank_shaft_measurement_table(
                machine_ids_str, partition_year, partition_month)
    
    print(sql_query_machining_crank_shaft_measurement_table)
    
    # run query
    cef.awswrangler_execute_query(sql_query_machining_crank_shaft_measurement_table, db_name)
    logger.info(f"Machining Crank Shaft measurement Table updated")
    
    # Checking Historical data , if not present create it.
    missing_year_month = check_historical_data(db_name, table_name)
    print(f"Missing partitions present for table: {table_name} are {missing_year_month}")
    for year, month in missing_year_month:
        print(f"Executing missing historical records for Table: {table_name}, Year: {year}, Month: {month}")
        sql_query_machining_crank_shaft_measurement_table = sql_object.get_query_machining_crank_shaft_measurement_table(machine_ids_str, year, month)
        # run query
        cef.awswrangler_execute_query(sql_query_machining_crank_shaft_measurement_table, db_name)
        
    #delete generated txt files     
    last_slash_index = s3_prefix.rfind('/')
    path = s3_prefix[:last_slash_index + 1]
    delete_txt_files(s3_bucket, path)
    
    return True
    
def machining_cylinder_bore_jr_mapping_func():
    """This function is used to extract & process data from all the source defect table for all machined id's.

    Args:
        params (json): Globally defined variable - contains config json
    """
    config = params['machining_cylinder_bore_jr_mapping_config']
    table_name = config['table_name']
    machine_ids = config['machine_id']
    s3_prefix = config['s3_prefix']
    machine_ids_str = ','.join(["'" + item + "'" for item in machine_ids])
    
    print(f"Number of Machine Id considered for machining_cylinder_bore_jr_mapping tables : {len(machine_ids)}")
    print(f"Machine Id considered for machining_cylinder_bore_jr_mapping tables : {machine_ids}")
    
    cef.delete_current_files_s3(s3_bucket, config, partition_year, partition_month)
    
    sql_query_machining_cylinder_bore_jr_mapping_table = sql_object.get_query_machining_cylinder_bore_jr_mapping_table(
                machine_ids_str, partition_year, partition_month)
    
    print(sql_query_machining_cylinder_bore_jr_mapping_table)
    
    # run query
    cef.awswrangler_execute_query(sql_query_machining_cylinder_bore_jr_mapping_table, db_name)
    logger.info(f"Machining Cylinder Bore jr mapping Table updated")
    
    # Checking Historical data , if not present create it.
    missing_year_month = check_historical_data(db_name, table_name)
    print(f"Missing partitions present for table: {table_name} are {missing_year_month}")
    for year, month in missing_year_month:
        print(f"Executing missing historical records for Table: {table_name}, Year: {year}, Month: {month}")
        sql_query_machining_cylinder_bore_jr_mapping_table = sql_object.get_query_machining_cylinder_bore_jr_mapping_table(machine_ids_str, year, month)
        # run query
        cef.awswrangler_execute_query(sql_query_machining_cylinder_bore_jr_mapping_table, db_name)
    
    #delete generated txt files     
    last_slash_index = s3_prefix.rfind('/')
    path = s3_prefix[:last_slash_index + 1]
    delete_txt_files(s3_bucket, path)
    
    return True
            
if __name__ == "__main__":
    
    # Main function
    logger.info(f"Main starting")
    create_sns_topic(topic_name)
    
    # Processing for Assembly Data
    if params['master_config']['assembly_crank_config'] == 1:
        assembly_crank_func()
        
    # Processing for Cynlinder Head Cam Data
    if params['master_config']['machining_cylinder_head_cam_bore_config'] == 1:
        machining_cylinder_head_cam_bore_func()
        
    # Processing for Cynlinder Head Cam Data
    if params['master_config']['machining_cylinder_block_bore_config'] == 1:
        machining_cylinder_block_bore_func()
        
    # Processing for Cynlinder Head Cam Data
    if params['master_config']['machining_cylinder_bore_jr_config'] == 1:
        machining_cylinder_bore_jr_func()
        
    # Processing for Cam Shaft Rotor Data
    if params['master_config']['machining_cam_shaft_rotor_config'] == 1:
        machining_cam_shaft_rotor_func()
        
    # Processing for Cam Shaft Measurement Data
    if params['master_config']['machining_cam_shaft_measurement_config'] == 1:
        machining_cam_shaft_measurement_func()
        
    # Processing for Crank Shaft Measurement Data
    if params['master_config']['machining_crank_shaft_measurement_config'] == 1:
        machining_crank_shaft_measurement_func()
        
    # Processing for Crank Shaft Measurement Data
    if params['master_config']['machining_cylinder_bore_jr_mapping_config'] == 1:
        machining_cylinder_bore_jr_mapping_func()
        
    # send send_sns_notification
    message = f'EPTO ETL job is Successfull. Data is updated for partition_year: {partition_year} and partition_month: {partition_month}'
    subject = f'EPTO ETL job completed on {date_today}'
    send_sns_notification(topic_arn, message, subject)