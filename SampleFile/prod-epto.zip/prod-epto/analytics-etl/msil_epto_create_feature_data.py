import sys
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
## @params: [JOB_NAME]
args = getResolvedOptions(sys.argv, ['JOB_NAME'])

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args['JOB_NAME'], args)

# Get config_bucket and config_key from argument.
args = getResolvedOptions(sys.argv, ["config_bucket", "config_key", "s3_output_bucket"])
s3_bucket = args["config_bucket"]
config_key = args["config_key"]
s3_output_bucket = args["s3_output_bucket"]

import boto3
import pandas as pd
# import pyarrow.parquet as pq
# import pyarrow as pa
import yaml
# import pyarrow.fs
# import pyarrow
from datetime import datetime
from datetime import datetime, timedelta
# import s3fs
# s3_fs = s3fs.S3FileSystem()

"""def load_config(config_file_path):
    try:
        with open(config_file_path, 'r') as config_file:
            config = yaml.safe_load(config_file)
        return config
    except Exception as e:
        print(f"Error loading config file: {str(e)}")
        return None"""
def read_yaml_from_s3(config_bucket, config_key):
    s3_client = boto3.client("s3")
    response = s3_client.get_object(Bucket=config_bucket, Key=config_key)
    config = yaml.safe_load(response["Body"])
    return config

def read_mean_parameters(config):
    mean_parameters = config['mean_parameters'] if 'mean_parameters' in config else {}
    return mean_parameters

def calculate_mean_values(data, mean_parameters):
    for component_name, mean_details in mean_parameters.items():
        for mean_type, columns in mean_details.items():
            if isinstance(columns, list):
                mean_column_name = f"{component_name}_{mean_type}_mean"
                data[mean_column_name] = data[columns].mean(axis=1, skipna=True)
                # Drop original columns after calculating mean values
                data = data.drop(columns=columns, errors='ignore')
    return data  # Return the modified dataframe

def filter_data_by_date(data, date_column, start_date=None, end_date=None):
    original_size = data.shape[0]  # Get the original size before filtering

    if start_date or end_date:
        try:
            data[date_column] = pd.to_datetime(data[date_column], errors='coerce')
        except Exception as e:
            print(f"Error converting {date_column} to datetime: {str(e)}")

        if start_date and end_date:
            data = data[(data[date_column] >= start_date) & (data[date_column] <= end_date)]
        elif start_date:
            data = data[data[date_column] >= start_date]
        elif end_date:
            data = data[data[date_column] <= end_date]
    else:
        # If start_date and end_date are not provided, extract data from the last seven days (excluding today)
        current_date = datetime.now().date()
        seven_days_ago = current_date - timedelta(days=1)
        data[date_column] = pd.to_datetime(data[date_column], errors='coerce')
        data = data[(data[date_column] >= seven_days_ago) & (data[date_column] < current_date)]

    filtered_size = data.shape[0]  # Get the size after filtering
    print(f"Original Size: {original_size}, Filtered Size: {filtered_size}")

    return data

def read_parquet_from_s3(bucket, path, key_column, date_column, start_date=None, end_date=None, exclude_columns=[]):
    s3_path = f"s3://{bucket}/{path}"
    print(s3_path)
    
    parquet_files = pd.read_parquet(s3_path)
    
    # Filter data based on date
    parquet_files = filter_data_by_date(parquet_files, date_column, start_date, end_date)

    # Exclude specified columns
    parquet_files = parquet_files.drop(columns=exclude_columns, errors='ignore')

    # Keep only the last occurrence of each duplicate row based on the key column
    parquet_files = parquet_files.drop_duplicates(subset=key_column, keep='last')
  
    return parquet_files

def read_csv_from_s3(bucket, path):
    
    s3_path = f"s3://{bucket}/{path}"
    csv_data = pd.read_csv(s3_path)
    return csv_data

def apply_transformations(data, transformations):
    for transformation in transformations:
        component_name = transformation['name']
        divide_by = transformation.get('divide_by', 1)

        if component_name in data:
            # Convert all numeric columns to float and divide by the specified value
            data[component_name] = data[component_name].apply(pd.to_numeric, errors='ignore')
            data[component_name] = data[component_name].div(divide_by)
            
def apply_engine_specific_updates(data, engine_type, engine_update_values):
    # Remove spaces from engine_type for consistent matching
    engine_type = engine_type.replace(" ", "")

    if engine_type in engine_update_values:
        update_values = engine_update_values[engine_type]

        for column, value in update_values.items():
            # Print the values before the update
            print(f"Before Update - {column}: {data[column].iloc[0]}")

            # Divide existing values by 1000 if the column exists in the dataset
            if column in data.columns:
                data[column] = data[column] / 1000  # Divide existing values by 1000
            else:
                print(f"Error updating column {column}: '{column}' not found in DataFrame for engine type {engine_type}")

            # Apply updates for the selected column
            if column in data.columns:
                data[column] = data[column] + value
            else:
                print(f"Error updating column {column}: '{column}' not found in DataFrame for engine type {engine_type}")

            # Print the values after the update
            print(f"After Update - {column}: {data[column].iloc[0]}")

    else:
        print(f"No update values found for engine type {engine_type}")

    return data

def merge_tables(engine_components, tag_data, mean_parameters, start_date, end_date):
    final_merged_table = pd.DataFrame()

    # Iterate through the engine components
    for component in engine_components:
        engine_data = read_parquet_from_s3(
            s3_bucket,
            component['path'],
            component['key_column'],
            component['date_column'],
            start_date=component.get('start_date'),
            end_date=component.get('end_date'),
            exclude_columns=component.get('exclude_columns', [])
        )

        # For "cam_shaft_rotor" component, consider only the last 14 characters from the key column
        if component['name'] == 'cam_shaft_rotor':
            engine_data[component['key_column']] = engine_data[component['key_column']].str[-14:]

        # Apply transformations
        apply_transformations(engine_data, component.get('transformations', []))

        # Apply str.strip() to key columns
        engine_data[component['key_column']] = engine_data[component['key_column']].str.strip()

        if not final_merged_table.empty:
            print(f"Merging with existing final merged table for component: {component['name']}")
            print(f"Existing columns: {final_merged_table.columns}")
            print(f"Component columns: {engine_data.columns}")

            # Drop 'key_0' before the merge
            final_merged_table = final_merged_table.drop(columns=['key_0'], errors='ignore')

            final_merged_table = pd.merge(
                final_merged_table,
                engine_data,
                left_on=final_merged_table[component['tag_key_column']],
                right_on=engine_data[component['key_column']],
                how='left'
            )
            print(f"After merge columns: {final_merged_table.columns}")
        else:
            print(f"Initial merge with Tag Data for component: {component['name']}")
            final_merged_table = pd.merge(
                tag_data,
                engine_data,
                left_on=tag_data[component['tag_key_column']],
                right_on=engine_data[component['key_column']],
                how='left'
            )
            print(f"After initial merge columns: {final_merged_table.columns}")

    # Drop columns with data type 'object' (excluding 'engine_type' and 'data_tag')
    drop_columns = [col for col, dtype in final_merged_table.dtypes.items() if dtype == 'object' and col not in ['date_tag', 'engine_type']]
    final_merged_table = final_merged_table.drop(columns=drop_columns, errors='ignore')

    # Calculate mean values
    final_merged_table = calculate_mean_values(final_merged_table, mean_parameters)

    return final_merged_table


def read_assembly_component(config):
    
        # Extract component details from the config
    component_name = config['name']
    path = config['path']
    key_column = config['key_column']
    # bucket = config['bucket']
    bucket = s3_bucket
    exclude_columns = config.get('exclude_columns', [])
    float_conversion_columns = config.get('float_conversion_columns', [])

    s3_path = f"s3://{bucket}/{path}"
    # assembly_data = pq.ParquetDataset(s3_path).read_pandas().to_pandas()
    assembly_data = pd.read_parquet(s3_path)

        # Exclude specified columns
    assembly_data = assembly_data.drop(columns=exclude_columns, errors='ignore')

        # Keep only the last occurrence of each duplicate row based on the key column
    assembly_data = assembly_data.drop_duplicates(subset=key_column, keep='last')

        # Convert specified columns to float
    for column in float_conversion_columns:
        if column in assembly_data:
            assembly_data[column] = pd.to_numeric(assembly_data[column], errors='coerce').astype(float)

    return assembly_data

    
    
def merge_assembly_components(cbsapreload_data, mtb_athena_table_data):
    
        # Extract the last 7 characters from 'engine_no' in mtb_athena_table_data
    mtb_athena_table_data['engine_no_last_7'] = mtb_athena_table_data['engine_no'].str[-7:]

        # Handle duplicate values and consider the last occurrence
    mtb_athena_table_data = mtb_athena_table_data.drop_duplicates(subset='engine_no_last_7', keep='last')

        # Filter data based on the 'result' column
    mtb_athena_table_data = mtb_athena_table_data[mtb_athena_table_data['result'] == 'OK']

        # Reset the index before merge
    mtb_athena_table_data.reset_index(drop=True, inplace=True)

        # Convert 'engine_no_last_7' to an integer data type
    mtb_athena_table_data['engine_no_last_7'] = pd.to_numeric(mtb_athena_table_data['engine_no_last_7'],errors='coerce').astype('Int64')

        # Convert 'engine_no' in cbsapreload_data to an integer data type
    cbsapreload_data['engine_no'] = pd.to_numeric(cbsapreload_data['engine_no'], errors='coerce').astype('Int64')

        # Drop unnecessary columns from mtb_athena_table_data after extracting 7 digits
    mtb_athena_table_data = mtb_athena_table_data.drop(columns=['engine_no'], errors='ignore')

        # Merge data based on the common 'engine_no_last_7' column
    merged_data = pd.merge(cbsapreload_data, mtb_athena_table_data, how='left', left_on='engine_no', right_on='engine_no_last_7')

        # Keep only the rows where the 'result' column is 'OK'
    merged_data = merged_data[merged_data['result'] == 'OK']

        # Drop unnecessary columns after the merge
    merged_data = merged_data.drop(columns=['engine_no_last_7', 'result', 'sys_date'], errors='ignore')

    return merged_data

def remove_whitespace_from_columns(data):
    data.columns = data.columns.str.strip()
    return data


def process_data():

    config = read_yaml_from_s3(s3_bucket, config_key)

    # Read the CSV file (tag_data)
    tag_data = read_csv_from_s3(s3_bucket, config['tag_data']['path'])

    # Read mean parameters from the config
    mean_parameters = read_mean_parameters(config)

    # Get start_date and end_date from the config
    start_date = config.get('start_date', None)
    end_date = config.get('end_date', None)

    # Merge engine components with tag data
    merged_data = merge_tables(config['engine_components'], tag_data, mean_parameters, start_date, end_date)

    merged_data = remove_whitespace_from_columns(merged_data)

    # Get the engine update values (moved here after merging)
    engine_update_values = config.get('engine_update_values', {})
    print(f"Engine Update Values: {engine_update_values}")

    # Create an empty list to store updated groups
    updated_groups = []

    for engine_type, group in merged_data.groupby('engine_type'):
        # Remove spaces from engine_type for consistent matching
        engine_type = engine_type.replace(" ", "")
        updated_group = apply_engine_specific_updates(group.copy(), engine_type, engine_update_values)
        updated_groups.append(updated_group)

    # Concatenate the updated groups back into a single DataFrame
    merged_data = pd.concat(updated_groups)

    # Read assembly components
    cbsapreload_config = config['assembly_components'][0]  # Assuming cbsapreload is the first component
    mtb_athena_table_config = config['assembly_components'][1]  # Assuming mtb_athena_table is the second component

    cbsapreload_data = read_assembly_component(cbsapreload_config)
    mtb_athena_table_data = read_assembly_component(mtb_athena_table_config)

    # Merge assembly components
    assembly_merged_data = merge_assembly_components(cbsapreload_data, mtb_athena_table_data)

    # Merge the two datasets based on 'engine_num' and 'engine_no'
    final_machine_assembly = pd.merge(merged_data, assembly_merged_data, how='inner', left_on='engine_num', right_on='engine_no')

    # Drop unnecessary columns after the merge
    final_machine_assembly = final_machine_assembly.drop(columns=['engine_no'], errors='ignore')

    # Save the final merged data for machine and assembly components based on engine_type
    for engine_type, group in final_machine_assembly.groupby('engine_type'):
        # Remove spaces from engine_type for use in the file path
        engine_type_stripped = engine_type.replace(" ", "")

        # Get the date from the 'your_date_column' formatted as 'YYYY-MM-DD'
        sys_date = pd.to_datetime(group['date_tag'].str.split(" ").str[0], format='%Y-%m-%d')
        year = sys_date.dt.year.max()
        month = sys_date.dt.strftime('%m').max()
        day = sys_date.dt.strftime('%d').max()
        
        # Construct the S3 path with partitions
        s3_path = f"s3://{s3_output_bucket}/finaldata_assembly_machine_dataset/engine_type={engine_type_stripped}/partition_year={year}/partition_month={month}/partition_day={day}/final_machine_assembly_{engine_type_stripped}_{year}_{month}_{day}.parquet"

        group.to_parquet(s3_path)

if __name__ == "__main__":
    process_data()