import logging
import sys
import awswrangler as wr
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import SparkSession
from awsglue.job import Job
from awsglue.dynamicframe import DynamicFrame
import boto3
from awsglue.dynamicframe import DynamicFrame
from awsglue.transforms import SelectFromCollection
from datetime import date, datetime, timedelta
from pyspark.sql.functions import col, when
import json
import pandas as pd
import warnings
from dataquality_helper_functions import glue_process_status, gluedf_s3_loading

# Initialize Spark session
log = logging.getLogger(__name__)
logging.basicConfig(format=' %(job_name)s - %(asctime)s - %(message)s ')

warnings.filterwarnings("ignore")

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)

todays_date = date.today()
year = todays_date.year
month = todays_date.month
day = todays_date.day

if __name__ == '__main__':
    try:
        ########################################################################################################################
        ##### Read Parameters using getResolvedOptions
        args = getResolvedOptions(sys.argv,
                                  ["jrs_local_bucket",
                                   "eap_central_bucket",
                                   "dq_athena_db",
                                   "job_run_status_table",
                                   "usecase_name",
                                   "region",
                                   "job_prefix",
                                   "historical_days"])
        jrs_local_bucket = args['jrs_local_bucket']
        dq_athena_db = args['dq_athena_db']
        job_run_status_table = args['job_run_status_table']
        usecase_name = args['usecase_name']
        region = args['region']
        eap_central_bucket = args['eap_central_bucket']
        job_prefix = args['job_prefix']
        historical_days = int(args["historical_days"])

        ########################################################################################################################
        ##### aws session objects creation using boto3
        boto3_session = boto3.session.Session()
        # athena_client = pythena.Athena(database=dq_athena_db, session=boto3_session, region=region)
        sns_client = boto3.client('sns', region_name=region)
        # ce_client = boto3.client('ce')
        glue_client = boto3.client('glue')  # Initialize the Glue client

        ########################################################################################################################

        s3_path = f's3://{jrs_local_bucket}/etl_data_quality/{job_run_status_table}'
        s3_path_tobe_delete = f's3://{jrs_local_bucket}/etl_data_quality/{job_run_status_table}/year={year}/month={month}/day={day}'
        dashboard_path = f's3://{eap_central_bucket}/etl_process_status_log/usecase_name={usecase_name}/year={year}/month={month}/day={day}'
        date_filter = datetime.now().replace(hour=0, minute=0, second=0).strftime('%Y-%m-%d %H:%M:%S')
        # date_filter="2024-02-01 00:00:00"
        date_filter = (date.today() - timedelta(days=historical_days)).strftime("%Y-%m-%d")
        print(f"s3_path_tobe_delete : {s3_path_tobe_delete}")
        # start_date = str(start_date)
        # end_date = str(end_date)
        # print(f"Start Date :{start_date}")
        # print(f"end date is :{end_date}")
        (job_list_dyf, job_list_df) = glue_process_status(glueContext, spark, glue_client, job_prefix, year, month, day)
        # final_df = spark.createDataFrame(pandasDF)
        # print(job_list_dyf.show(20))
        filtered_job_list_df = job_list_df.where(job_list_df["startedon"] > date_filter)
        filtered_job_list_dyf = DynamicFrame.fromDF(filtered_job_list_df, glueContext, "filtered_job_list_dyf")
        filtered_job_list_df.createOrReplaceTempView("filtered_job_list_df")
        print(filtered_job_list_dyf.show())
        ########################################################################
        # Writing datase data to local athena table
        wr.s3.delete_objects(s3_path_tobe_delete)  # delete the exisitng files
        gluedf_s3_loading(glueContext, filtered_job_list_dyf, s3_path, dq_athena_db, job_run_status_table)

        ########################################################################
        # Write the data in parquet in cross account bucket

        log.info(dashboard_path)
        final_df = spark.sql(
            f"select jobname job_name,run_id,jobrunstate job_run_state,startedon started_on,completedon completed_on,lastmodifiedon last_modified_on,errormessage error_message,maxcapacity max_capacity,numberofworkers number_of_workers ,workertype worker_type,accountnumber account_number from filtered_job_list_df where startedon >= '{date_filter}' ")
        final_df.write.mode('overwrite').parquet(dashboard_path)
        log.info(f"Output data is written in parquet in cross account bucket: {dashboard_path}")

    except Exception as error:
        log.error("Error ->{}".format(error))
        raise error
