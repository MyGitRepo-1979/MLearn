import logging
import sys
import awswrangler as wr
from awsglue.transforms import *
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from pyspark.sql import SparkSession
from awsglue.job import Job
from awsglue.dynamicframe import DynamicFrame
import boto3
from awsglue.dynamicframe import DynamicFrame
from awsglue.transforms import SelectFromCollection
from datetime import date, datetime, timedelta
from pyspark.sql.functions import col, when
import json
import pandas as pd
from billing_cost_helperfunction import get_cost_data, get_date_list

# Initialize Spark session
log = logging.getLogger(__name__)
logging.basicConfig(format=' %(job_name)s - %(asctime)s - %(message)s ')

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)

if __name__ == '__main__':
    try:
        ########################################################################################################################
        ##### Read Parameters using getResolvedOptions
        args = getResolvedOptions(sys.argv,
                                  ["bcm_bucket",
                                   "eap_central_bucket",
                                   "dq_athena_db",
                                   "consolidated_bcm_table",
                                   "usecase_name",
                                   "region",
                                   "start_date",
                                   "end_date"])
        bcm_bucket = args['bcm_bucket']
        dq_athena_db = args['dq_athena_db']
        consolidated_bcm_table = args['consolidated_bcm_table']
        usecase_name = args['usecase_name']
        region = args['region']
        eap_central_bucket = args["eap_central_bucket"]
        start_date = args["start_date"]
        end_date = args["end_date"]

        ########################################################################################################################
        ##### aws session objects creation using boto3
        boto3_session = boto3.session.Session()
        # athena_client = pythena.Athena(database=dq_athena_db, session=boto3_session, region=region)
        sns_client = boto3.client('sns', region_name=region)
        ce_client = boto3.client('ce')

        ########################################################################################################################
        ##### define start & end date attributes
        ## Start_date : it should be month start date for ex : 2024-03-01 (YYYY-MM-DD") format . defauly value is "1900-01-01"
        ## end_date : it should be month end date of previous months or current datefor ex : 2024-03-12 (YYYY-MM-DD") format . defauly value is "1900-01-01"

        if (start_date == "1900-01-01" or end_date == "1900-01-01"):
            start_date = str(date.today().replace(day=1))
            end_date = str(date.today())
        else:
            start_date = start_date
            end_date = end_date
        dates_list = get_date_list(start_date, end_date)
        print(dates_list)

        for (start_date, end_date) in dates_list:
            year = start_date.year
            month = start_date.month
            s3_path = f's3://{bcm_bucket}/etl_data_quality/{consolidated_bcm_table}'
            s3_path_tobe_delete = f's3://{bcm_bucket}/etl_data_quality/{consolidated_bcm_table}/year={year}/month={month}/'
            dashboard_bcm_path = f's3://{eap_central_bucket}/billing-cost-management/usecase_name={usecase_name}/year={year}/month={month}/'
            start_date = str(start_date)
            end_date = str(end_date)
            print(f"Start Date :{start_date}")
            print(f"end date is :{end_date}")
            pandasDF = get_cost_data(ce_client, start_date, end_date)
            final_df = spark.createDataFrame(pandasDF)
            final_df.createOrReplaceTempView("final_df")

            ###################################################################################################################
            ### Writing detailed data to S3 and updating glue catalog
            wr.s3.delete_objects(s3_path_tobe_delete)  # delete the exisitng files
            list_partition_key = ["year", "month"]
            compression = "snappy"
            fileformat = "glueparquet"

            final_df = spark.sql(
                f"""select accountnumber,service,date,servicecost,unit,'{year}' as year,'{month}' as month from final_df where servicecost > 0.0""")
            local_final_dyf = DynamicFrame.fromDF(final_df, glueContext, "consolidated_dq_result_dyf")

            outcome = glueContext.getSink(
                path=s3_path,
                connection_type="s3",
                updateBehavior="UPDATE_IN_DATABASE",
                partitionKeys=list_partition_key,
                compression=compression,
                enableUpdateCatalog=True
            )
            outcome.setCatalogInfo(
                catalogDatabase=dq_athena_db, catalogTableName=consolidated_bcm_table
            )
            outcome.setFormat(fileformat)
            outcome.writeFrame(local_final_dyf)

            ########################################################################
            # Write the data in parquet in cross account bucket

            log.info(dashboard_bcm_path)
            # final_df = spark.createDataFrame(pandasDF)
            # final_df.createOrReplaceTempView("final_df")
            final_df = spark.sql(
                "select accountnumber,service,date,servicecost,unit from final_df where servicecost > 0.0")
            final_df.write.mode('overwrite').parquet(dashboard_bcm_path)
            print(f"Output data is written in parquet in cross account bucket: {dashboard_bcm_path}")
    except Exception as error:

        log.info("Ended the program cleanly")
        # raise error

