# 1. Anayltics-ETL aka DataOps

Note: Dependencies are managed in core repository to follow DRY principle and enforce security governance.

- [1. Anayltics-ETL aka DataOps](#1-anayltics-etl-aka-dataops)
  - [1.1. Automation: Analytics ETL (DataOps)](#11-automation-analytics-etl-dataops)
    - [1.1.1. Prerequisites](#111-prerequisites)
      - [1.1.1.1. Steps to be followed for creating Analytics ETL Glue jobs](#1111-steps-to-be-followed-for-creating-analytics-etl-glue-jobs)
      - [1.1.1.2. Steps to be followed for creating Analytics ETL  glue workflows](#1112-steps-to-be-followed-for-creating-analytics-etl--glue-workflows)
  - [1.2. ETL Data Quality](#12-etl-data-quality)
    - [1.2.1. Important Refernce link for GLue DQ dictionary](#121-important-refernce-link-for-glue-dq-dictionary)
    - [1.2.2. Prerequisites](#122-prerequisites)
    - [1.2.3. Information required from Developer/Business](#123-information-required-from-developerbusiness)
    - [1.2.4. Steps to be followed for creating etl dataquality glue jobs](#124-steps-to-be-followed-for-creating-etl-dataquality-glue-jobs)
    - [1.2.5. Success criteria for Data Quality Jobs](#125-success-criteria-for-data-quality-jobs)

## 1.1. Automation: Analytics ETL (DataOps)

This section talks about the automation of ETL glue jobs and their workflows

### 1.1.1. Prerequisites

Glue jobs and workflows should be developed and successfully tested from the console in sandbox or development environment

#### 1.1.1.1. Steps to be followed for creating Analytics ETL Glue jobs

 **Deployment of Glue workflow**

1. Data engineer need to create the list of glue jobs in the text file **“glue_jobs.txt”.** This will be used as an input to pull the glue jobs configuration in required json format
2. Data engineer need to use the below python script to extract the jobs configuration and create the
    Script path : [jenkins/scripts/readjobconfig.py](jenkins/scripts/readjobconfig.py)
3. Above script will generate the json file having all the required configuration of the glue jobs for their deployment in AWS account
4. Data engineer need to commit the json file in the usecase specific git repository in the following paths
    **Dev** : [env/dev/glue_jobs.config.json](env/dev/glue_jobs.config.json)
    **UAT** : [env/uat/glue_jobs.config.json](env/uat/glue_jobs.config.json)
    **Prod** : [env/prod/glue_jobs.config.json](env/prod/glue_jobs.config.json)

5. Data engineer need to commit glue job code in the file with the extension **“.py”**  in the “analytics-etl” folder in the  usecase specific git repository . Each python script in this path corresponds to one glue job showing on the console
6. Combination of script placed as .py file and configurations passed in glue_jobs_config.json will deploy the glue job in the AWS account

#### 1.1.1.2. Steps to be followed for creating Analytics ETL  glue workflows

 **Deployment of Glue workflow**

1. Data engineer need to create the list of glue workflow in the text file **“glue_wf.txt”.** This will be used as an input to pull the glue workflow configuration in required json format
2. Data engineer need to use the below python script to extract the jobs configuration and create the
    Script path : [jenkins/scripts/readjobconfig.py](jenkins/scripts/readjobconfig.py)
    **Note**: This script will give the workflow deinition for each workflow which needs to be concatenated seaprated by commas in the manual step to match to the required format.
    Please refer this sample workflow definition for the validation : [env/dev/glue_wf.config.json](env/dev/glue_wf.config.json)
3. Above script will generate the json file having all the required configuration of the glue workflow for their deployment in AWS account
4. Data engineer need to commit the json file in the usecase specific git repository  in the following paths
    **Dev** : [env/dev/glue_wf.config.json](env/dev/glue_wf.config.json)
    **UAT** : [env/uat/glue_wf.config.json](env/uat/glue_wf.config.json)
    **Prod** : [env/prod/glue_wf.config.json](env/prod/glue_wf.config.json)
5. Configurations passed in glue_wf.config.json will deploy the glue job in the AWS account
6. Data engineer needs to ensure that the etl data quality jobs should be included in the main workflow’s definition so that etl data quality jobs can be executed before the actual processing starts

## 1.2. ETL Data Quality

### 1.2.1. Important Refernce link for GLue DQ dictionary

This is the link which can referred for creating data quality rules
<https://docs.aws.amazon.com/glue/latest/dg/dqdl.html>

### 1.2.2. Prerequisites

1. DevOps engineer will create Athena DB (`<usecase>_data_quality`) by terraform IAC  as a part of framework repository
2. DevOps engineer will create SSM Parameter by terraform IAC in parameter store as a part of framework
    **Parameter name:** `/<usecase_name>/dev/<workflow_name>/expected_dq_job_cnt` (This variable signifies the number of DQ jobs that needs to be executed in a workflow) . This is required for sending consolidated email when all the dq jobs in a glue workflow finished processing
    **Note:** Please make sure to update the terraform variable `expected_dq_job_count` in the file [env/dev/dev.tfvars.json](env/dev/dev.tfvars.json) for dev environment. Please update in respective envirionment files for their respective envirionments
3. DevOps engineer will create Email SNS topic needs to be created by Terraform IAC to send the email notifications
4. Data engineer will create Email distribution list as part of SNS topic subscription where all the email needs to sent out for notification
5. All the glue job should have permission to access the parameter in ssm parameter store and email sns topic
6. Analytics glue job role should be included for the `cross account role` in `eap bucket policy` - This should be part of terraform code in the git repository - [eap-shared-core](https://github.com/MSIL-Analytics-ACE/eap-shared-core)
7. All the helper code should be there in the S3 bucket

### 1.2.3. Information required from Developer/Business

DQ rules information must be in the following format

|UseCase **** |Source |Target table |Column **** |Rule |
|--- |--- |--- |--- |--- |
|SPRS |price |mspr_pric_incremental |pric_part_id |Not NULL |
|SPRS |price |mspr_pric_incremental |pric_type |String & Not NULL |
|SPRS |price |mspr_pric_incremental |pric_eff_from |Not Null |

1. Email Distribution list that needs to be added as part of subscription in the Email SNS topic
2. Identifying  the number of Data quality jobs to be created. Based on this , ssm parameter needs to be updated in terraform env variables

### 1.2.4. Steps to be followed for creating etl dataquality glue jobs

Data Engineer needs to follow the below steps to deploy the data quality glue jobs

**Template repository link** : `https://github.com/MSIL-Analytics-ACE/template-bu-use-case-dapm-framework`

Please refer the DataQuality boiler plate code placed on the path (analytics-etl) and create the .py in your usecase repository in analytics-etl folder by the naming convention `<usecasename>_<source_name>_data_quality.py` ( all in lowercase letters)

Boiler plate code location: [analytics-etl](analytics-etl)

| Job Name | Function |
| --- | --- |
|[sample_dq_from_athena_source.py](analytics-etl/sample_dq_from_athena_source.py)|Boiler plate code to perform data quality on athena as a source|
|[sample_dq_from_redshift_source.py](analytics-etl/sample_dq_from_redshift_source.py)|Boiler plate code to perform data quality on redshift table as a source |
|[sample_dq_from_s3_csv_source.py](analytics-etl/sample_dq_from_s3_csv_source.py)|Boiler plate code to perform data quality on s3csv files as a source |
|[sample_dq_from_s3_parquet_source.py](analytics-etl/sample_dq_from_s3_parquet_source.py)| Boiler plate code to perform data quality on s3 parquet files as a source|

1. Now , base glue job for data quality by the naming convention `<usecasename>_<source_name>_data_quality.py`  is created

2. In the job `<usecasename>_<source_name>_data_quality.py`: please look for this comment "### TO BE MODIFIED BY DEV : Parameters to read the source data into the glue dataframe" and update the Data quality glue job code by changing the following parameters:

- **column_list**  - This python variable contains the comma separated string of required column names on which data quality needs to be applied . This includes key columns which are required to identify any single record (it is needed for debugging)

```python
 column_list = 'CLAM_DEIND,CLAM_DELR_CD,CLAM_FOR_CD,CLAM_OUTLET_CD,CLAM_DUP_SL_NO,CLAM_ISSUE_NO,CLAM_SRATR_DATE,CLAM_CREDIT_AMT,concat(CLAM_DEIND,CLAM_DELR_CD,CLAM_FOR_CD,CLAM_OUTLET_CD,CLAM_DUP_SL_NO,CLAM_ISSUE_NO) as concat_primary'
```

- **evaluate_dataquality_ruleset** - This python variable provide the data quality rules in the string format. Please refer the link to understand the dictionary of rules syntax - <https://docs.aws.amazon.com/glue/latest/dg/dqdl.html>

```python
             evaluate_dataquality_ruleset = """
                Rules = [
                    IsPrimaryKey "concat_primary",
                    (IsComplete "CLAM_DEIND"),
                    ColumnDataType "CLAM_SRATR_DATE" = "Date",
                    ColumnValues "CLAM_SRATR_DATE" between "2015-01-01" and now(),
                    ColumnDataType "CLAM_CREDIT_AMT" = "Float" ]
                """
```

1. To deploy the Data quality job , glue job configuration needs to provided in the `glue_jobs.config.json` in the respective environment’s envronment variable

    **Dev** : [env/dev/glue_jobs.config.json](env/dev/glue_jobs.config.json)
    **UAT** : [env/uat/glue_jobs.config.json](env/uat/glue_jobs.config.json)
    **Prod** : [env/prod/glue_jobs.config.json](env/prod/glue_jobs.config.json)
    *Following paramters should be part of the  glue job confirguration.*

2. Below is the sample json structure that needs to be included in the [env/glue_jobs.config.json](env/glue_jobs.config.json) for passing the GLue data quality jobs config

- Jobs config for `Athena` as a source

```json
     "jobs": {
            "<usecase><source_name>data_quality_athena": {
                "file_name": "sample_dq_from_athena_source.py",
                "description": "",
                "glue_version": "3.0",
                "role_arn": "arn:aws:iam::${tfvars_account_number}:role/sprs-dev-apsouth1-dapf-analytics-etl-glue-job-role",
                "number_of_workers": 10,
                "worker_type": "G.1X",
                "timeout": 2880,
                "connections": [],
                "type": "glueetl",
                "python_version": "3",
                "default_arguments": {
                    "—region": "${tfvars_region}",
                    "—enable-glue-datacatalog": "true",
                    "—job-bookmark-option": "job-bookmark-disable",
                    "—TempDir": "s3://${tfvars_analytics_internal_bucket}/temporary/",
                    "—email_ssn_topic_arn": "${tfvars_common_sns_topic}",
                    "—dqjob_cnt_parameter_name": "${tfvars_workflow_count_ssm_param_name}",
                    "—enable-metrics": "true",
                    "—enable-spark-ui": "true",
                    "—extra-py-files": "s3://${tfvars_analytics_internal_bucket}/src/python/utils/dataquality_helper_functions.py,s3://${tfvars_analytics_internal_bucket}/src/python/utils/ddb_helper_functions.py",
                    "—source_table": "spr_de_mspr_pric",
                    "—spark-event-logs-path": "s3://${tfvars_analytics_internal_bucket}/sparkHistoryLogs/",
                    "—enable-job-insights": "true",
                    "—consolidated_dq_table": "dqresults",
                    "—additional-python-modules": "pythena==1.6.0,ndjson==0.3.1",
                    "—WORKFLOW_NAME": "test_wf",
                    "—conf": "spark.sql.legacy.parquet.int96RebaseModeInRead=CORRECTED —conf spark.sql.legacy.parquet.int96RebaseModeInWrite=CORRECTED —conf spark.sql.legacy.parquet.datetimeRebaseModeInRead=CORRECTED",
                    "—source_database_name": "msil_spare_pricing_sample_data_db",
                    "—enable-continuous-cloudwatch-log": "true",
                    "—dq_athena_db": "${tfvars_dq_athena_db}",
                    "—dq_bucket": "${tfvars_dq_s3_bucket}",
                    "—job-language": "python",
                    "—usecase_name": "${tfvars_use_case_name}",
                    "—WORKFLOW_RUN_ID": "test_wf_id_comp_3.1",
                    "—eap_central_bucket": "${tfvars_eap_dq_bucket_name}"
                },
                "execution_property": {
                    "max_concurrent_runs": 1
                }
        }
    }
```

**Note**: Only following parameters need to change for the config of Athena as source

- `source_table`: This is the name of the athena table
- `source_database_name`: This is the name of the athena database

- Jobs config for `Redshift` as a source

```json
        {
            "jobs": {
                "<usecase><source_name>data_quality_redshift": {
                    "file_name": "sample_dq_from_redshift_source.py",
                    "description": "",
                    "glue_version": "3.0",
                    "role_arn": "arn:aws:iam::${tfvars_account_number}:role/aws-glue-dq-role",
                    "number_of_workers": 3,
                    "worker_type": "G.1X",
                    "timeout": 10,
                    "connections": [],
                    "type": "glueetl",
                    "python_version": "3",
                    "default_arguments": {
                        "—region": "${tfvars_region}",
                        "—enable-glue-datacatalog": "true",
                        "—job-bookmark-option": "job-bookmark-disable",
                        "—TempDir": "s3://${tfvars_analytics_internal_bucket}/temporary/",
                        "—email_ssn_topic_arn": "${tfvars_common_sns_topic}",
                        "—dqjob_cnt_parameter_name": "${tfvars_workflow_count_ssm_param_name}",
                        "—enable-metrics": "true",
                        "—enable-spark-ui": "true",
                        "—extra-py-files": "s3://${tfvars_analytics_internal_bucket}/src/python/utils/dataquality_helper_functions.py,s3://${tfvars_analytics_internal_bucket}/src/python/utils/ddb_helper_functions.py",
                        "—source_table": "gm_var_dedup",
                        "—spark-event-logs-path": "s3://${tfvars_analytics_internal_bucket}/sparkHistoryLogs/",
                        "—enable-job-insights": "true",
                        "—consolidated_dq_table": "dqresults",
                        "—additional-python-modules": "pythena==1.6.0,ndjson==0.3.1",
                        "—conf": "spark.sql.legacy.parquet.int96RebaseModeInRead=CORRECTED —conf spark.sql.legacy.parquet.int96RebaseModeInWrite=CORRECTED —conf spark.sql.legacy.parquet.datetimeRebaseModeInRead=CORRECTED",
                        "—source_database_schema_name": "aws_transform_zone_mdm",
                        "—enable-continuous-cloudwatch-log": "true",
                        "—dq_athena_db": "${tfvars_dq_athena_db}",
                        "—dq_bucket": "${tfvars_dq_s3_bucket}",
                        "—job-language": "python",
                        "—usecase_name": "${tfvars_use_case_name}",
                        "—eap_central_bucket": "${tfvars_eap_dq_bucket_name}",
                        "—secret_name": "mlops-eap"
                    },
                    "execution_property": {
                        "max_concurrent_runs": 1
                    }
                }
            }
        }
```

**Note**: Only following parameters need to change for the config of Redshift as source

- `source_database_schema_name`: This is the name of the Redshift table
- `source_table`: This is the name of the Redshift database
- `secret_name`: This is the name of the secret which stores the Redshift credentials with the given keys
  {"DB_DBNAME":"","DB_HOST":"","DB_PORT":"","DB_PWD":"","DB_USERNAME":""}

- Jobs config for `S3 csv file` as a source

```json
        {
            "jobs": {
                "<usecasename><source_name>data_quality_s3_csv": {
                    "file_name": "sample_dq_from_s3_csv_source.py",
                    "description": "",
                    "glue_version": "3.0",
                    "role_arn": "arn:aws:iam::${tfvars_account_number}:role/aws-glue-dq-role",
                    "number_of_workers": 3,
                    "worker_type": "G.1X",
                    "timeout": 10,
                    "connections": [],
                    "type": "glueetl",
                    "python_version": "3",
                    "default_arguments": {
                        "—region": "${tfvars_region}",
                        "—enable-glue-datacatalog": "true",
                        "—job-bookmark-option": "job-bookmark-disable",
                        "—TempDir": "s3://${tfvars_analytics_internal_bucket}/temporary/",
                        "—email_ssn_topic_arn": "${tfvars_common_sns_topic}",
                        "—dqjob_cnt_parameter_name": "${tfvars_workflow_count_ssm_param_name}",
                        "—enable-metrics": "true",
                        "—enable-spark-ui": "true",
                        "—extra-py-files": "s3://${tfvars_analytics_internal_bucket}/src/python/utils/dataquality_helper_functions.py,s3://${tfvars_analytics_internal_bucket}/src/python/utils/ddb_helper_functions.py",
                        "—spark-event-logs-path": "s3://${tfvars_analytics_internal_bucket}/sparkHistoryLogs/",
                        "—enable-job-insights": "true",
                        "—consolidated_dq_table": "dqresults",
                        "—additional-python-modules": "pythena==1.6.0,ndjson==0.3.1",
                        "—conf": "spark.sql.legacy.parquet.int96RebaseModeInRead=CORRECTED —conf spark.sql.legacy.parquet.int96RebaseModeInWrite=CORRECTED —conf spark.sql.legacy.parquet.datetimeRebaseModeInRead=CORRECTED",
                        "—enable-continuous-cloudwatch-log": "true",
                        "—dq_athena_db": "${tfvars_dq_athena_db}",
                        "—dq_bucket": "${tfvars_dq_s3_bucket}",
                        "—job-language": "python",
                        "—usecase_name": "${tfvars_use_case_name}",
                        "—eap_central_bucket": "${tfvars_eap_dq_bucket_name}",
                        "—input_file_path": "s3://sample_bucket_name/sample_folder_name"
                    },
                    "execution_property": {
                        "max_concurrent_runs": 1
                    }
                }
            }
        }
```

**Note**: Only following parameters need to change for the config of S3 csv file as source

- `input_file_path`: This is the path of the csv file. Data Engineer can either provide exact file path inclusing csv file name or can provide the folder path in which csv is stored.

- Jobs config for `S3 parquet file` as a source

```json
        {
            "jobs": {
                "<usecasename><source_name>data_quality_s3_parquet": {
                    "file_name": "sample_dq_from_s3_parquet_source.py",
                    "description": "",
                    "glue_version": "3.0",
                    "role_arn": "arn:aws:iam::${tfvars_account_number}:role/aws-glue-dq-role",
                    "number_of_workers": 3,
                    "worker_type": "G.1X",
                    "timeout": 10,
                    "connections": [],
                    "type": "glueetl",
                    "python_version": "3",
                    "default_arguments": {
                        "—region": "${tfvars_region}",
                        "—enable-glue-datacatalog": "true",
                        "—job-bookmark-option": "job-bookmark-disable",
                        "—TempDir": "s3://${tfvars_analytics_internal_bucket}/temporary/",
                        "—email_ssn_topic_arn": "${tfvars_common_sns_topic}",
                        "—dqjob_cnt_parameter_name": "${tfvars_workflow_count_ssm_param_name}",
                        "—enable-metrics": "true",
                        "—enable-spark-ui": "true",
                        "—extra-py-files": "s3://${tfvars_analytics_internal_bucket}/src/python/utils/dataquality_helper_functions.py,s3://${tfvars_analytics_internal_bucket}/src/python/utils/ddb_helper_functions.py",
                        "—spark-event-logs-path": "s3://${tfvars_analytics_internal_bucket}/sparkHistoryLogs/",
                        "—enable-job-insights": "true",
                        "—consolidated_dq_table": "dqresults",
                        "—additional-python-modules": "pythena==1.6.0,ndjson==0.3.1",
                        "—conf": "spark.sql.legacy.parquet.int96RebaseModeInRead=CORRECTED —conf spark.sql.legacy.parquet.int96RebaseModeInWrite=CORRECTED —conf spark.sql.legacy.parquet.datetimeRebaseModeInRead=CORRECTED",
                        "—enable-continuous-cloudwatch-log": "true",
                        "—dq_athena_db": "${tfvars_dq_athena_db}",
                        "—dq_bucket": "${tfvars_dq_s3_bucket}",
                        "—job-language": "python",
                        "—usecase_name": "${tfvars_use_case_name}",
                        "—eap_central_bucket": "${tfvars_eap_dq_bucket_name}",
                        "—input_file_path": "s3://sample_bucket_name/sample_folder_name"
                    },
                    "execution_property": {
                        "max_concurrent_runs": 1
                    }
                }
            }
        }
```

**Note**: Only following parameters need to change for the config of S3 parquet file as source

- `input_file_path`: This is the path of the parquet file. Data Engineer can either provide exact file path inclusing csv file name or can provide the folder path in which csv is stored.

Below are the details with paramters names , description of their purpose and origin who will provide the value.

|*Parameter* |*SampleValue* |*Description* |*ValueProvider* |
|--- |--- |--- |--- |
|—WORKFLOW_NAME | |*This is the value of the glue workflow name of which dq job is a part of* |*Glue Workflow* |
|*—WORKFLOW_RUN_ID* | |*This is the workflow run id of the glue workflow of which dq job is a part of* |*Glue Workflow* |
|—additional-python-modules |*pythena==1.6.0,ndjson==0.3.1* |*Python libraries which are requried to downloaded as a part of this glue job* |*Terraform IAC* |
|*—conf* |*spark.sql.legacy.parquet.int96RebaseModeInRead=CORRECTED —conf spark.sql.legacy.parquet.int96RebaseModeInWrite=CORRECTED —conf spark.sql.legacy.parquet.datetimeRebaseModeInRead=CORRECTED* |*Confirguration value to read older parquet files* |*Terraform IAC* |
|—consolidated_dq_table |*dqresults* |*Name of data quality table having consolidated data* |*Terraform IAC* |
|*—dq_athena_db* |*<usecase_name>_data_quality* |*Name of athena database in which all the detailed and consolidated tables will be created* |*Terraform IAC* |
|*—dq_bucket* |*<usecase_name>-<region>-analytics-etl* |*Name of the same account bucket where the outputs will be stored* |*Terraform IAC* |
|*—dqjob_cnt_parameter_name* |*/<usecase_name>-ssm/analytics-etl/expected_dq_job_cnt* |*Name of the ssm parameter having the count of total data quality jobs* |*Terraform IAC* |
|*—eap_central_bucket* |*eap-dev-apsouth1-glue-cross-account-bucket* |*Name of the EAP cross account bucket where the dq outputs will be stored* |*Terraform IAC* |
|*—email_ssn_topic_arn* |*arn:aws:sns:ap-south-1:<account_id>:<usecase_name>-apsouth1-dapf-notifier* |*Name of email sns topic which is used to send the email notifications* |*Terraform IAC* |
|*—region* |ap-south-1 |*Name of the region in which all the resources are deployed* |*Terraform IAC* |
|*—source_database_nam* |*dcp_amlgolabs* |*Name of the athena source database which is having the source table on which DQ needs to be applied* |*Terraform IAC* |
|*—source_table* |*mwar_clam* |*Name of the actual athena source table on which DQ needs to be applied* |*Terraform IAC* |
|*—usecase_name* |dcp |*Name of the usecase which will be used for segregating dq results in the cross account bucket* |*Terraform IAC* |
|*—extra-py-files* |*${tfvars_analytics_internal_bucket}/src/python/utils/dataquality_helper_functions.py,s3://${tfvars_analytics_internal_bucket}/src/python/utils/ddb_helper_functions.py* |*Helper functions locations* |*Terraform IAC* |

1. **Workflow of ETL Data quality jobs:** Data engineer to ensure that these etl data quality jobs shold be the part of mail ETL workflow for them to run as per the required schedule in order to ensure that ETL should not proceed if ETL job fails
2. **Deployment of ETL Data quality and analytics jobs:**
    Data engineer to place the following configuration in tfvars.json for deployment of anlytics etl and data quality jobs

    **expected_dq_job_count**: This is the variable created to provide the count of total data quality jobs in a workflow
    **glue_config_paths** : This is the list type variable created to add the config json files for job and workflow creation

    **Sample Value:**

    ```json
        "analytics_etl": {
            "expected_dq_job_count": 5,
                "glue_config_paths": [
                    "env/dev/glue_jobs.config.json",
                    "env/dev/glue_wf.config.json"
                ]
        }
    ```

    **Note**: Please ensure to provide all the config as per the the specific envirionment

    **Dev tfvar**: [env/dev/dev.tfvars.json](env/dev/dev.tfvars.json)
    **UAT tfvar**: [env/uat/uat.tfvars.json](env/uat/uat.tfvars.json)
    **Prod tfvar**: [env/prod/prod.tfvars.json](env/prod/prod.tfvars.json)

### 1.2.5. Success criteria for Data Quality Jobs

1. Data is getting loaded in the same account athena tables in the athena database: - `<usecase><environment>_<region>_data_quality`

    a. Consolidated data quality results table  - dqresults
    b. Detailed data quality results table : Name of the table would be same as the source provided

2. Data is getting generated in the cross account bucket in EAP bucket - eap-dev-apsouth1-glue-cross-account-bucket
3. Try running the crawler "eap-dev-apsouth1-data-quality-monitoring" and validate  if the same data is showing in the EAP athena table `"eap-dev-apsouth1-dashboard-monitoring-db"."etl_data_quality"`
4. Ensure that Notification Emails are getting sent after completion of entire workflow

**References for writing DQ rules in ETL data quality glue job:**

1. Working with Glue DQ in glue notebook - <https://docs.aws.amazon.com/glue/latest/ug/data-quality-notebooks.html>
2. Glue DQ - <https://docs.aws.amazon.com/glue/latest/dg/data-quality.html>
3. Data Quality definition languages - <https://docs.aws.amazon.com/glue/latest/dg/dqdl.html>
