import argparse
import logging
import time
import boto3
import sys
import pandas as pd
import traceback
from utils.ddb_helper_functions import upload_file, read_json_from_s3, read_ssm_store, update_ssm_store
from utils.inference_dynamodb_model import InferenceMetaDataModel, InferenceInputDataModel, Timelaps
import awswrangler as wr
import yaml
import os

# import argparse
# import logging
# import time
# import boto3
# import pandas as pd
# from sklearn.preprocessing import MinMaxScaler
# from model.utils.ddb_helper_functions import  upload_file, read_json_from_s3
# from model.utils_inference.inference_dynamodb_model import InferenceMetaDataModel, InferenceInputDataModel, Timelaps
##################
log = logging.getLogger("inferencing_preprocessing")
# logging.basicConfig(format='%(asctime)s - %(filename)s - %(funcName)s %(lineno)d -- %(message)s', level=logging.INFO)
logging.basicConfig(format='%(levelname)-8s [%(filename)s:%(lineno)d] %(message)s',
                    datefmt='%Y-%m-%d:%H:%M',
                    level=logging.DEBUG)


def args_parse():
    """
    :return: constant, arguments
    """

    # Create the parser
    parser = argparse.ArgumentParser()
    parser.add_argument('--inference_metatable_name', type=str, required=True)
    parser.add_argument('--region', type=str, required=True)
    return parser.parse_args()

def setup(metatable):
    """
    method is assigning variable sent from Jenkins

    :return: Bool
    """
    try:
        global year, month, day, framework_analytical_dataset_bucket, stepjobid, internal_bucket_name
        year = metatable.inference_execution_year
        month = metatable.inference_execution_month
        day = metatable.inference_execution_day
        stepjobid=metatable.inference_step_job_id
        framework_analytical_dataset_bucket = metatable.s3_bucket_name_internal
        internal_bucket_name = metatable.s3_bucket_name_internal

    except Exception as error:
        log.error("Error while setup variables ".format(error))
        raise Exception("Error while setting up variables in combine data source")
    return True

def combine_harmonize_data(meta_table_item) -> pd.DataFrame:
    """
     this method is a boilerplate code thus needs to be changed on the basis of business ml use case
    :param file_path:
    :return: DataFrame
    """
    setup(metatable=meta_table_item)
    # Load the configuration data from the util folder
    config_file_path = 'utils/prediction_optimization_model_config.yml'
    with open(config_file_path, 'r') as config_file:
        config_data = yaml.safe_load(config_file)

    # Construct the local path for raw data from the config
    local_path = config_data['s3']['local_path']

    _env = internal_bucket_name.split('-')[1]

    if _env == 'uat':
        local_path = local_path.replace('msil-epto-dev', 'msil-epto-uat')
    elif _env == 'prod':
        local_path = local_path.replace('msil-epto-dev', 'msil-epto-prod')

    # Read raw data from Parquet file
    raw_data_file = os.path.join(local_path)
    raw_data = pd.read_parquet(raw_data_file)

    # Extract input columns based on input_columns_param_range
    input_columns = config_data['input_columns_param_range'].keys()

    # Extract output columns
    output_columns = config_data['assembly_output'].keys()

    # Filter raw data based on input column ranges
    for column, param_range in config_data['input_columns_param_range'].items():
        raw_data = raw_data[(raw_data[column] >= param_range[0]) & (raw_data[column] <= param_range[1])]


    # Select only the relevant columns from the filtered DataFrame
    selected_columns = list(input_columns) + list(output_columns)
    combined_df = raw_data[selected_columns]

    # Reshape the DataFrame
    combined_df = pd.melt(combined_df, id_vars=input_columns, value_vars=output_columns, var_name='assembly_output', value_name='output_value')
    
    combined_data_destination_path = f"s3://{framework_analytical_dataset_bucket}/analytical_data/year={year}/month={month}/day={day}/stepjobid={stepjobid}/"
    wr.s3.to_parquet(
        df=combined_df,
        path=combined_data_destination_path,
        dataset=True,
        index=False
        )
    return combined_df, combined_data_destination_path

def ml_preprocessing(combined_dataframe, mapping_id) -> pd.DataFrame:
    """
    this method is a boilerplate code thus needs to be changed on the basis of business ml use case
    :param combined_dataframe: dataset dataframe after combining data from different source
    :param mapping_id: mappingid is comming from mapping json file ,value can be "default","region" etc
    :return: DataFrame
    """
    df = combined_dataframe
    df_column_filter_list = ['crank_journal_bore_measurement_1j_main',
                            'crank_journal_bore_measurement_2j_main',
                            'crank_journal_bore_measurement_3j_main',
                            'crank_journal_bore_measurement_4j_main',
                            'crank_journal_bore_measurement_5j_main',
                            'crank_shaft_j_dia_mean_value_mean', 'thurst_width',
                            'no1_bore_measurement_value', 'no2_bore_measurement_value',
                            'no3_bore_measurement_value', 'no4_bore_measurement_value', 'j1f_dia',
                            'cam_shaft_measurement_dia_crank_mean_value_mean',
                            'crank_shaft_p_dia_mean_value_mean',
                            'cylinder_head_cam_hole_in_mean_value_mean',
                            'cylinder_head_cam_hole_ex_mean_value_mean',
                            'rotor_press_fitting_angle', 'cam_shaft_measurement_c_mean_value_mean',
                            'cam_shaft_measurement_ca_mean_value_mean', 'p1_half_storke',
                            'p2_half_storke', 'p3_half_storke', 'p4_half_storke', 'assembly_output',
                            'output_value','mapping',mapping_id]
    df = df[df_column_filter_list]
    return df




def insert_inference_job_def_input_table(pk_mappingid, step_job_id, usecase_name,
                                         execution_year, execution_month, execution_day, pkid,
                                         mapping_id, mapping_json_s3_path, algo_names,
                                         s3_pk_mappingid_data_input_path, s3_output_bucket_name,
                                         batch_job_definition, batch_job_status_overall, input_data_set,
                                         meta_table_item,
                                         s3_pk_mapping_model_prefix_input_path,
                                         recursive_run=0,
                                         **kwargs
                                         ) -> int:
    """
    Takes input all columns and saves data in TrainInput DDB Table
    :param pk_mappingid: pk|mapping_id( primary key)
    :param step_job_id:
    :param usecase_name:
    :param execution_year: yyyy
    :param execution_month: mm
    :param execution_day: dd
    :param pkid: unique string
    :param mapping_id:
    :param algo_execution_status:
    :param s3_pk_mappingid_data_input_path:
    :param s3_output_bucket_name:
    :param batch_job_definition: algo_names:
    :param batch_job_status_overall:
    :param meta_table_item:
    **kwargs
    :return: exit code
    """
    log.info(
        " About to insert into Input DynamoDB table for partition key {} and reursive num runs {},meta_table_item {}".format(
            pk_mappingid,
            recursive_run,
            meta_table_item))
    try:
        InferenceInputDataModel(pk_mappingid=pk_mappingid,
                                inference_step_job_id=step_job_id,
                                training_step_job_id=meta_table_item.training_step_job_id,

                                inference_usecase_name=usecase_name,
                                inference_execution_year=execution_year,
                                inference_execution_month=execution_month,
                                inference_execution_day=execution_day,

                                training_execution_year=meta_table_item.training_execution_year,
                                training_execution_month=meta_table_item.training_execution_month,
                                training_execution_day=meta_table_item.training_execution_day,
                                pk=pkid,
                                mapping_id=mapping_id,
                                mapping_json_s3_inference_path=mapping_json_s3_path,
                                mapping_json_s3_training_path=meta_table_item.mapping_json_s3_training_path,

                                inference_input_data_set=input_data_set,

                                inference_algo_names=algo_names,
                                training_algo_names=meta_table_item.training_algo_names,

                                s3_pk_mappingid_data_input_path=s3_pk_mappingid_data_input_path,
                                s3_pk_mapping_model_prefix_input_path=s3_pk_mapping_model_prefix_input_path,
                                s3_output_bucket_name=s3_output_bucket_name,
                                batch_job_definition=batch_job_definition,
                                batch_job_status_overall=batch_job_status_overall,
                                ).save()

    except Exception as error:
        logging.error(error)
        if recursive_run == 3:
            return False
        time.sleep(1)
        insert_inference_job_def_input_table(pk_mappingid, step_job_id, usecase_name,
                                             execution_year, execution_month, execution_day, pkid,
                                             mapping_id, mapping_json_s3_path, algo_names,
                                             s3_pk_mappingid_data_input_path, s3_output_bucket_name,
                                             batch_job_definition, batch_job_status_overall, input_data_set,
                                             meta_table_item,
                                             s3_pk_mapping_model_prefix_input_path,
                                             recursive_run + 1)

    return True


if __name__ == "__main__":
    try:
        pre_processing_start_epoch = int(time.time())
        s3_client = boto3.client('s3')

        args = args_parse()
        log.info("Preprocessing Arguments {}".format(args))
        # Meta Table name and Region required to instantiate TrainingMetaDataModel
        InferenceMetaDataModel.setup_model(
            InferenceMetaDataModel, args.inference_metatable_name, args.region)
        meta_item = InferenceMetaDataModel.get("fixedlookupkey")
        InferenceInputDataModel.setup_model(
            InferenceInputDataModel, meta_item.inference_inputtable_name, meta_item.region)


        # DynamoDB Table Creation
        if not InferenceInputDataModel.exists():
            log.info("Creating InferenceInputDataModel...")
            InferenceInputDataModel.create_table(
                read_capacity_units=100, write_capacity_units=100)
            time.sleep(10)
            
        # Read mapping json from Amazon S3
        mapping_json_constants = read_json_from_s3(meta_item.mapping_json_s3_inference_path, s3_client)
        primaryKey = mapping_json_constants["mapping_json_data"]["primary_key"]
        mapping_id = mapping_json_constants["mapping_json_data"]['Inference']["mappingColumn"]

        # Input Path for Preprocessing Jo
        
        combined_df, analytical_data_path = combine_harmonize_data(meta_table_item=meta_item)
        
        logging.info(f"Mapping Id is: {mapping_id}")
        if mapping_id == "default":
            combined_df['mapping'] = 'default'
        else:
            combined_df['mapping'] = combined_df[mapping_id]
        
        combined_df[mapping_id] = combined_df["mapping"]   
        ml_dataset = ml_preprocessing(combined_df, mapping_id)
        

        # "this will be used in in_path"
        s3_preprocessing_prefix_output_path = "s3://{}/preprocessing/year={}/month={}/day={}/stepjobid={}/smid={}/".format(
            meta_item.s3_bucket_name_shared,
            meta_item.inference_execution_year,
            meta_item.inference_execution_month,
            meta_item.inference_execution_day,
            meta_item.inference_step_job_id,
            meta_item.inference_step_job_id)
        log.info('s3_preprocessing_prefix_output_path  {}'.format(
            s3_preprocessing_prefix_output_path))
        log.info('mapping inference path {}'.format(
            meta_item.mapping_json_s3_inference_path))

        ml_dataset["pk"] = ml_dataset[primaryKey]
        ml_dataset["pk"] = ml_dataset["pk"].apply(lambda x : ''.join(letter for letter in x if letter.isalnum()))

        log.info("ML Dataset record count per pk and mapping")
        log.info(ml_dataset.groupby(["pk", mapping_id]).size())

        ml_dataset.to_parquet(s3_preprocessing_prefix_output_path,
                              partition_cols=["pk", "mapping"])
        try:
            log.info("primaryKey:{},mapping_id:{}".format(primaryKey, mapping_id))
            if mapping_id == "default":
                filtered_data = ml_dataset.drop_duplicates(
                    subset=[primaryKey], keep="last")
            else:
                filtered_data = ml_dataset.drop_duplicates(
                    subset=[primaryKey, mapping_id], keep="last")
        except Exception as error:
            raise Exception(
                "Inference DataSet does not contain mapping or primarykey column as mentioned in Mapping Json")

        ################### Custom Business Logic from below #######################################

        total_num_training_jobs = 0
        log.info("Total {} Jobs will be submitted".format(filtered_data.shape[0]))

        meta_data = InferenceMetaDataModel.get("fixedlookupkey")
        s3_pk_mapping_model_prefix_input_path = meta_data.training_prefix_path_from_ssm
              
        for index, row in filtered_data.iterrows():

            total_num_training_jobs = total_num_training_jobs + 1
            if mapping_json_constants['mapping_json_data']['Inference']['all_algorithms']:
                algo_names = mapping_json_constants['mapping_json_data']['Inference']['all_algorithms']

            else:
                algo_names = mapping_json_constants['mapping_json_data']['Inference']['mapping'][row[mapping_id]]

            # "smid is same as step function id"
            s3_pk_mappingid_data_input_path = (
                "s3://{}/preprocessing/year={}/month={}/day={}/stepjobid={}/smid={}/pk={}/mapping={}/").format(
                meta_item.s3_bucket_name_shared,
                meta_item.inference_execution_year,
                meta_item.inference_execution_month,
                meta_item.inference_execution_day,
                meta_item.inference_step_job_id,
                meta_item.inference_step_job_id,
                row.pk,
                row[mapping_id])

            aws_batch_job_definition = meta_item.aws_batch_job_definition

            status_input_job = insert_inference_job_def_input_table(pk_mappingid=row.pk + "|" + row[mapping_id],
                                                                    step_job_id=meta_item.inference_step_job_id,
                                                                    usecase_name=meta_item.inference_usecase_name,
                                                                    execution_year=meta_item.inference_execution_year,
                                                                    execution_month=meta_item.inference_execution_month,
                                                                    execution_day=meta_item.inference_execution_day,
                                                                    pkid=row.pk,
                                                                    mapping_id=row[mapping_id],
                                                                    mapping_json_s3_path=meta_item.mapping_json_s3_inference_path,
                                                                    algo_names=algo_names,
                                                                    s3_pk_mappingid_data_input_path=s3_pk_mappingid_data_input_path,
                                                                    s3_output_bucket_name=meta_item.s3_bucket_name_shared,
                                                                    batch_job_definition=aws_batch_job_definition,
                                                                    batch_job_status_overall="TO_BE_CREATED",
                                                                    input_data_set=[
                                                                        analytical_data_path],
                                                                    meta_table_item=meta_data,
                                                                    s3_pk_mapping_model_prefix_input_path=s3_pk_mapping_model_prefix_input_path)

            if not status_input_job:
                raise Exception("Preprocessing failed!")

        pre_processing_end_epoch = int(time.time())

        meta_item.preprocessing_timelaps = Timelaps(start_time=pre_processing_start_epoch,
                                                    end_time=pre_processing_end_epoch)
        meta_item.input_data_set = [analytical_data_path]
        meta_item.features_dq_input_path = analytical_data_path
        meta_item.algo_names = algo_names
        meta_item.preprocessing_total_batch_jobs = total_num_training_jobs
        meta_item.s3_preprocessing_prefix_output_path = s3_preprocessing_prefix_output_path
        meta_item.save()
        
        logging.info("Inference Preprocessing done!!")
        
    except Exception as error:
        log.error("Error ->{}".format(error))
        traceback.print_exc()
        log.info("Inference Preprocessing Job failed to Complete!")
        sys.exit(1)

