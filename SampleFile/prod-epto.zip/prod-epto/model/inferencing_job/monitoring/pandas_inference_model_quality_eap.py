"""
Hard dependencies:
1. Input file needs to be uploaded on s3://<usecase>-<env>-apsouth1-inferencing-shared/model-quality-input/model_quality_input_file.csv.
    This static file is placed in the git repo at the path /model/model_quality_input_file.csv
2. Threshold file needs to be added by terraform at the path s3://<usecase>-<env>-apsouth1-inferencing-shared/src/python/monitoring/model_quality_threshold.csv
    Sample threshold file is palced in git repo at the path /env/<environment>/model_quality_threshold.csv
3. Helper function should be added by terraform at the path s3://{bucketname}/utils/model_quality_helper_functions.py

1. CSV file to be generated in S3 bucket in hive style partiion which contains both predicted and actual data in a single file . 
    For now , static file is being used as an input
    ColumnList of the expected csv : Algorithm,actual_column , predicted_column
2. Athena DB to be created IAC - usecasename_monitoring
3. Threshold file needs to be provided  on the path specified in the glue parameters
"""
import time
import boto3
import sys
import logging
import traceback
from sklearn.metrics import mean_absolute_percentage_error
from model_quality_helper_functions import rsqr_calc 
import pandas as pd
from awsglue.utils import getResolvedOptions
import awswrangler as wr
import numpy as np
import boto3
from datetime import date , datetime
import boto3
  

log = logging.getLogger(__name__)
logging.basicConfig(format='%(asctime)s :: %(message)s', level=logging.INFO)
logging.info("info")

pd.set_option('display.max_columns', None)





if __name__ == "__main__":
    log.info("Entered the main function")
    try:
        args = getResolvedOptions(sys.argv,
                                  ['inferencing_shared_bucketname',
                                  'threshold_data_path',
                                  'eap_central_bucket',
                                  'model_quality_prefix',
                                  'WORKFLOW_RUN_ID',
                                  'source',
                                  'usecase_name',
                                  'solution_type',
                                  'solution_category',
                                    'retraining_lambda_arn',
                                    'auto_training_flag',
                                    'rsqr_threshold',
                                    'mape_threshold'])
        
        inferencing_shared_bucketname=args['inferencing_shared_bucketname']
        threshold_data_path=args['threshold_data_path']
        
        eap_central_bucket=args['eap_central_bucket']
        model_quality_prefix=args['model_quality_prefix']
        corelation_id=args['WORKFLOW_RUN_ID']
        source=args['source']
        usecase_name=args['usecase_name']
        solution_type=args['solution_type']
        solution_category=args['solution_category']
        
        ####Capture retaining lambda inputs
        auto_training_flag = args['auto_training_flag']
        retraining_lambda_arn = args['retraining_lambda_arn']
        
        ####Capture Metric threshold values when retraining_lambda_arn = true  
        # by Developer
        rsqr_threshold = args['rsqr_threshold']
        mape_threshold = args['mape_threshold']
        
        todays_date = date.today()
        year =  todays_date.year
        month = todays_date.month
        day = todays_date.day
    
        month = str(month)
        len_month= len(month)
        
        if len_month <2:
            month= '0'+month
        
        metric_dict = {}
        
        ############################################################################################################
        """
         by Developer (Future Backlog): Need to make it generic path once the pipeline is in place to generate 
        these static files which contains actual and predicted values.
        Currently it has been decided by MSIL to use the static file as an input for model quality
        """
        input_file_path = f's3://{inferencing_shared_bucketname}/model-quality-input/' #static file path
        log.info(f"Input_path: {input_file_path}")
        input_df = wr.s3.read_csv(path=input_file_path)
        log.info(f"Created the pandas dataframe from the csv placed in the path :{input_file_path}")
        
        input_df = input_df.dropna()
        log.info("Filtered not null values from the column - Actual_Buy_Price")
        
        log.info(input_df.head(5))
        
        ############################################################################################################
        
        """
         by developer : 
        1. Specify the actual and predicted columns for the calcualtion of model quality metrices
        2. Specify the model metric which needs to be calcuated
        3. Call the model metric calculation functions either from sklearn standard lib or from the model quality helper function
            Reference link : https://scikit-learn.org/stable/modules/classes.html#module-sklearn.metrics
        """
        
        y_actual=input_df['mrp']
        y_pred=input_df['ml_proposed_mrp']
        
        log.info(f"Datatype of actual data : {type(y_actual)}")
        
        metric_name_list = ["mape","r2"]
        
        
        
        mape = mean_absolute_percentage_error(y_actual, y_pred)
        mape= "{:.2f}".format(mape)
        log.info(f"mape :  {mape}")
        metric_dict["mape"]=mape
        

        
        rsqr_score=rsqr_calc(y_actual,y_pred)
        log.info(f"r2 score  :  {rsqr_score}")
        metric_dict["r2"]=float(rsqr_score)
        
        log.info(f"metric_dict:{metric_dict}")
        
        df = pd.DataFrame()
        df['metric_name'] = metric_name_list
        df['actual_value'] = df['metric_name'].map(metric_dict)
        #Comment: First row is picked to get the algoname considering that only one algo is there in the production for inferencing 
        df['algoname'] = input_df['Algoname'].values[0]
        
        log.info(df)
        
        # Calling the threshold values csv
        threshold_df = wr.s3.read_csv(path=threshold_data_path)
        log.info(threshold_df)
        
        # Merge the model metric calculated values with the threshold values 
        new_enhanced_df = df.merge(threshold_df, how='right')
        
        log.info(new_enhanced_df)
        
        # Assigning the values for the required columns in final datframe which will be loading data to cross account bucket
        new_enhanced_df['status'] =  "NA"
        new_enhanced_df['audit_timestamp'] = datetime.now()
        new_enhanced_df['source'] = source
        new_enhanced_df['solution_type']=solution_type
        new_enhanced_df['solution_category']=solution_category
        
        """
         by developer: Placeholder for adding the comparison condition for each of the specified metric
        """
        for ind in new_enhanced_df.index:
            
            if new_enhanced_df['metric_name'][ind].lower() == 'mape':
                if float(new_enhanced_df['actual_value'][ind]) <= float(new_enhanced_df['base_threshold'][ind]):
                    new_enhanced_df['status'][ind] = 'Green'
                elif float(new_enhanced_df['actual_value'][ind]) > float(new_enhanced_df['base_threshold'][ind]) and float(new_enhanced_df['actual_value'][ind]) <= float(new_enhanced_df['critical_threshold'][ind]):
                    new_enhanced_df['status'][ind] = 'Amber'
                elif float(new_enhanced_df['actual_value'][ind]) > float(new_enhanced_df['critical_threshold'][ind]):
                    new_enhanced_df['status'][ind] = 'Red'
                    

                    
            if new_enhanced_df['metric_name'][ind].lower() == 'r2':
                if float(new_enhanced_df['actual_value'][ind]) >= float(new_enhanced_df['base_threshold'][ind]):
                    new_enhanced_df['status'][ind] = 'Green'
                elif float(new_enhanced_df['actual_value'][ind]) < float(new_enhanced_df['base_threshold'][ind]) and float(new_enhanced_df['actual_value'][ind]) >= float(new_enhanced_df['critical_threshold'][ind]):
                    new_enhanced_df['status'][ind] = 'Amber'
                elif float(new_enhanced_df['actual_value'][ind]) < float(new_enhanced_df['critical_threshold'][ind]):
                    new_enhanced_df['status'][ind] = 'Red'
        ############################################################################################################

        new_enhanced_df['status'] =  new_enhanced_df['status'].astype(str)
        new_enhanced_df['audit_timestamp'] = datetime.now()
        new_enhanced_df['source'] = new_enhanced_df['source'].astype(str)
        new_enhanced_df['expected_value'] = new_enhanced_df['expected_value'].astype(str)
        new_enhanced_df['expected_value'] = new_enhanced_df['expected_value'].astype(str)
        new_enhanced_df['actual_value'] = new_enhanced_df['actual_value'].astype(float)
        new_enhanced_df['algoname'] = new_enhanced_df['algoname'].astype(str)
        new_enhanced_df['base_threshold'] = new_enhanced_df['base_threshold'].astype(float)
        new_enhanced_df['critical_threshold'] = new_enhanced_df['critical_threshold'].astype(float)
        
        
        log.info(new_enhanced_df.dtypes)
        ########################################################################
        #### Write the data in parquet in cross account bucket
        dashboard_model_quality_path = f's3://{eap_central_bucket}/{model_quality_prefix}/usecase_name={usecase_name}/year={year}/month={month}/day={day}/corelation_id={corelation_id}'
        log.info("Writing the data to the cross bucket s3 path ")
        wr.s3.to_parquet(
            df=new_enhanced_df,
            path=dashboard_model_quality_path,
            dataset=True,
            mode='overwrite'
        )    
        
        log.info(f"Output data is written in parquet in cross account bucket on the path {dashboard_model_quality_path}")
        
        
        
        ########################################################################
        #### Logic for retraining lambda function 
        lambda_client = boto3.client('lambda')
        
        if auto_training_flag == "true":
            if (float(rsqr_score) > float(rsqr_threshold))or (float(mape) > float(mape_threshold)):
                response = lambda_client.invoke(
                                FunctionName=retraining_lambda_arn , Payload= '{ "region": "ap-south-1" }')
        else:
            log.info(f"By default autotraining is not enabled.Please enable it by passing the flag auto_training_flag = 'true' in environment variables ")
            
                            
        log.info(f"Invoked the Retraining lambda function:  {retraining_lambda_arn} status:{response}" )
        

    except Exception as e:
        log.info(f"Error={e}")
        raise e