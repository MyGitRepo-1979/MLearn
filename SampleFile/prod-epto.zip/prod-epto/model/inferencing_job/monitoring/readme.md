# Inferencing Model Quality

1. Sample inferencing model quality job using pandas - pandas_inference_model_quality_eap.py
2. Sample inferencing model quality job using pyspark - pyspark_inference_model_quality_eap.py



## Auto retraining

1. In order to enable auto-retraining , developer needs to pass "auto_training_flag" as "true" for the monitoring module in the 
    a. dev.tfvars.json for dev environment
    b. uat.tfvars.json for dev environment
    c. prod.tfvars.json for dev environment

2. Threshold values for the model metric needs to be passed in the tfvar 
    Naming convention for threshold variable : <metric_name>_threshold
    For eg: "intersection_threshold": 30

Sample json passed in the tfvars.json

"monitoring": {
"glue_inferencing_model_quality_params": {
      "path": "model/inferencing_job/monitoring/pyspark_inference_model_quality_eap.py",
      "additional_arguments": {
        "intersection_threshold": 30,
        "auto_training_flag": "true"
      }
      }
      

3. For the sample implementation , threshold is being passed for the metric intersection