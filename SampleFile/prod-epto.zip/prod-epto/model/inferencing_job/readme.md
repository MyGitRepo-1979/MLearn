### #Inference Job

- Please set root of SCM repository which contains util as your default workspace/ root of your project. You can do so by using [.env file](https://code.visualstudio.com/docs/python/environments#_environment-variable-definitions-file)


## Purpose of Inference


## Prerequisite to run batch framework

*** Three dynamoDB :
1. 'inference_inputtable_name'
2. 'inference_statetable_name'
3. 'inference_metatable_name'
Above tables must be present and must have zero items before starting Inference excecution otherwise results may not be statisfactory and may break the pipeline.


SSM paramter which are important to give correct inferencing from the models:

1. ssm_winning_algo_name - this parameter have information about which ML algorithm has the highest score during training.
2. ssm_approved_model_prefix_path - this parameter contains location of the all the trained models for the approved model that were approved by Lead Data Scientist/Model Approver
3. ssm_inferencing_complete_status - this parameter can be bool type string "False" or "True". "False" means during execution of SF(Step Function) all the aws submiited batch job are completed or not 
                                    if yes then value is set as "True".
                                    

*** Mapping JSON file is the source of truth for inferencing pipeline to know what algo to inference on. Algos defined in Mapping for Inferenceing must be subset of Training algorithms set.



Inference submodules:
1. gateKeeper : GateKeeper module inserts information in inference_metatable db table which is meta information which used amongs all the process and job in step function. It also do a quality check on the data.
2. monitoring : plug and play module for model and data quality for EAP dashboard.
3. preprocessing : this module is ML specific preprocessings. Three major things are happeing 
                    a. cobmining data from different sources to create one dataset for ML usecase specific
                    b. ML algorithm inclined data wrangling and transformations
                    c. Insert records in inference_inputtable_name
                    Files content in preprocessing module:
                    1. Docker
                    2. combine_source_data.py
                    3. preprocessing.py
                    4. requirements.txt
4. Inference : this module is ML code for inferencing for each spare part that runs in aws batch jobs..
                    Files content in preprocessing module:
                    1. Docker
                    2. inference.py
                    3. requirements.txt
                All inference job are submiited by inference submit glue job which is part of IAC.
                For debugging user can visit to aws console-> aws batch console -> job-> select job queue.