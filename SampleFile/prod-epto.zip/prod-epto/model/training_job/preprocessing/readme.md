Preprocessing 
