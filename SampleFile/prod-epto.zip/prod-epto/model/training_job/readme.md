# Training Job

- Please set root of SCM repository which contains util as your default workspace/ root of your project. You can do so by using [.env file](https://code.visualstudio.com/docs/python/environments#_environment-variable-definitions-file)
