# Data Drift Workflow details

## Prerequisites
1. S3 bucket "eap-dev-apsouth1-glue-cross-account-bucket" and Glue database "eap-dev-apsouth1-dashboard-monitoring-db" should already be created in the EAP account based on which quicksight dashboard will be created
2. Threshold Values needs to be provided by Business. Below is the sample provided for reference. All the 5 columns to be provided by business :
    | --- | --- | --- | --- | --- |
    |variablename|ruletype | unit | minthreshold | maxthreshold |
    |partname | count | Number | 1.0 |4000.0 | 
3. Below infrastrusture resources should be deployed as a part of the fisrt time infrastructure setup:
    a. Lambda function - "<usecase-dapm-apsouth1-glue-trigger-on-event" 
    b. Event bus in event bridge "<usecase-dapm-apsouth1-dapf-cb" 
    c. Rules of the event bus "<usecase-dapm-apsouth1-dapf-cb" 
        i. Rule - data_quality-event
            Event Pattern: 
                {
                  "source": ["dcpd.dataquality"]
                }

4. evaluation job in training (model/training_job/evaluation/evaluation_summary.py) and in inferencing (model/inferencing_job/evaluation/inferencing_summary.py)
   should have a code to send the data quality event in the eventbridge
5. Monitoring Bucket in the usecase account to be created - "<usecase>_dapm_apsouth1_monitoring"
     

## Code Flow:
1. Triggered from the event( data quality event generated from the evaluation_summary job of Training or Inferencing Step function) providing the required parameters
2. Data quality event invokes the lambda "<usecase-dapm-apsouth1-glue-trigger-on-event" which triggers the data drift glue job for data drift processing 
3. Read input dataset on which data quality needs to be done from the paramter "--preprocessing_read" coming from the event
4. Input is provided which is having ruleset and the additional metric to enhance dashboard metrics
5. Ruleset is evaluated and captured the result in the same account
6. Consolidated resultset is also loaded in cross account EAP bucket
7. Detailed resultset of the Data quality will be captured in the same account buckets:
    a. Training Data drift 
        Data is captured in S3 bucket : <usecase>-<env>-<region>-training-shared
        Athena table created automatically by the glue job : training_data_quality
    b. Inferencing Data drift 
        Data is captured in S3 bucket : <usecase>-<env>-<region>-inferncing-shared
        Athena table created automatically by the glue job : inferencing_data_quality
 


## Development Steps to deploy data drift job
1. Sample boiler plate code needs to be picked from the template repository ( /model/common/monitoring/data_quality_eap.py)
2. In the code , look for the "# TODO BE PROVIDED BY DEV :" and provide the data quality ruleset and their threshold values in the list of tuples "dq_df_dataset"
    Sample Values: 
    dq_df_dataset = [
        ("part_name", "count", 'Number', 1.0, 4000.0,
         """DistinctValuesCount "part_name" between 0 and 4000"""),
        ("data_from", "count", 'Number', 1.0, 4000.0,
         """DistinctValuesCount "data_from" between 0 and 4"""),
        ("part_proababilty", "min", 'Number', 0.1, 1.0,
         """CustomSql "select min(part_probability) from primary" between 0.0 and 1.0""")
    ]
3. Save the job and deploy it by placing in the git at the location of respective usecase repository ( /model/common/monitoring/data_quality_eap.py)


## Testing the Data Drift job manually

1. Trigger the lambda "<usecase-dapm-apsouth1-glue-trigger-on-event" by providing the sample event as shown below :
    Note: Please change the values of parameters passed inside "details" : {}
        {
      "version": "0",
      "id": "dadfc1bb-05df-2389-5b9c-d10eff91ac25",
      "detail-type": "data_quality_event",
      "source": "sprs.dataquality",
      "account": "645520530156",
      "time": "2023-09-25T12:46:42Z",
      "region": "ap-south-1",
      "resources": [],
      "detail": {
        "--year": "2023",
        "--month": "10",
        "--day": "28",
        "--stepjobid": "sprs-dev-apsouth1-modelops-training-orchestrator-214e9559-dace-4f41-a58c-5011afc3647c",
        "--usecase_name": "sprs",
        "--features_dq_input_path": "s3://sprs-dev-apsouth1-training-internal/analytical_data/year=2023/month=10/day=28/combined_data.csv",
        "--input_job_identifier": "training",
        "--same_account_dq_bucket": "sprs-dev-apsouth1-training-shared"
      }
    }

2. After execution , validate if the data comes in the cross account bucket "s3://eap-dev-apsouth1-glue-cross-account-bucket/ml-dd-dataquality/"
3. Trigger the glue crawler "eap-dev-apsouth1-data-quality-monitoring" and validate the data is getting refreshed in the athena table 
   SELECT * FROM "eap-dev-apsouth1-dashboard-monitoring-db"."ml_dd_dataquality" where corelation_id = "<step_job_id"

## Explanation of parameters passed in the inputs of Data drift job

Below are the details with paramters names , description of their purpose and origin who will provide the value. 
| Parameter | SampleValue |Description| ValueProvider |
| --- | --- | --- | --- |
|--year|2023| This is the year for which training or inference has been done |Evaluation job Event |
|--month|09 | TThis is the month for which training or inference has been done |Evaluation job Event |
|--day|25 | This is the day for which training or inference has been done |Evaluation job Event |
|--stepjobid|b040bacd-a6d4-4b99-956c-a102fb55621d | This is the step job identifier for which training or inference has been done |Evaluation job Event |
|--usecase_name|dcp | This is the usecase for which training or inference has been done |Evaluation job Event |
|--preprocessing_read|s3://dcpd-dapm-apsouth1-training-internal/analytical_data/year=2023/month=09/day=25/combined_data.csv | Input data file path |Evaluation job Event |
|--input_job_identifier|training |Identifier whether this is run for training or inferencing |Evaluation job Event |
|--same_account_dq_bucket|| Name of the same account bucket where detailed data quality results are captured  |Evaluation job Event |
|--additional-python-modules|pythena==1.6.0,ndjson==0.3.1 | Python libraries which are requried to downloaded as a part of this glue job | Terraform IAC  |
|--dashboard_consoilidated_dq_tablename|ml-dd-dataquality | Name of the athena table created for data drift in eap account ( No change required here) | Terraform IAC  |
|--eap_central_bucket|eap-dev-apsouth1-glue-cross-account-bucket | Name of cross account eap bucket where data is stored for dashbaording( No change required here) | Terraform IAC |
|--job_frequency|Monthly | Frequency at which Data drift job has been running  | Terraform IAC | 
|--same_account_monitoring_athena_db|<usecase_name>_dapm_apsouth1_monitoring | Name of the same account athena db where detailed result set can be viewed | Terraform IAC |
|--solution_category|Forecasting | Tells about the solution category of the ML model | Terraform IAC |
|--solution_type|Batch | Tells about the solution type whether it is Batch or Realtime | Terraform IAC |


## References:
1. Working with Glue DQ in glue notebook - https://docs.aws.amazon.com/glue/latest/ug/data-quality-notebooks.html
2. Glue DQ - https://docs.aws.amazon.com/glue/latest/dg/data-quality.html
3. Data Quality definition languages - https://docs.aws.amazon.com/glue/latest/dg/dqdl.html