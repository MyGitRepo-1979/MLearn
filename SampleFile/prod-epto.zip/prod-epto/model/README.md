# 1. MLOps

- [1. MLOps](#1-mlops)
  - [1.1. Training\_Job](#11-training_job)
    - [1.1.1. training](#111-training)
    - [1.1.2. preprocessing](#112-preprocessing)
    - [1.1.3. evaluation](#113-evaluation)
  - [1.2. Inferencing\_Job](#12-inferencing_job)
  - [1.3. High level workflow](#13-high-level-workflow)
  - [1.4. Monitoring](#14-monitoring)
    - [1.4.1. Dashboard Data Drift](#141-dashboard-data-drift)
      - [1.4.1.1. Prerequisites](#1411-prerequisites)
      - [1.4.1.2. Explanation of the code flow for data drift](#1412-explanation-of-the-code-flow-for-data-drift)
      - [1.4.1.3. Steps to be followed for deploying  Dashboard data drift glue jobs](#1413-steps-to-be-followed-for-deploying--dashboard-data-drift-glue-jobs)
      - [1.4.1.4. Testing/Validating  the Data Drift job manually](#1414-testingvalidating--the-data-drift-job-manually)
      - [1.4.1.5. Explanation of parameters passed in the inputs of Data drift job](#1415-explanation-of-parameters-passed-in-the-inputs-of-data-drift-job)
      - [1.4.1.6. References for writing DQ rules in Data drift job](#1416-references-for-writing-dq-rules-in-data-drift-job)
    - [1.4.2. Dashboard  Training Model Quality](#142-dashboard--training-model-quality)
      - [1.4.2.1. Prerequisites](#1421-prerequisites)
      - [1.4.2.2. Explanation of the code flow for training model quality](#1422-explanation-of-the-code-flow-for-training-model-quality)
      - [1.4.2.3. Steps to be followed for deploying Training model glue jobs](#1423-steps-to-be-followed-for-deploying-training-model-glue-jobs)
      - [1.4.2.4. Explanation of parameters passed in the inputs of Training model quality job](#1424-explanation-of-parameters-passed-in-the-inputs-of-training-model-quality-job)
      - [1.4.2.5. Testing/Validating  the Training model quality job manually](#1425-testingvalidating--the-training-model-quality-job-manually)
    - [1.4.3. Dashboard  Inferencing Model Quality](#143-dashboard--inferencing-model-quality)
      - [1.4.3.1. Prerequisites](#1431-prerequisites)
      - [1.4.3.2. Explanation of the code flow for Inferencing model quality](#1432-explanation-of-the-code-flow-for-inferencing-model-quality)

This section is a guide for a Data scientist/ ML Engineer to operationalize ML code.
DS/MLE to navigate to  forked repo and double click on **Model** directory , three directories are listed

1. [**common**](common)
2. [**inferencing_job**](inferencing_job)
3. [**training_job**](training_job)

## 1.1. Training_Job

`training_Job` folder contains 5 folders.
From MLOps perspective you will mostly be working with below three

### 1.1.1. training

1. DS/MLE to commit
   - ML training code (ML business logic) into training.py
   - The libraries imported in training.py in requirements.txt
2. MLE to commit docker image build steps into `Dockerfile`

### 1.1.2. preprocessing

DS/MLE to commit Training preprocessing (ML business logic) into `preprocessing.py`

### 1.1.3. evaluation

DS/MLE to commit model evaluation (ML business logic) into evaluation.py

## 1.2. Inferencing_Job

Similar to training construct, DS/ML to commit corresponding code to respective module of inferencing folder

## 1.3. High level workflow

DS/MLE to push commited code to remote repo. this will trigger an automated code build and push to ECR, AWS Glue jobs etc. DS/ML to update infrastrcture through following steps

1. Go to Jenkins console

2. Select your use case - example Quality-dcp.

3. After selecting your use case example quality-dcp:

There are 3 pipelines:
1- `aws-code-sync`: this will sync code in different resources. Benefit of code sync is that data scientist need not to deploy whole infra on changing ds related code.
2- `Terraform-infra-deploy` - helps to deploy infra and resources in AWS acccount
3- `modelops-model-step-function-orchestrator` - will help you trigger training and inferencing from Jenkins console

DS/MLE to run training using following steps :

1. select orchestrator and user will se different environments for which you need to trigger pipeline. Example: select main for development environment

2. Select training and click build

3. DS/MLE to Approve Model via Model Registry, Navigate to Sagemaker Studio > Models > Model Registry > update status > click Approved

4. Inferencing execution
    1. MLE/DS to schedule or trigger Inferencing by Jenkins , similar to Training Execution
    2. For Real time Inferencing, MLE/DS to test Infernecing by making HTTPS calls to Applicaiton Endpoint or API GW

## 1.4. Monitoring

### 1.4.1. Dashboard Data Drift

#### 1.4.1.1. Prerequisites

1. Data Engineer to receive threshold values from business team. Below is the sample provided for reference. All the 5 columns to be provided by business

|4 |Unit |Rule |Threshold Max **** |Threshold Min |
|--- |--- |--- |--- |--- |
|part_name |Number |Count |2000 |1 |
|data_from |Number |Count |4 |1 |

1. Data drift will be applicable on the output of the transformed dataset generated through ML preprocessing job . So framework’s ML preprocessing job should be already deployed
2. EAP account S3 bucket `eap-<env>-apsouth1-glue-cross-account-bucket` and Glue database `eap-<env>-apsouth1-dashboard-monitoring-db` should already be created in the EAP account based on which quicksight dashboard will be created.
3. Below infrastrusture resources should be deployed as a part of the first time infrastructure setup:
    a.   **Lambda** function - `<usecase-dapm-apsouth1-glue-trigger-on-event`
    b.   **Event bus** in event bridge `<usecase-dapm-apsouth1-dapf-cb>`
    c.   **Rules** of the event bus `<usecase-dapm-apsouth1-dapf-cb`

    *Rule** - data_quality-event

            Event Pattern:
                {
                  "source": ["<usecase_name>.dataquality"]
                }

4. evaluation job in training (model/training_job/evaluation/evaluation_summary.py) and in inferencing (model/inferencing_job/evaluation/inferencing_summary.py) should have a code to send the data quality event in the eventbridge
5. Monitoring Bucket in the usecase account to be created by frameowrk IAC  code `<usecase>_dapm_apsouth1_monitoring`

#### 1.4.1.2. Explanation of the code flow for data drift

[Image: Image.jpg]

1. Triggered from the event( data quality event generated from the evaluation_summary job of Training or Inferencing Step function) providing the required parameters
2. Data quality event invokes the lambda `<usecase-dapm-apsouth1-glue-trigger-on-event` which triggers the data drift glue job for data drift processing
3. Data drift glue job reads input dataset on which data quality needs to be done from the parameter **"—preprocessing_read"** coming from the event
4. Input is provided in the data drift glue job which is having ruleset and the additional metric to enhance dashboard metrics
5. Ruleset is evaluated and captured the result in the same account
6. Consolidated resultset is also loaded in cross account EAP bucket
7. Detailed resultset of the Data quality will be captured in the same account buckets:

    a. Training Data drift
        Data is captured in S3 bucket : `<usecase>-<env>-<region>-training-shared`
        Athena table created automatically by the glue job : `training_data_quality`
    b. Inferencing Data drift
        Data is captured in S3 bucket : `<usecase>-<env>-<region>-inferncing-shared`
        Athena table created automatically by the glue job : `inferencing_data_quality`

#### 1.4.1.3. Steps to be followed for deploying  Dashboard data drift glue jobs

1. Sample boiler plate code needs to be picked from the template repository
    Link : [model/common/monitoring/data_quality_eap.py](model/common/monitoring/data_quality_eap.py)
2. Data engineer needs to create the python file `data_quality_eap.py` using the base code in the usecaase repository `model/common/monitoring/data_quality_eap.py`
3. In the code , look for the "# TODO BE PROVIDED BY DEV :" and provide the data quality ruleset and their threshold values in the list of tuples "dq_df_dataset"

**Sample Values:**

```python
dq_df_dataset = [
        ("part_name", "count", 'Number', 1.0, 4000.0,
         """DistinctValuesCount "part_name" between 0 and 4000"""),
        ("data_from", "count", 'Number', 1.0, 4000.0,
         """DistinctValuesCount "data_from" between 0 and 4"""),
        ("part_proababilty", "min", 'Number', 0.1, 1.0,
         """CustomSql "select min(part_probability) from primary" between 0.0 and 1.0""")
    ]

```

4. Save the job and deploy it by placing in the git at the location of respective usecase repository ( /model/common/monitoring/data_quality_eap.py)
5. Data engineer needs to update the `env/<env>/<env>.tfvars.json` to pass the below configurations

```json
{
    "eap_dq_bucket_name":"eap-dev-apsouth1-glue-cross-account-bucket",
    "monitoring":{
        "glue_data_quality_params":{
            "path":"model/common/monitoring/data_quality_eap.py",
            "additional_arguments":{
                "—job_frequency":"Monthly",
                "—solution_type":"Real-Time",
                "—solution_category":"Regression"
            }
        }
    }
}
```

#### 1.4.1.4. Testing/Validating  the Data Drift job manually

1. Trigger the lambda `<usecase-dapm-apsouth1-glue-trigger-on-event` by providing the sample event as shown below :

**Note:** Please change the values of parameters passed inside "details" : {}

**Sample event for triggering lambda for validating data drift glue job**

```json
{
    "version": "0",
    "id": "dadfc1bb-05df-2389-5b9c-d10eff91ac25",
    "detail-type": "data_quality_event",
    "source": "sprs.dataquality",
    "account": "645520530156",
    "time": "2023-09-25T12:46:42Z",
    "region": "ap-south-1",
    "resources": [],
    "detail": {
    "—year": "2023",
    "—month": "10",
    "—day": "28",
    "—stepjobid": "sprs-dev-apsouth1-modelops-training-orchestrator-214e9559-dace-4f41-a58c-5011afc3647c",
    "—usecase_name": "sprs",
    "—features_dq_input_path": "s3://sprs-dev-apsouth1-training-internal/analytical_data/year=2023/month=10/day=28/combined_data.csv",
    "—input_job_identifier": "training",
    "—same_account_dq_bucket": "sprs-dev-apsouth1-training-shared"
    }
}
```

1. After execution , validate if the data comes in the cross account bucket `s3://eap-<env>-apsouth1-glue-cross-account-bucket/ml-dd-dataquality/`
2. Trigger the glue crawler "eap-dev-apsouth1-data-quality-monitoring" and validate the data is getting refreshed in the athena table

```sql
SELECT * FROM "eap-dev-apsouth1-dashboard-monitoring-db"."ml_dd_dataquality" where corelation_id = "<step_job_id"
```

#### 1.4.1.5. Explanation of parameters passed in the inputs of Data drift job

|Parameter |SampleValue |Description |ValueProvider |
|--- |--- |--- |--- |
|—year |2023 |This is the year for which training or inference has been done |Evaluation job Event |
|—month |9 |This is the month for which training or inference has been done |Evaluation job Event |
|—day |25 |This is the day for which training or inference has been done |Evaluation job Event |
|—stepjobid |b040bacd-a6d4-4b99-956c-a102fb55621d | |Evaluation job Event |
|—usecase_name |dcp |This is the usecase for which training or inference has been done |Evaluation job Event |
|—preprocessing_read |s3://dcpd-dapm-apsouth1-training-internal/analytical_data/year=2023/month=09/day=25/combined_data.csv |Input data file path |Evaluation job Event |
|—input_job_identifier |training |Identifier whether this is run for training or inferencing |Evaluation job Event |
|—same_account_dq_bucket | |Name of the same account bucket where detailed data quality results are captured |Evaluation job Event |
|—additional-python-module |pythena==1.6.0,ndjson==0.3.1 |Python libraries which are requried to downloaded as a part of this glue job |Terraform IAC |
|—dashboard_consoilidated_dq_tablename |ml-dd-dataquality |Name of the athena table created for data drift in eap account ( No change required here) |Terraform IAC |
|—eap_central_bucket |eap-dev-apsouth1-glue-cross-account-bucket |Name of cross account eap bucket where data is stored for dashbaording( No change required here) |Data engineer needs to pass this in the environment file - env/<env>/<env>.tfvars.json |
|—job_frequency |Monthly |Frequency at which Data drift job has been running |Data engineer needs to pass this in the environment file - env/<env>/<env>.tfvars.json |
|—same_account_monitoring_athena_db |<usecase_name>_dapm_apsouth1_monitoring |Name of the same account athena db where detailed result set can be viewed |Terraform IAC |
|—solution_category |Forecasting |Tells about the solution category of the ML model |Data engineer needs to pass this in the environment file - env/<env>/<env>.tfvars.json |
|—solution_type |Batch |Tells about the solution type whether it is Batch or Realtime |Data engineer needs to pass this in the environment file - env/<env>/<env>.tfvars.json |
| | | | |

#### 1.4.1.6. References for writing DQ rules in Data drift job

1. Working with Glue DQ in glue notebook - <https://docs.aws.amazon.com/glue/latest/ug/data-quality-notebooks.html>
2. Glue DQ - <https://docs.aws.amazon.com/glue/latest/dg/data-quality.html>
3. Data Quality definition languages - <https://docs.aws.amazon.com/glue/latest/dg/dqdl.html>

### 1.4.2. Dashboard  Training Model Quality

#### 1.4.2.1. Prerequisites

1. **Business** needs to provide Threshold for model in the following format
    **critical_threshold** - represents the condition to show the status as “Red”
    **base_threshold** - represents the condition to show the status as “Green”
    Range between base threshold and critical_threshold will be represented as “Amber”
    **expected_value -** This metric is only for representation purpose on the dashboard . This is of string type and has no significance in calculation of model quality status

|usecase |metric_name |unit |critical_threshold |base_threshold |expected_value |
|--- |--- |--- |--- |--- |--- |
|WCF |mape |Percentage |> 50 |< 20 |< 20 |

Example :
 if mape score < 20% then it is  **“Green”**
 if mape score > 50% then it is **“Red”**
 if mape score > 20% and mape score < 50%  then it is **“Amber”**

2. Data engineer needs to create the csv from the values provided by business ( mentioned in point 1)  in the following format

    **Sample csv format :**
    metric_name,unit,base_threshold,critical_threshold,expected_value
    mape,Percentage,50.0,20.0,<20

3. Below are the points that needs to taken care while creating csv file
    a. **metric_name** should be in **lowercase**
    b. **critical_threshold** and **base_threshold** should **not** have any symbol like less than , greater than  , equal to  or percentage sign . This should be of float type .
    For eg: if business provides critical_threshold as **“>50”** then in the csv it’s value should be passed as 50.0 . This greater than sign will be included as a part of glue job code.
    c. Naming convention of the threshold file - model_quality_threshold.csv

4. model_quality_threshold.csv needs to be stored in the usecase git repository  in the path `model/common/monitoring`
Sample threshold file can be found at : [model/common/monitoring/model_quality_threshold.csv](model/common/monitoring/model_quality_threshold.csv)

5. EAP account S3 bucket `eap-<env>-apsouth1-glue-cross-account-bucket` and Glue database `eap-<env>-apsouth1-dashboard-monitoring-db` should already be created in the EAP account based on which quicksight dashboard will be created.

6. Below infrastrusture resources should be deployed as a part of the first time infrastructure setup:
    a.   **Lambda** function - `<usecase-dapm-apsouth1-glue-trigger-on-event`
    b.   **Event bus** in event bridge `<usecase-dapm-apsouth1-dapf-cb`
    c.   **Rules** of the event bus `<usecase-dapm-apsouth1-dapf-cb`
    **Rule** - model_quality-event

            Event Pattern:
                {
                  "source": ["<usecase_name>.modelquality"]
                }

7. evaluation job in training (model/training_job/evaluation/evaluation_summary.py) should have a code to send the training model quality event in the eventbridge

#### 1.4.2.2. Explanation of the code flow for training model quality

1. Model evaluation is calculated by Training evaluation job and stored in the path `s3://<usecase_name>-<env>-apsouth1-training-shared/model_eval_summary/year=<year>/month=<month>/day=<day>/stepjobid=<step_job_id>/` .
2. After evaluation , an event  is being sent to event bridge to trigger training model quality job to enhance the metrices and sent them to the eap shared bucket.
3. Model quality event invokes the lambda `<usecase-dapm-apsouth1-glue-trigger-on-event` which triggers the model quality glue job for enhancing training model quality for dashboard
4. Training model quality glue job reads model_eval_summary file generated in the step 1 and combine with threshold file to enhance the data as per the dashboard needs

#### 1.4.2.3. Steps to be followed for deploying Training model glue jobs

1. Take the training model quality sample job from the template repository using the below link [model/training_job/monitoring/training_model_quality_eap.py](model/training_job/monitoring/training_model_quality_eap.py)
2. Data engineer to create the `training_model_quality_eap.py` with the base code ( mentioned in step 1) in the usecase repository in the path `model/training_job/monitoring`
3. Please look for the comment  **“#TODO - this section needs to be updated as per the required threshold criteria”** and update this section as per the threshold criteria given by Business .
**Note**: Instructions are clearly mentioned in the comment in the code
4. Data engineer needs to update the `env/<env>/<env>.tfvars.json` to pass the below configurations

```
"eap_dq_bucket_name":"eap-dev-apsouth1-glue-cross-account-bucket",
"monitoring":{
    "glue_training_model_quality_params":{
        "path":"model/training_job/monitoring/training_model_quality_eap.py",
        "additional_arguments":{
        "—solution_type":"Real-Time",
        "—solution_category":"Regression"
        }
    }
}
```

#### 1.4.2.4. Explanation of parameters passed in the inputs of Training model quality job

|Parameter |SampleValue |Description |ValueProvider |
|--- |--- |--- |--- |
|—year |2023 |This is the year for which training or inference has been done |Evaluation job Event |
|—month |9 |This is the month for which training or inference has been done |Evaluation job Event |
|—day |25 |This is the day for which training or inference has been done |Evaluation job Event |
|—stepjobid |sprs-dev-apsouth1-modelops-training-orchestrator-214e9559-dace-4f41-a58c-5011afc3647c |Step job id for which training has been done  |Evaluation job Event |
|—usecase_name |dcp |This is the usecase for which training or inference has been done |Evaluation job Event |
|--input_read_path |s3://sprs-dev-apsouth1-training-shared/model_eval_summary/year=2023/month=10/day=28/stepjobid=sprs-dev-apsouth1-modelops-training-orchestrator-214e9559-dace-4f41-a58c-5011afc3647c/ |S3 path where model evaluation metric are stored for this particular training |Evaluation job Event |
|--threshold_data_path |training |S3 Path of the model quality threshold file |Provided by Framework automatically. Nothing needs to be done manually for this |
|--eap_central_bucket |eap-dev-apsouth1-glue-cross-account-bucket |Name of eap shared bucket |Data engineer needs to pass this in the environment file - env/<env>/<env>.tfvars.json |
|--model_quality_prefix |model_quality |This is the prefix of the S3 path where model quality is stored . Also , this same is used to refer to the athena table in the eap account  |Provided by Framework automatically. Nothing needs to be done manually for this |
|--source |Training |Source for which model quality is done whether it is for training or infercing  |Provided by Framework automatically. Nothing needs to be done manually for this |
|--solution_type |Forecasting |Tells about the solution category of the ML model |Data engineer needs to pass this in the environment file - env/<env>/<env>.tfvars.json |
|--solution_category |Batch |Tells about the solution type whether it is Batch or Realtime |Data engineer needs to pass this in the environment file - env/<env>/<env>.tfvars.json |

#### 1.4.2.5. Testing/Validating  the Training model quality job manually

1. Trigger the lambda `<usecase-dapm-apsouth1-glue-trigger-on-event` by providing the sample event as shown below :

**Note:** Please change the values of parameters passed inside "details" : {}

**Sample event for triggering lambda for validating data drift glue job**

```
{
    "version": "0",
    "id": "e12ce794-22cf-76ed-be23-49ff608b11c9",
    "detail-type": "model_monitoring_event",
    "source": "sprs.modelquality",
    "account": "645520530156",
    "time": "2023-09-25T12:46:42Z",
    "region": "ap-south-1",
    "resources": [],
    "detail": {
    "—year": "2023",
    "—month": "10",
    "—day": "29",
    "—stepjobid": "sprs-dev-apsouth1-modelops-training-orchestrator-214e9559-dace-4f41-a58c-5011afc3647c",
    "—usecase_name": "sprs",
    "—eval_summary_prefix_path": "s3://sprs-dev-apsouth1-training-shared/model_eval_summary/year=2023/month=10/day=28/stepjobid=sprs-dev-apsouth1-modelops-training-orchestrator-214e9559-dace-4f41-a58c-5011afc3647c/",
    "—input_job_identifier": "training"
    }
}
```

1. After execution , validate if the data comes in the cross account bucket `s3://eap-<env>-apsouth1-glue-cross-account-bucket/model-quality/`
2. Trigger the glue crawler "eap-dev-apsouth1-model-quality-monitoring" and validate the data is getting refreshed in the athena table

```sql
SELECT * FROM "eap-dev-apsouth1-dashboard-monitoring-db"."model_quality" where corelation_id = "<step_job_id>"
```

### 1.4.3. Dashboard  Inferencing Model Quality

#### 1.4.3.1. Prerequisites

1. **Business** needs to provide Threshold for model in the following format
    **critical_threshold** - represents the condition to show the status as “Red”
    **base_threshold** - represents the condition to show the status as “Green”
    Range between base threshold and critical_threshold will be represented as “Amber”

    **expected_value -** This metric is only for representation purpose on the dashboard . This is of string type and has no significance in calculation of model quality status

|usecase |metric_name |unit |critical_threshold |base_threshold |expected_value |
|--- |--- |--- |--- |--- |--- |
|WCF |mape |Percentage |> 50 |< 20 |< 20 |

Example :
 if mape score < 20% then it is  **“Green”**
 if mape score > 50% then it is **“Red”**
 if mape score > 20% and mape score < 50%  then it is **“Amber”
**

1. Data engineer needs to create the csv from the values provided by business ( mentioned in point 1)  in the following format

    **Sample csv format :**
    metric_name,unit,base_threshold,critical_threshold,expected_value
    mape,Percentage,50.0,20.0,<20
2. Below are the points that needs to taken care while creating csv file
    a. **metric_name** should be in **lowercase**
    b. **critical_threshold** and **base_threshold** should **not** have any symbol like less than , greater than  , equal to  or percentage sign . This should be of float type .
    For eg: if business provides critical_threshold as **“>50”** then in the csv it’s value should be passed as 50.0 . This greater than sign will be included as a part of glue job code.
    c. Naming convention of the threshold file - model_quality_threshold.csv
3. model_quality_threshold.csv needs to be stored in the usecase git repository  in the path **“model/common/monitoring”
    Sample threshold file can be found at : [model/common/monitoring/model_quality_threshold.csv](model/common/monitoring/model_quality_threshold.csv)
4. EAP account S3 bucket `eap-<env>-apsouth1-glue-cross-account-bucket` and Glue database `eap-<env>-apsouth1-dashboard-monitoring-db` should already be created in the EAP account based on which quicksight dashboard will be created.

#### 1.4.3.2. Explanation of the code flow for Inferencing model quality

1. After the completion of inference and recieving the actual data , glue workflow will be scheduled to do the model quality comparison and enriches this dataset with threshold provided by business to be shown on the dashboard

**Steps to be followed for deploying  Inferencing  model  glue jobs:**

1. Data engineer to clone the infrencing model quality sample job from the template repository using the below link: [main/model/inferencing_job/monitoring](main/model/inferencing_job/monitoring)
2. Data engineer to create the “**inferencing_model_quality_eap.py”** with the base code ( mentioned in step 1) in the usecase repository in the path **“model/inferencing_job/monitoring”
    **
3. Please customise the code as per the requirement
4. Data engineer needs to update the env/<env>/<env>.tfvars.json to pass the below configurations

"eap_dq_bucket_name":"eap-dev-apsouth1-glue-cross-account-bucket",
"monitoring":{
"glue_inferencing_model_quality_params":{
"path":"model/inferencing_job/monitoring/inference_model_quality_eap.py",
"additional_arguments":{
"—solution_type":"Real-Time",
"—solution_category":"Regression",
"—additional-python-modules":"numpy,scikit-learn==1.3.1,pandas==1.5.3,awswrangler"
}
}}

1. Data engineer needs to add inference workflow configuration in the **“gule_wf.config.json”** in the path of usecase git repository **“env/<env>”**
    Note: Please update the cron expression of schedule timing as per the requirement requiremen
    "wf_inference_model_quality"
    "wf_inference_model_quality": {

"description":"",
"default_run_properties":{

},
"max_concurrent_runs":1,
"triggers":{
"inference_mq":{
"type":"SCHEDULED",
"schedule":"cron(0 9 5 *?*)",
"enabled":"false",
"actions":[
{
"job_name":"${tfvars_name_prefix}-inferencing-model-quality"
}
]
}
}
}
**Explanation of parameters passed in the inputs of Data drift job**

|Parameter |SampleValue |Description |ValueProvider |
|--- |--- |--- |--- |
|--inferencing_shared_bucketname | |Name of the inferencing bucket where the actual and inference combine data file will be available for model quality evaluation  |Provided by Framework automatically. Nothing needs to be done manually for this |
|--threshold_data_path | |S3 Path where threshold file is placed   |Provided by Framework automatically. Nothing needs to be done manually for this |
|--eap_central_bucket |eap-dev-apsouth1-glue-cross-account-bucket |Name of the eap shared bucket  |Data engineer needs to pass this in the environment file - env/<env>/<env>.tfvars.json |
|--model_quality_prefix |model_quality |This is the prefix of the S3 path where model quality is stored . Also , this same is used to refer to the athena table in the eap account  |Provided by Framework automatically. Nothing needs to be done manually for this |
|--WORKFLOW_RUN_ID | |Identifier of the glue workflow of which this inferecning model quality job is a part of  |Provided by Framework automatically. Nothing needs to be done manually for this |
|--source |Inferencing |Name of the source for which model quality is done  |Provided by Framework automatically. Nothing needs to be done manually for this |
|--solution_type |Forecasting |Tells about the solution category of the ML model |Data engineer needs to pass this in the environment file - env/<env>/<env>.tfvars.json |
|--solution_category |Batch |Tells about the solution type whether it is Batch or Realtime |Data engineer needs to pass this in the environment file - env/<env>/<env>.tfvars.json |

**Testing/Validating  the Training model quality job manually**

1. Trigger the lambda "<usecase-dapm-apsouth1-glue-trigger-on-event" by providing the sample event as shown below :

**Note:** Please change the values of parameters passed inside "details" : {}

**Sample event for triggering lambda for validating data drift glue job**
{
"version": "0",
"id": "e12ce794-22cf-76ed-be23-49ff608b11c9",
"detail-type": "model_monitoring_event",
"source": "sprs.modelquality",
"account": "645520530156",
"time": "2023-09-25T12:46:42Z",
"region": "ap-south-1",
"resources": [],
"detail": {
"—year": "2023",
"—month": "10",
"—day": "29",
"—stepjobid": "sprs-dev-apsouth1-modelops-training-orchestrator-214e9559-dace-4f41-a58c-5011afc3647c",
"—usecase_name": "sprs",
"—eval_summary_prefix_path": "s3://sprs-dev-apsouth1-training-shared/model_eval_summary/year=2023/month=10/day=28/stepjobid=sprs-dev-apsouth1-modelops-training-orchestrator-214e9559-dace-4f41-a58c-5011afc3647c/",
"—input_job_identifier": "training"
}
}

1. After execution , validate if the data comes in the cross account bucket "s3://eap-<env>-apsouth1-glue-cross-account-bucket/model-quality/"
2. Trigger the glue crawler "eap-dev-apsouth1-model-quality-monitoring" and validate the data is getting refreshed in the athena table

SELECT * FROM "eap-dev-apsouth1-dashboard-monitoring-db"."model_quality" where corelation_id = "<step_job_id>"
