<!-- BEGIN_TF_DOCS -->
# Analytics-ETL

This module reads env files and enabled DataOps

### Requirements

No requirements.

### Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | n/a |
| <a name="provider_utils"></a> [utils](#provider\_utils) | n/a |

### Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_glue_job_policy"></a> [glue\_job\_policy](#module\_glue\_job\_policy) | github.com/MSIL-Analytics-ACE/terraform-common-modules//iam-policy | v1.0.0 |
| <a name="module_glue_job_role"></a> [glue\_job\_role](#module\_glue\_job\_role) | github.com/MSIL-Analytics-ACE/terraform-common-modules//iam-role | v1.0.0 |
| <a name="module_glue_jobs"></a> [glue\_jobs](#module\_glue\_jobs) | github.com/MSIL-Analytics-ACE/terraform-common-modules//terraform-aws-glue-job | v2.0.0 |
| <a name="module_glue_wfs"></a> [glue\_wfs](#module\_glue\_wfs) | github.com/MSIL-Analytics-ACE/terraform-common-modules//terraform-aws-glue-workflow | v2.0.0 |

### Resources

| Name | Type |
|------|------|
| [aws_athena_database.athena_db](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/athena_database) | resource |
| [aws_s3_bucket.analytics_bucket](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_bucket) | resource |
| [aws_s3_object.upload_ext_scripts](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_object) | resource |
| [aws_s3_object.upload_utils](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_object) | resource |
| [aws_ssm_parameter.ssm_params](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssm_parameter) | resource |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |
| [aws_iam_policy_document.glue_job_policy](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/iam_policy_document) | data source |
| [aws_region.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/region) | data source |
| [utils_deep_merge_json.merged_json](https://registry.terraform.io/providers/cloudposse/utils/latest/docs/data-sources/deep_merge_json) | data source |

### Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_etl_glue_config_json_paths"></a> [etl\_glue\_config\_json\_paths](#input\_etl\_glue\_config\_json\_paths) | Path of glue json which contains config | `list(string)` | n/a | yes |
| <a name="input_etl_source_path"></a> [etl\_source\_path](#input\_etl\_source\_path) | Provide source folder path of etl scripts | `string` | n/a | yes |
| <a name="input_expected_dq_job_count"></a> [expected\_dq\_job\_count](#input\_expected\_dq\_job\_count) | Expected number of ETL dq jobs which are matched for email functionality | `number` | n/a | yes |
| <a name="input_name_prefix"></a> [name\_prefix](#input\_name\_prefix) | Prefix to be appended to all resource names | `string` | n/a | yes |
| <a name="input_use_case_name"></a> [use\_case\_name](#input\_use\_case\_name) | use case name identifier | `string` | n/a | yes |
| <a name="input_utils_path"></a> [utils\_path](#input\_utils\_path) | paths to utilities | `string` | n/a | yes |
| <a name="input_athena_databases"></a> [athena\_databases](#input\_athena\_databases) | athena db names | `any` | `{}` | no |
| <a name="input_eap_dq_bucket_name"></a> [eap\_dq\_bucket\_name](#input\_eap\_dq\_bucket\_name) | S3 bucket name from EAP account | `string` | `"random"` | no |
| <a name="input_etl_ssm_params"></a> [etl\_ssm\_params](#input\_etl\_ssm\_params) | provide list of ssm params to create | `any` | `{}` | no |

### Outputs

| Name | Description |
|------|-------------|
| <a name="output_athena_db"></a> [athena\_db](#output\_athena\_db) | n/a |
| <a name="output_s3"></a> [s3](#output\_s3) | n/a |
<!-- END_TF_DOCS -->