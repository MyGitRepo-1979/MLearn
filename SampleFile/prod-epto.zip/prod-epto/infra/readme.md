<!-- BEGIN_TF_DOCS -->
# Terraform root module for Dynamic and parallel framework

This module inherits functions from [terraform-awsproserv-dapm-framework](https://github.com/MSIL-Analytics-ACE/terraform-awsproserv-dapm-framework)

### Requirements

| Name | Version |
|------|---------|
| <a name="requirement_terraform"></a> [terraform](#requirement\_terraform) | >= 0.15, < 2.0.0 |
| <a name="requirement_aws"></a> [aws](#requirement\_aws) | >= 4.61.0 |
| <a name="requirement_awscc"></a> [awscc](#requirement\_awscc) | >= 0.49.0 |

### Providers

| Name | Version |
|------|---------|
| <a name="provider_aws"></a> [aws](#provider\_aws) | >= 4.61.0 |

### Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_analytics_etl"></a> [analytics\_etl](#module\_analytics\_etl) | ./modules/analytics_etl | n/a |
| <a name="module_batch_inferencing"></a> [batch\_inferencing](#module\_batch\_inferencing) | github.com/MSIL-Analytics-ACE/terraform-awsproserv-dapm-framework//constructs/batch_inferencing | v3.1.0 |
| <a name="module_batch_training"></a> [batch\_training](#module\_batch\_training) | github.com/MSIL-Analytics-ACE/terraform-awsproserv-dapm-framework//constructs/batch_training | v3.1.0 |
| <a name="module_common"></a> [common](#module\_common) | ./modules/common | n/a |
| <a name="module_monitoring"></a> [monitoring](#module\_monitoring) | github.com/MSIL-Analytics-ACE/terraform-awsproserv-dapm-framework//constructs/monitoring | v3.1.0 |

### Resources

| Name | Type |
|------|------|
| [aws_resourcegroups_group.test](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/resourcegroups_group) | resource |
| [aws_s3_object.upload_mapping_json](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/s3_object) | resource |
| [aws_ssm_parameter.step_function_inputs](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/resources/ssm_parameter) | resource |
| [aws_caller_identity.current](https://registry.terraform.io/providers/hashicorp/aws/latest/docs/data-sources/caller_identity) | data source |

### Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_account_number"></a> [account\_number](#input\_account\_number) | target account number | `number` | n/a | yes |
| <a name="input_env"></a> [env](#input\_env) | Stage / Environment identifier | `string` | n/a | yes |
| <a name="input_mapping_json_path"></a> [mapping\_json\_path](#input\_mapping\_json\_path) | Provide path relative to root for mapping json | `string` | n/a | yes |
| <a name="input_region"></a> [region](#input\_region) | region to deploy resources | `string` | n/a | yes |
| <a name="input_repo_url"></a> [repo\_url](#input\_repo\_url) | Repository URL | `string` | n/a | yes |
| <a name="input_use_case_name"></a> [use\_case\_name](#input\_use\_case\_name) | use case name identifier | `string` | n/a | yes |
| <a name="input_analytics_etl"></a> [analytics\_etl](#input\_analytics\_etl) | n/a | <pre>object({<br>    glue_config_paths     = optional(any)<br>    expected_dq_job_count = number<br>  })</pre> | <pre>{<br>  "expected_dq_job_count": null,<br>  "glue_config_path": null<br>}</pre> | no |
| <a name="input_eap_dq_bucket_name"></a> [eap\_dq\_bucket\_name](#input\_eap\_dq\_bucket\_name) | S3 bucket name from EAP account | `string` | `"random"` | no |
| <a name="input_enable_monitoring"></a> [enable\_monitoring](#input\_enable\_monitoring) | S3 bucket name from EAP account | `bool` | `false` | no |
| <a name="input_inferencing"></a> [inferencing](#input\_inferencing) | n/a | <pre>object({<br>    evaluation_job_params = optional(any)<br>    gatekeeper_job_params = optional(any)<br>    batch_vpc = optional(object({<br>      vpc_id     = string<br>      subnet_ids = list(string)<br>    }))<br>    pre_processing_params      = optional(any)<br>    batch_compute_environments = optional(map(any))<br>  })</pre> | <pre>{<br>  "batch_compute_environments": {<br>    "inferencing": {<br>      "desired_vcpus": 0,<br>      "instance_types": [<br>        "m5.large"<br>      ],<br>      "max_vcpus": 216,<br>      "min_vcpus": 0,<br>      "type": "EC2"<br>    }<br>  },<br>  "evaluation_job_params": {<br>    "path": "model/inferencing_job/evaluation/inferencing_summary.py"<br>  },<br>  "gatekeeper_job_params": {<br>    "path": "model/inferencing_job/gatekeeper/gatekeeper.py"<br>  },<br>  "pre_processing_params": {<br>    "instance_count": 1,<br>    "instance_type": "ml.c5.2xlarge",<br>    "job_execution_role_name": null,<br>    "volume_size": 10<br>  }<br>}</pre> | no |
| <a name="input_monitoring"></a> [monitoring](#input\_monitoring) | n/a | <pre>object({<br>    glue_data_quality_params              = optional(any)<br>    glue_feature_store_params             = optional(any)<br>    glue_inferencing_model_quality_params = optional(any)<br>    glue_training_model_quality_params    = optional(any)<br>  })</pre> | `{}` | no |
| <a name="input_training"></a> [training](#input\_training) | n/a | <pre>object({<br>    evaluation_job_params      = optional(any)<br>    gatekeeper_job_params      = optional(any)<br>    pre_processing_params      = optional(any)<br>    batch_compute_environments = optional(map(any))<br>  })</pre> | <pre>{<br>  "batch_compute_environments": {<br>    "training": {<br>      "desired_vcpus": 0,<br>      "instance_types": [<br>        "m5.large"<br>      ],<br>      "max_vcpus": 216,<br>      "min_vcpus": 0,<br>      "type": "EC2"<br>    }<br>  },<br>  "evaluation_job_params": {<br>    "path": "model/training_job/evaluation/evaluation_summary.py"<br>  },<br>  "gatekeeper_job_params": {<br>    "path": "model/training_job/gatekeeper/gatekeeper.py"<br>  },<br>  "pre_processing_params": {<br>    "instance_count": 1,<br>    "instance_type": "ml.c5.2xlarge",<br>    "job_execution_role_name": null,<br>    "volume_size": 10<br>  }<br>}</pre> | no |
| <a name="input_utils_path"></a> [utils\_path](#input\_utils\_path) | paths to utilities | `string` | `"utils"` | no |

### Outputs

| Name | Description |
|------|-------------|
| <a name="output_step_function_inputs"></a> [step\_function\_inputs](#output\_step\_function\_inputs) | n/a |
<!-- END_TF_DOCS -->