import json
from datetime import date, timedelta,datetime
from dateutil.relativedelta import relativedelta
from typing import Dict, List
import watchtower
import logging

import awswrangler as wr
import boto3
import pandas as pd


class CommonExecuteFunctions:
    def __init__(self):
        pass

    
    # create log group 
    def create_log_group(self,log_group_name):
        """
        Creates a CloudWatch Logs log group with the given name if it doesn't already exist.
        Args:
            log_group_name (str): The name of the log group to create.
        Returns:
            None
        """
        logs = boto3.client("logs")
        try:
            logs.create_log_group(logGroupName=log_group_name)
        except logs.exceptions.ResourceAlreadyExistsException:
            # If the log group already exists, we don't need to do anything.
            pass

    # create log stream    
    def create_log_stream(self, log_group_name, log_stream_name):
        """
        Creates a CloudWatch Logs log stream with the given name in the specified log group if it doesn't already exist.
        Args:
            log_group_name (str): The name of the log group to create the log stream in.
            log_stream_name (str): The name of the log stream to create.
        Returns:
            None
        """
        logs = boto3.client("logs")
        try:
            logs.create_log_stream(
                logGroupName=log_group_name, logStreamName=log_stream_name
            )
        except logs.exceptions.ResourceAlreadyExistsException:
            # If the log stream already exists, we don't need to do anything.
            pass

    # function to initialize logger    
    def init_cloudwatch_logger(self,log_group_name, log_stream_name):
        """
        Creates a CloudWatch logger with the specified log group and stream names using the watchtower library.
        Args:
            log_group_name (str): The name of the CloudWatch log group to write to.
            log_stream_name (str): The name of the CloudWatch log stream to write to.
        Returns:
            A CloudWatch logger object.
        """
        # Create a logger and set the log level.
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.INFO)
        # Create a Watchtower handler for the logger, and set the log group and log stream names.
        handler = watchtower.CloudWatchLogHandler(
            log_group=log_group_name, stream_name=log_stream_name
        )
        # Add the handler to the logger.
        logger.addHandler(handler)
        return logger

    def json_read_from_s3(self, p_Bucket: str, p_Key: str) -> Dict:
        """ This function is used to read json file from s3 using boto3.
        Args:
            p_Bucket (str): Bucket name
            p_Key (str): Key to json file
        Returns:
            Dict: returns the json dictionary.
        """
        s3 = boto3.client("s3")
        json_obj = s3.get_object(Bucket=p_Bucket, Key=p_Key)
        json_data = json_obj["Body"].read().decode("utf-8")
        json_dict = json.loads(json_data)
        return json_dict

    def awswrangler_execute_query(self, sql_query: str, db_name: str) -> pd.DataFrame:
        """ This function is used to execute athena queries using awswrangler.
        Args:
            sql_query (str): SQL Query to be executed
            db_name (str): Database name
        Returns:
            dataframe: returns the output dataframe.
        """
        df = wr.athena.read_sql_query(
            sql=sql_query,
            boto3_session=boto3.session.Session(),
            database=db_name,
            ctas_approach=False,
        )

        return df
    
    def get_month_start_end_date(self, date_lag):
        # Get yesterday's date
        current_date = datetime.now() - timedelta(days=date_lag)

        # Get the first day of the month
        start_date = current_date.replace(day=1)

        # Calculate the last day of the month
        if start_date.month == 12:
            end_date = start_date.replace(year=start_date.year + 1, month=1) - timedelta(days=1)
        else:
            end_date = start_date.replace(month=start_date.month + 1) - timedelta(days=1)

        start_date = start_date.strftime("%Y-%m-%d")
        end_date = end_date.strftime("%Y-%m-%d")

        return start_date, end_date

    def get_partition_year_month(self, date_lag):

        current_date = datetime.now() - timedelta(days=date_lag)
        partition_year = current_date.strftime("%Y")
        partition_month = current_date.strftime("%m").zfill(2)

        return partition_year, partition_month


    def get_distinct_partitions(
        self, max_date: str, parameter: str, db_name: str, tbl_name: str
    ) -> List:
        """ This function is used to get a list of dates/partitions after a particular date (max_date).
        Args:
            max_date (str): Max Date after which we need the date list
            parameter (str): column name/partition name
            db_name (str): Database name
            tbl_name (str): Table name
        Returns:
            list: returns the date list.
        """
        sql_query = f"""select distinct {parameter} as result from {db_name}.{tbl_name} 
                            where {parameter}> Date'{max_date}' order by {parameter} desc 
                    """
        res = self.awswrangler_execute_query(sql_query, db_name)
        date_list = res["result"].tolist()

        return date_list

    def delete_from_s3(self, p_bucket: str, p_prefix: str):
        """ This function is used to delete items from s3.
        Args:
            bucket (str): Bucket name
            prefix (str): Key to destination item
        """
        s3_res = boto3.Session().resource("s3")
        my_bucket = s3_res.Bucket(p_bucket)
        for item in my_bucket.objects.filter(Prefix=p_prefix):
            item.delete()

    def months_between_dates(self, start_date_str, end_date_str):
        start_date = datetime.strptime(start_date_str, "%Y-%m-%d")
        end_date = datetime.strptime(end_date_str, "%Y-%m-%d")

        current_date = start_date
        while current_date <= end_date:
            yield str(current_date.year), str(current_date.month).zfill(2)
            current_date += relativedelta(months=1)


    def delete_current_files_s3(self, s3_bucket, config, partition_year, partition_month):
        s3_path =  config['s3_prefix'] 

        for mch_id in config['machine_id']:
            s3_prefix = f"{s3_path}{mch_id}/partition_year={partition_year}/partition_month={partition_month}/"
            self.delete_from_s3(s3_bucket, s3_prefix)
            print(f"path deleted : s3://{s3_bucket}/{s3_prefix}")