
ASSEMBLY_CRANK_TABLE = "CREATE EXTERNAL TABLE IF NOT EXISTS `msil_epto_etl`.`assembly_crank_v1`( \
  `engine_prefix` string, \
  `engine_no` string, \
  `engine_short_code` string, \
  `start_date` string, \
  `complete_date` string,\
  `pl_start_trq` double, \
  `pl_ave_trq` double, \
  `pl_max_trq_dou` double,\
  `sys_date` string, \
  `sys_date_time` string) \
PARTITIONED BY ( \
  `mcpm_mcid` string,\
  `partition_year` string, \
  `partition_month` string)\
ROW FORMAT SERDE \
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe' \
STORED AS INPUTFORMAT \
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat' \
OUTPUTFORMAT \
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'\
LOCATION\
  's3://{base_table_name}/extracted_data/assembly_crank_v1'\
TBLPROPERTIES (\
  'auto.purge'='false', \
  'has_encrypted_data'='false', \
  'numFiles'='-1', \
  'parquet.compression'='SNAPPY', \
  'presto_query_id'='20231128_083413_00007_9d4sk', \
  'presto_version'='0.215-19754-g6bc6b86', \
  'totalSize'='-1', \
  'transactional'='false');"

ASSEMBLY_CRANK_TABLE_LOCATION = 'f"s3://{base_table_name}/extracted_data/assembly_crank_v1"'
 
MACHINING_CYLINDER_HEAD_CAM_BORE_TABLE = "CREATE EXTERNAL TABLE IF NOT EXISTS `msil_epto_etl`.`machining_cylinder_head_cam_bore_v1`( \
  `serial_number` string, \
  `cam_hole_int2_23_x_effective_value` double, \
  `cam_hole_int2_23_y_effective_value` double, \
  `cam_hole_int3_23_x_effective_value` double, \
  `cam_hole_int3_23_y_effective_value` double, \
  `cam_hole_int4_23_x_effective_value` double, \
  `cam_hole_int4_23_y_effective_value` double, \
  `cam_hole_int5_23_x_effective_value` double, \
  `cam_hole_int5_23_y_effective_value` double, \
  `cam_hole_int6_23_x_effective_value` double, \
  `cam_hole_int6_23_y_effective_value` double, \
  `cam_hole_exh2_23_x_effective_value` double, \
  `cam_hole_exh2_23_y_effective_value` double, \
  `cam_hole_exh3_23_x_effective_value` double, \
  `cam_hole_exh3_23_y_effective_value` double, \
  `cam_hole_exh4_23_x_effective_value` double, \
  `cam_hole_exh4_23_y_effective_value` double, \
  `cam_hole_exh5_23_x_effective_value` double, \
  `cam_hole_exh5_23_y_effective_value` double, \
  `guide_hole_int5_front_side_x_effective_value` double, \
  `guide_hole_int5_front_side_y_effective_value` double, \
  `guide_hole_int5_back_side_x_effective_value` double, \
  `guide_hole_int5_back_side_y_effective_value` double, \
  `guide_hole_exh5_front_side_x_effective_value` double, \
  `guide_hole_exh5_front_side_y_effective_value` double, \
  `guide_hole_exh5_back_side_x_effective_value` double, \
  `guide_hole_exh5_back_side_y_effective_value` double, \
  `sys_date` string, \
  `sys_date_time` string)\
PARTITIONED BY ( \
  `mcpm_mcid` string, \
  `partition_year` string, \
  `partition_month` string)\
ROW FORMAT SERDE \
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe' \
STORED AS INPUTFORMAT \
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat' \
OUTPUTFORMAT \
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'\
LOCATION \
  's3://{base_table_name}/extracted_data/machining_cylinder_head_cam_bore_v1' \
TBLPROPERTIES (\
  'auto.purge'='false', \
  'has_encrypted_data'='false', \
  'numFiles'='-1', \
  'parquet.compression'='SNAPPY', \
  'presto_query_id'='20231201_040926_00036_fwm8f', \
  'presto_version'='0.215-19754-g6bc6b86', \
  'totalSize'='-1', \
  'transactional'='false');"                                                                                                                

MACHINING_CYLINDER_HEAD_CAM_BORE_TABLE_LOCATION = 'f"s3://{base_table_name}/extracted_data/machining_cylinder_head_cam_bore_v1"'

MACHINING_CYLINDER_BLOCK_BORE_TABLE = "CREATE EXTERNAL TABLE IF NOT EXISTS `msil_epto_etl`.`machining_cylinder_block_bore_data_v1`(\
  `machining_serial_number` string, \
  `model_number` string, \
  `total_judgment` string,  \
  `no1_bore_measurement_value` double, \
  `no2_bore_measurement_value` double, \
  `no3_bore_measurement_value` double, \
  `no4_bore_measurement_value` double, \
  `sys_date` string, \
  `sys_date_time` string)\
PARTITIONED BY ( \
  `mcpm_mcid` string, \
  `partition_year` string, \
  `partition_month` string)\
ROW FORMAT SERDE \
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe' \
STORED AS INPUTFORMAT \
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat' \
OUTPUTFORMAT \
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'\
LOCATION\
  's3://{base_table_name}/extracted_data/machining_cylinder_block_bore_data_v1'\
TBLPROPERTIES (\
  'auto.purge'='false', \
  'has_encrypted_data'='false', \
  'numFiles'='-1', \
  'parquet.compression'='SNAPPY', \
  'presto_query_id'='20231201_051055_00022_6qjpy', \
  'presto_version'='0.215-19754-g6bc6b86', \
  'totalSize'='-1', \
  'transactional'='false')"

MACHINING_CYLINDER_BLOCK_BORE_TABLE_LOCATION = 'f"s3://{base_table_name}/extracted_data/machining_cylinder_block_bore_data_v1"'


MACHINING_CAM_SHAFT_ROTOR_TABLE = "CREATE EXTERNAL TABLE IF NOT EXISTS `msil_epto_etl`.`machining_cam_shaft_rotor_v1`(\
  `serial_number` string, \
  `line_name` string, \
  `qc_check_component` string, \
  `rotor_press_fitting_load` double, \
  `plug_press_fitting_load` double, \
  `rotor_press_length` double, \
  `rotor_press_fitting_angle` double, \
  `sys_date` string, \
  `sys_date_time` string)\
PARTITIONED BY ( \
  `mcpm_mcid` string, \
  `partition_year` string, \
  `partition_month` string)\
ROW FORMAT SERDE \
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe' \
STORED AS INPUTFORMAT \
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat' \
OUTPUTFORMAT \
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'\
LOCATION\
  's3://{base_table_name}/extracted_data/machining_cam_shaft_rotor_v1'\
TBLPROPERTIES (\
  'auto.purge'='false', \
  'has_encrypted_data'='false', \
  'numFiles'='-1', \
  'parquet.compression'='SNAPPY', \
  'presto_query_id'='20231205_081816_00051_98t4v', \
  'presto_version'='0.215-19754-g6bc6b86', \
  'totalSize'='-1', \
  'transactional'='false')"

MACHINING_CAM_SHAFT_ROTOR_TABLE_LOCATION = 'f"s3://{base_table_name}/extracted_data/machining_cam_shaft_rotor_v1"'

MACHINING_CYLINDER_BORE_JR_TABLE = "CREATE EXTERNAL TABLE IF NOT EXISTS `msil_epto_etl`.`machining_cylinder_bore_jr_data_v1`(\
  `material_serial_number` string, \
  `model_number` string, \
  `total_judgment` string, \
  `crank_journal_bore_measurement_1j_main` double, \
  `crank_journal_bore_measurement_2j_main` double, \
  `crank_journal_bore_measurement_3j_main` double, \
  `crank_journal_bore_measurement_4j_main` double, \
  `crank_journal_bore_measurement_5j_main` double, \
  `sys_date` string, \
  `sys_date_time` string)\
PARTITIONED BY ( \
  `mcpm_mcid` string, \
  `partition_year` string, \
  `partition_month` string)\
ROW FORMAT SERDE \
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe' \
STORED AS INPUTFORMAT \
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat' \
OUTPUTFORMAT \
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'\
LOCATION\
  's3://{base_table_name}/extracted_data/machining_cylinder_bore_jr_data_v1'\
TBLPROPERTIES (\
  'auto.purge'='false', \
  'has_encrypted_data'='false', \
  'numFiles'='-1', \
  'parquet.compression'='SNAPPY', \
  'presto_query_id'='20231201_094946_00096_qexqx', \
  'presto_version'='0.215-19754-g6bc6b86', \
  'totalSize'='-1', \
  'transactional'='false')"

MACHINING_CYLINDER_BORE_JR_TABLE_LOCATION = 'f"s3://{base_table_name}/extracted_data/machining_cylinder_bore_jr_data_v1"'


MACHINING_CRANK_SHAFT_MEASUREMENT_TABLE = "CREATE EXTERNAL TABLE IF NOT EXISTS `msil_epto_etl`.`machining_crank_shaft_measurement_v1`(\
  `serial_number2` string, \
  `line_name` string, \
  `qc_check_component` string, \
  `j1_diameter` string, \
  `j2_diameter` string, \
  `j3_diameter` string, \
  `j4_diameter` string, \
  `j5_diameter` string, \
  `p1_diameter` string, \
  `p2_diameter` string, \
  `p3_diameter` string, \
  `p4_diameter` string, \
  `p1_half_storke` string, \
  `p2_half_storke` string, \
  `p3_half_storke` string, \
  `p4_half_storke` string, \
  `front_shaft_diameter` string, \
  `rear_flange_diameter` string, \
  `sensor_plate_diameter` string, \
  `thurst_width` string, \
  `sys_date` string, \
  `sys_date_time` string)\
PARTITIONED BY ( \
  `mcpm_mcid` string, \
  `partition_year` string, \
  `partition_month` string)\
ROW FORMAT SERDE \
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe' \
STORED AS INPUTFORMAT \
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat' \
OUTPUTFORMAT \
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat' \
LOCATION\
  's3://{base_table_name}/extracted_data/machining_crank_shaft_measurement_v1'\
TBLPROPERTIES (\
  'auto.purge'='false', \
  'has_encrypted_data'='false', \
  'numFiles'='-1', \
  'parquet.compression'='SNAPPY', \
  'presto_query_id'='20231206_055601_00041_jajw9', \
  'presto_version'='0.215-19754-g6bc6b86', \
  'totalSize'='-1', \
  'transactional'='false')"

MACHINING_CRANK_SHAFT_MEASUREMENT_TABLE_LOCATION = 'f"s3://{base_table_name}/extracted_data/machining_crank_shaft_measurement_v1"'

MACHINING_CAM_SHAFT_MEASUREMENT_TABLE = "CREATE EXTERNAL TABLE IF NOT EXISTS `msil_epto_etl`.`machining_cam_shaft_measurement_v1`(\
  `serial_no` string, \
  `line_name` string, \
  `qc_check_component` string, \
  `front_dia` double, \
  `j1f_dia` double, \
  `j1r_dia` double, \
  `j2_dia` double, \
  `j3_dia` double, \
  `j4_dia` double, \
  `j5_dia` double, \
  `rear_dia` double,\
  `l1_len` double, \
  `c1_ch` double, \
  `c2_ch` double, \
  `c3_ch` double, \
  `c4_ch` double, \
  `c5_ch` double, \
  `c6_ch` double, \
  `c7_ch` double, \
  `c8_ch` double, \
  `c1_ca_ctr` double, \
  `c2_ca_ctr` double, \
  `c3_ca_ctr` double, \
  `c4_ca_ctr` double, \
  `c5_ca_ctr` double, \
  `c6_ca_ctr` double, \
  `c7_ca_ctr` double, \
  `c8_ca_ctr` double, \
  `sys_date` string, \
  `sys_date_time` string)\
PARTITIONED BY ( \
  `mcpm_mcid` string, \
  `partition_year` string, \
  `partition_month` string)\
ROW FORMAT SERDE \
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe' \
STORED AS INPUTFORMAT \
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat' \
OUTPUTFORMAT \
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'\
LOCATION\
  's3://{base_table_name}/extracted_data/machining_cam_shaft_measurement_v1'\
TBLPROPERTIES (\
  'auto.purge'='false', \
  'has_encrypted_data'='false', \
  'numFiles'='-1', \
  'parquet.compression'='SNAPPY', \
  'presto_query_id'='20231205_100026_00007_6rm2t', \
  'presto_version'='0.215-19754-g6bc6b86', \
  'totalSize'='-1', \
  'transactional'='false')"

MACHINING_CAM_SHAFT_MEASUREMENT_TABLE_LOCATION = 'f"s3://{base_table_name}/extracted_data/machining_cam_shaft_measurement_v1"'


MACHINING_CYLINDER_BORE_JR_MAPPING_TABLE = "CREATE EXTERNAL TABLE IF NOT EXISTS `msil_epto_etl`.`machining_cylinder_bore_jr_mapping_v1`(\
  `material_serial_number` string, \
  `machining_serial_number` string, \
  `sys_date` string, \
  `sys_date_time` string)\
PARTITIONED BY ( \
  `mcpm_mcid` string, \
  `partition_year` string, \
  `partition_month` string)\
ROW FORMAT SERDE \
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe' \
STORED AS INPUTFORMAT \
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat' \
OUTPUTFORMAT \
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'\
LOCATION\
  's3://{base_table_name}/extracted_data/machining_cylinder_bore_jr_mapping_v1'\
TBLPROPERTIES (\
  'auto.purge'='false', \
  'has_encrypted_data'='false', \
  'numFiles'='-1', \
  'parquet.compression'='SNAPPY', \
  'presto_query_id'='20231206_072730_00123_vhbze', \
  'presto_version'='0.215-19754-g6bc6b86', \
  'totalSize'='-1', \
  'transactional'='false')"

MACHINING_CYLINDER_BORE_JR_MAPPING_TABLE_LOCATION = 'f"s3://{base_table_name}/extracted_data/machining_cylinder_bore_jr_mapping_v1"'


MTB_ATHENA_TABLE = "CREATE EXTERNAL TABLE IF NOT EXISTS `msil_epto_etl`.`mtb_athena_table_data_v1`(\
  `engine_no` string, \
  `bench_no` string, \
  `engine_code` string, \
  `engine_spec` string, \
  `serial_no` string, \
  `result` string, \
  `operator` string, \
  `m1_trq` string, \
  `m1_trq_1` string, \
  `m2_cyl1` string, \
  `m2_cyl2` string, \
  `m2_cyl3` string, \
  `m2_cyl4` string, \
  `m2_oilprs` string, \
  `m2_crank` string, \
  `m2_in_cam` string, \
  `m2_ex_cam` string, \
  `m3_oilprs` string, \
  `m4_oilprs` string)\
PARTITIONED BY ( \
  `mtbfile` string, \
  `partition_year` string, \
  `partition_month` string, \
  `partition_date` string)\
ROW FORMAT SERDE \
  'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe' \
STORED AS INPUTFORMAT \
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat' \
OUTPUTFORMAT \
  'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'\
LOCATION\
  's3://{base_table_name}/extracted_data/mtb_athena_table_data_v1'\
TBLPROPERTIES (\
  'classification'='parquet', \
  'parquet.compression'='SNAPPY', \
  'transient_lastDdlTime'='1701947377')"


MTB_ATHENA_TABLE_LOCATION = 'f"s3://{base_table_name}/extracted_data/mtb_athena_table_data_v1"'