class SqlQueryEPTO:
    def __init__(self):
        pass

    def get_query_assembly_crank_table(
        self,
        machine_ids_str: str,
        partition_year: str,
        partition_month:str
    ) -> str:
        """ 
        This function use python f-string to return a SQL query for Assembly table.
        """
        sql_query = f"""insert into "msil_epto_etl"."assembly_crank_v1"
                        with cte_tran as 
                        (select mcpm_mcid, mcpm_data_string, mcpm_sysdate from msil_datalake_curated_sr7_dblink.dets_de_csms_mcpm where 
                        mcpm_mcid IN ({machine_ids_str}) and partition_year= {partition_year} and partition_month = {partition_month}
                        )
                        select
                        substring(mcpm_data_string, 5, 5) as engine_prefix,
                        substring(mcpm_data_string, 10, 7) as engine_no,
                        substring(mcpm_data_string, 17, 4) as engine_short_code,
                        substring(mcpm_data_string, 21, 14) as start_date,
                        substring(mcpm_data_string, 35, 14) as complete_date,
                        CAST(substring(mcpm_data_string, 149, 4) as double)/100 as pl_start_trq,
                        CAST(substring(mcpm_data_string, 153, 4) as double)/100 as pl_ave_trq,
                        CAST(substring(mcpm_data_string, 157, 4) as double)/100 as pl_max_trq_dou,
                        DATE_FORMAT(mcpm_sysdate, '%Y%m%d') as sys_date,
                        DATE_FORMAT(mcpm_sysdate, '%Y%m%d%H%i%s') as sys_date_time,
                        mcpm_mcid,
                        DATE_FORMAT(mcpm_sysdate, '%Y') as partition_year,
                        DATE_FORMAT(mcpm_sysdate, '%m') as partition_month
                        from
                        cte_tran

                    """

        return sql_query
    
    def get_query_machining_cylinder_head_cam_bore_table(
        self,
        machine_ids_str: str,
        partition_year: str,
        partition_month:str
    ) -> str:
        """ 
        This function use python f-string to return a SQL query for Cylinder head table.
        """
        sql_query = f"""insert into msil_epto_etl.machining_cylinder_head_cam_bore_v1
                        with cte_tran as 
                        (select mcpm_mcid, mcpm_data_string, mcpm_sysdate from msil_datalake_curated_sr7_dblink.dets_de_csms_mcpm where 
                        mcpm_mcid IN ({machine_ids_str}) and partition_year= {partition_year} and partition_month = {partition_month}
                        )
                        select
                        SUBSTRING(mcpm_data_string, 1, 15) as serial_number,
                        cast(SUBSTRING(mcpm_data_string,304, 4) as double)/10 as cam_hole_int2_23_x_effective_value,
                        cast(SUBSTRING(mcpm_data_string,308, 4) as double)/10 as cam_hole_int2_23_y_effective_value,
                        cast(SUBSTRING(mcpm_data_string,312, 4) as double)/10 as cam_hole_int3_23_x_effective_value,
                        cast(SUBSTRING(mcpm_data_string,316, 4) as double)/10 as cam_hole_int3_23_y_effective_value,
                        cast(SUBSTRING(mcpm_data_string,320, 4) as double)/10 as cam_hole_int4_23_x_effective_value,
                        cast(SUBSTRING(mcpm_data_string,324, 4) as double)/10 as cam_hole_int4_23_y_effective_value,
                        cast(SUBSTRING(mcpm_data_string,328, 4) as double)/10 as cam_hole_int5_23_x_effective_value,
                        cast(SUBSTRING(mcpm_data_string,332, 4) as double)/10 as cam_hole_int5_23_y_effective_value,
                        cast(SUBSTRING(mcpm_data_string,336, 4) as double)/10 as cam_hole_int6_23_x_effective_value,
                        cast(SUBSTRING(mcpm_data_string,340, 4) as double)/10 as cam_hole_int6_23_y_effective_value,
                        cast(SUBSTRING(mcpm_data_string,344, 4) as double)/10 as cam_hole_exh2_23_x_effective_value,
                        cast(SUBSTRING(mcpm_data_string,348, 4) as double)/10 as cam_hole_exh2_23_y_effective_value,
                        cast(SUBSTRING(mcpm_data_string,352, 4) as double)/10 as cam_hole_exh3_23_x_effective_value,
                        cast(SUBSTRING(mcpm_data_string,356, 4) as double)/10 as cam_hole_exh3_23_y_effective_value,
                        cast(SUBSTRING(mcpm_data_string,360, 4) as double)/10 as cam_hole_exh4_23_x_effective_value,
                        cast(SUBSTRING(mcpm_data_string,364, 4) as double)/10 as cam_hole_exh4_23_y_effective_value,
                        cast(SUBSTRING(mcpm_data_string,368, 4) as double)/10 as cam_hole_exh5_23_x_effective_value,
                        cast(SUBSTRING(mcpm_data_string,372, 4) as double)/10 as cam_hole_exh5_23_y_effective_value,
                        cast(SUBSTRING(mcpm_data_string,376, 4) as double)/10 as guide_hole_int5_front_side_x_effective_value,
                        cast(SUBSTRING(mcpm_data_string,380, 4) as double)/10 as guide_hole_int5_front_side_y_effective_value,
                        cast(SUBSTRING(mcpm_data_string,384, 4) as double)/10 as guide_hole_int5_back_side_x_effective_value,
                        cast(SUBSTRING(mcpm_data_string,388, 4) as double)/10 as guide_hole_int5_back_side_y_effective_value,
                        cast(SUBSTRING(mcpm_data_string,392, 4) as double)/10 as guide_hole_exh5_front_side_x_effective_value,
                        cast(SUBSTRING(mcpm_data_string,396, 4) as double)/10 as guide_hole_exh5_front_side_y_effective_value,
                        cast(SUBSTRING(mcpm_data_string,400, 4) as double)/10 as guide_hole_exh5_back_side_x_effective_value,
                        cast(SUBSTRING(mcpm_data_string,404, 4) as double)/10 as guide_hole_exh5_back_side_y_effective_value,
                        DATE_FORMAT(mcpm_sysdate, '%Y%m%d') as sys_date,
                        DATE_FORMAT(mcpm_sysdate, '%Y%m%d%H%i%s') as sys_date_time,
                        mcpm_mcid,
                        DATE_FORMAT(mcpm_sysdate, '%Y') as partition_year,
                        DATE_FORMAT(mcpm_sysdate, '%m') as partition_month
                        from
                        cte_tran

                    """

        return sql_query
    
    def get_query_machining_cylinder_block_bore_table(
        self,
        machine_ids_str: str,
        partition_year: str,
        partition_month:str
    ) -> str:
        """ 
        This function use python f-string to return a SQL query for Assembly table.
        """
        sql_query = f"""insert into "msil_epto_etl"."machining_cylinder_block_bore_data_v1"
                        with cte_tran as 
                        (select mcpm_mcid, mcpm_data_string, mcpm_sysdate from msil_datalake_curated_sr7_dblink.dets_de_csms_mcpm where 
                        mcpm_mcid IN ({machine_ids_str}) and partition_year= {partition_year} and partition_month = {partition_month}
                        ) 
                        select
                        SUBSTRING(mcpm_data_string, 1, 20) as machining_serial_number,
                        SUBSTRING(mcpm_data_string, 38, 2) as model_number,
                        SUBSTRING(mcpm_data_string, 72, 1) as total_judgment,
                        cast(SUBSTRING(mcpm_data_string, 75, 3) as double)/10 as no1_bore_measurement_value,
                        cast(SUBSTRING(mcpm_data_string, 113, 3) as double)/10 as no2_bore_measurement_value,
                        cast(SUBSTRING(mcpm_data_string, 151, 3) as double)/10 as no3_bore_measurement_value,
                        cast(SUBSTRING(mcpm_data_string, 189, 3) as double)/10 as no4_bore_measurement_value,
                        DATE_FORMAT(mcpm_sysdate, '%Y%m%d') as sys_date,
                        DATE_FORMAT(mcpm_sysdate, '%Y%m%d%H%i%s') as sys_date_time,
                        mcpm_mcid,
                        DATE_FORMAT(mcpm_sysdate, '%Y') as partition_year,
                        DATE_FORMAT(mcpm_sysdate, '%m') as partition_month
                        from
                        cte_tran

                    """

        return sql_query
    
    def get_query_machining_cylinder_bore_jr_table(
        self,
        machine_ids_str: str,
        partition_year: str,
        partition_month:str
    ) -> str:
        """ 
        This function use python f-string to return a SQL query for Assembly table.
        """
        sql_query = f"""insert into "msil_epto_etl"."machining_cylinder_bore_jr_data_v1"
                        with cte_tran as 
                        (select mcpm_mcid, mcpm_data_string, mcpm_sysdate from msil_datalake_curated_sr7_dblink.dets_de_csms_mcpm where 
                        mcpm_mcid IN ({machine_ids_str}) and partition_year= {partition_year} and partition_month = {partition_month}
                        )
                        select
                        SUBSTRING(mcpm_data_string, 1, 14) as material_serial_number,
                        SUBSTRING(mcpm_data_string, 32, 2) as model_number,
                        SUBSTRING(mcpm_data_string, 99, 1) as total_judgment,
                        cast(SUBSTRING(mcpm_data_string, 102, 3) as double)/10 as Crank_journal_bore_Measurement_1J_main,
                        cast(SUBSTRING(mcpm_data_string, 113, 3) as double)/10 as Crank_journal_bore_Measurement_2J_main,
                        cast(SUBSTRING(mcpm_data_string, 124, 3) as double)/10 as Crank_journal_bore_Measurement_3J_main,
                        cast(SUBSTRING(mcpm_data_string, 135, 3) as double)/10 as Crank_journal_bore_Measurement_4J_main,
                        cast(SUBSTRING(mcpm_data_string, 146, 3) as double)/10 as Crank_journal_bore_Measurement_5J_main,
                        DATE_FORMAT(mcpm_sysdate, '%Y%m%d') as sys_date,
                        DATE_FORMAT(mcpm_sysdate, '%Y%m%d%H%i%s') as sys_date_time,
                        mcpm_mcid,
                        DATE_FORMAT(mcpm_sysdate, '%Y') as partition_year,
                        DATE_FORMAT(mcpm_sysdate, '%m') as partition_month
                        from
                        cte_tran

                    """

        return sql_query

    def get_query_machining_cam_shaft_rotor_table(
        self,
        machine_ids_str: str,
        partition_year: str,
        partition_month:str
    ) -> str:
        """ 
        This function use python f-string to return a SQL query for Assembly table.
        """
        sql_query = f"""insert into "msil_epto_etl"."machining_cam_shaft_rotor_v1"
                        with cte_tran as 
                        (select mcpm_mcid, mcpm_data_string, mcpm_sysdate from msil_datalake_curated_sr7_dblink.dets_de_csms_mcpm where 
                        mcpm_mcid IN ({machine_ids_str}) and partition_year= {partition_year} and partition_month = {partition_month}
                        )
                        select
                        SUBSTRING(mcpm_data_string, 1, 15) as serial_number,
                        SUBSTRING(mcpm_data_string, 31, 2) as line_name,
                        SUBSTRING(mcpm_data_string, 33, 1) as qc_check_component,
                        try(cast(SUBSTRING(mcpm_data_string, 290, 4) as double)/100) as rotor_press_fitting_load,
                        try(cast(SUBSTRING(mcpm_data_string, 302, 4) as double)/100) as plug_press_fitting_load,
                        try(cast(SUBSTRING(mcpm_data_string, 324, 5)  as double)/10000) as rotor_press_length,
                        try(cast(SUBSTRING(mcpm_data_string, 329, 6)  as double)/1000) as rotor_press_fitting_angle,
                        DATE_FORMAT(mcpm_sysdate, '%Y%m%d') as sys_date,
                        DATE_FORMAT(mcpm_sysdate, '%Y%m%d%H%i%s') as sys_date_time,
                        mcpm_mcid,
                        DATE_FORMAT(mcpm_sysdate, '%Y') as partition_year,
                        DATE_FORMAT(mcpm_sysdate, '%m') as partition_month
                        from
                        cte_tran
                    """

        return sql_query

    def get_query_machining_cam_shaft_measurement_table(
        self,
        machine_ids_str: str,
        partition_year: str,
        partition_month:str
    ) -> str:
        """ 
        This function use python f-string to return a SQL query for Assembly table.
        """
        sql_query = f"""insert into "msil_epto_etl"."machining_cam_shaft_measurement_v1"
                        with cte_tran as 
                        (select mcpm_mcid, mcpm_data_string, mcpm_sysdate from msil_datalake_curated_sr7_dblink.dets_de_csms_mcpm where 
                        mcpm_mcid IN ({machine_ids_str}) and partition_year= {partition_year} and partition_month = {partition_month}
                        )
                        select
                        SUBSTRING(mcpm_data_string, 1, 15) as serial_no,
                        SUBSTRING(mcpm_data_string, 31, 2) as line_name,
                        SUBSTRING(mcpm_data_string, 33, 1) as qc_check_component,
                        cast (SUBSTRING(mcpm_data_string,292, 5) as double)/1000 as front_dia,
                        cast (SUBSTRING(mcpm_data_string,309, 5) as double)/1000 as j1f_dia,
                        cast (SUBSTRING(mcpm_data_string,326, 5) as double)/1000 as j1r_dia,
                        cast (SUBSTRING(mcpm_data_string,343, 5) as double)/1000 as j2_dia,
                        cast (SUBSTRING(mcpm_data_string,360, 5) as double)/1000 as j3_dia,
                        cast (SUBSTRING(mcpm_data_string,377, 5) as double)/1000 as j4_dia,
                        cast (SUBSTRING(mcpm_data_string,394, 5) as double)/1000 as j5_dia,
                        cast (SUBSTRING(mcpm_data_string,411, 5) as double)/1000 as rear_dia,
                        cast (SUBSTRING(mcpm_data_string,691, 6) as double)/1000 as l1_len,
                        cast (SUBSTRING(mcpm_data_string,711, 5) as double)/1000 as c1_ch,
                        cast (SUBSTRING(mcpm_data_string,728, 5) as double)/1000 as c2_ch,
                        cast (SUBSTRING(mcpm_data_string,745, 5) as double)/1000 as c3_ch,
                        cast (SUBSTRING(mcpm_data_string,762, 5) as double)/1000 as c4_ch,
                        cast (SUBSTRING(mcpm_data_string,779, 5) as double)/1000 as c5_ch,
                        cast (SUBSTRING(mcpm_data_string,796, 5) as double)/1000 as c6_ch,
                        cast (SUBSTRING(mcpm_data_string,813, 5) as double)/1000 as c7_ch,
                        cast (SUBSTRING(mcpm_data_string,830, 5) as double)/1000 as c8_ch,
                        cast (SUBSTRING(mcpm_data_string,1080, 5) as double)/100 as c1_ca_ctr,
                        cast (SUBSTRING(mcpm_data_string,1097, 5) as double)/100 as c2_ca_ctr,
                        cast (SUBSTRING(mcpm_data_string,1114, 5) as double)/100 as c3_ca_ctr,
                        cast (SUBSTRING(mcpm_data_string,1131, 5) as double)/100 as c4_ca_ctr,
                        cast (SUBSTRING(mcpm_data_string,1148, 5) as double)/100 as c5_ca_ctr,
                        cast (SUBSTRING(mcpm_data_string,1165, 5) as double)/100 as c6_ca_ctr,
                        cast (SUBSTRING(mcpm_data_string,1182, 5) as double)/100 as c7_ca_ctr,
                        cast (SUBSTRING(mcpm_data_string,1199, 5) as double)/100 as c8_ca_ctr,
                        DATE_FORMAT(mcpm_sysdate, '%Y%m%d') as sys_date,
                        DATE_FORMAT(mcpm_sysdate, '%Y%m%d%H%i%s') as sys_date_time,
                        mcpm_mcid,
                        DATE_FORMAT(mcpm_sysdate, '%Y') as partition_year,
                        DATE_FORMAT(mcpm_sysdate, '%m') as partition_month
                        from
                        cte_tran
                    """

        return sql_query

    def get_query_machining_crank_shaft_measurement_table(
        self,
        machine_ids_str: str,
        partition_year: str,
        partition_month:str
    ) -> str:
        """ 
        This function use python f-string to return a SQL query for Assembly table.
        """
        sql_query = f""" insert into "msil_epto_etl"."machining_crank_shaft_measurement_v1"
                        with cte_tran as 
                        (select mcpm_mcid, mcpm_data_string, mcpm_sysdate from msil_datalake_curated_sr7_dblink.dets_de_csms_mcpm where 
                        mcpm_mcid IN ({machine_ids_str}) and partition_year= {partition_year} and partition_month = {partition_month}
                        )
                        select
                        SUBSTRING(mcpm_data_string, 13, 26) as serial_number2,
                        SUBSTRING(mcpm_data_string, 53, 2) as line_name,
                        SUBSTRING(mcpm_data_string, 55, 1) as qc_check_component,
                        SUBSTRING(mcpm_data_string,312, 5) as j1_diameter,
                        SUBSTRING(mcpm_data_string,328, 5) as j2_diameter,
                        SUBSTRING(mcpm_data_string,344, 5) as j3_diameter,
                        SUBSTRING(mcpm_data_string,360, 5) as j4_diameter,
                        SUBSTRING(mcpm_data_string,376, 5) as j5_diameter,
                        SUBSTRING(mcpm_data_string,464, 5) as p1_diameter,
                        SUBSTRING(mcpm_data_string,484, 5) as p2_diameter,
                        SUBSTRING(mcpm_data_string,504, 5) as p3_diameter,
                        SUBSTRING(mcpm_data_string,524, 5) as p4_diameter,
                        SUBSTRING(mcpm_data_string,544, 5) as p1_half_storke,
                        SUBSTRING(mcpm_data_string,559, 5) as p2_half_storke,
                        SUBSTRING(mcpm_data_string,574, 5) as p3_half_storke,
                        SUBSTRING(mcpm_data_string,589, 5) as p4_half_storke,
                        SUBSTRING(mcpm_data_string,604, 5) as front_shaft_diameter,
                        SUBSTRING(mcpm_data_string,619, 5) as rear_flange_diameter,
                        SUBSTRING(mcpm_data_string,634, 5) as sensor_plate_diameter,
                        SUBSTRING(mcpm_data_string,694, 5) as thurst_width,
                        DATE_FORMAT(mcpm_sysdate, '%Y%m%d') as sys_date,
                        DATE_FORMAT(mcpm_sysdate, '%Y%m%d%H%i%s') as sys_date_time,
                        mcpm_mcid,
                        DATE_FORMAT(mcpm_sysdate, '%Y') as partition_year,
                        DATE_FORMAT(mcpm_sysdate, '%m') as partition_month
                        from
                        cte_tran
                    """

        return sql_query

    def get_query_machining_cylinder_bore_jr_mapping_table(
        self,
        machine_ids_str: str,
        partition_year: str,
        partition_month:str
    ) -> str:
        """ 
        This function use python f-string to return a SQL query for Assembly table.
        """
        sql_query = f""" insert into "msil_epto_etl"."machining_cylinder_bore_jr_mapping_v1"
                        with cte_tran as 
                        (select mcpm_mcid, mcpm_data_string, mcpm_sysdate from msil_datalake_curated_sr7_dblink.dets_de_csms_mcpm where 
                        mcpm_mcid IN ({machine_ids_str}) 
                        and partition_year= {partition_year} and partition_month = {partition_month}
                        )
                        select
                        SUBSTRING(mcpm_data_string, 1, 14) as material_serial_number,
                        SUBSTRING(mcpm_data_string, 15, 20) as machining_serial_number,
                        DATE_FORMAT(mcpm_sysdate, '%Y%m%d') as sys_date,
                        DATE_FORMAT(mcpm_sysdate, '%Y%m%d%H%i%s') as sys_date_time,
                        mcpm_mcid,
                        DATE_FORMAT(mcpm_sysdate, '%Y') as partition_year,
                        DATE_FORMAT(mcpm_sysdate, '%m') as partition_month
                        from cte_tran
                    """

        return sql_query

    