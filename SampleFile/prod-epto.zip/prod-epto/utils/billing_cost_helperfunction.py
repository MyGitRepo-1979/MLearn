import boto3
import json
import csv
import os
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from dateutil.rrule import rrule, MONTHLY
import pandas as pd

dtype_dict = {
    'accountnumber': 'string',
    'date': 'datetime64[ns]',
    'service': 'string',
    'servicecost': 'float64',
    'unit': 'string'
}
consolidated_df = pd.DataFrame(columns=list(dtype_dict.keys())).astype(dtype_dict)

##################################################################################################################
#### List the number of months between start and end date
def get_date_list(start_dt , end_dt):
    start_dt = datetime.strptime(start_dt, '%Y-%m-%d')
    start_dt = start_dt - relativedelta(days=start_dt.day-1)
    end_dt = datetime.strptime(end_dt, '%Y-%m-%d')
    end_dt = end_dt - relativedelta(days=end_dt.day-1)
    dates_list = [( dt.date(),dt.date()+ relativedelta(months=1)) for dt in rrule(MONTHLY, dtstart=start_dt, until=end_dt)]
    return dates_list

##################################################################################################################
#### get the account ID
def get_account_id():
    client = boto3.client("sts")
    return client.get_caller_identity()["Account"]

##################################################################################################################
#### Generate the dataframe with columns account_number,  date, service_name,  service_cost, unit
def create_dataframe(cost_data, account_num, consolidated_df):
    for item in cost_data:
        date = pd.to_datetime(item['TimePeriod']['Start']).date()
        # print(date)
        for group in item['Groups']:
            account_number = account_num
            service_name = group['Keys'][0]
            service_cost = float(group['Metrics']['UnblendedCost']['Amount'])
            service_cost = round(service_cost, 2)
            unit = group['Metrics']['UnblendedCost']['Unit']
            df_new_row = pd.DataFrame({'accountnumber': account_number, 'date': date, 'service': service_name, 'servicecost': service_cost,
                 'unit': unit},index=[1])
            consolidated_df = pd.concat([consolidated_df, df_new_row],ignore_index=False)
            # consolidated_df = consolidated_df.append(
            #     {'accountnumber': account_number, 'date': date, 'service': service_name, 'servicecost': service_cost,
            #      'unit': unit}, ignore_index=True)
    return consolidated_df

##################################################################################################################
#### Get the cost of account for a month for each service using cost explorer
def get_cost_data(ce_client,start_date,end_date):
    data = ce_client.get_cost_and_usage(
        # Monthly cost and grouped by Account and Service
        TimePeriod={'Start': start_date, 'End': end_date},
        Granularity='MONTHLY',
        Metrics=['UnblendedCost'],
        GroupBy=[{'Type': 'DIMENSION', 'Key': 'SERVICE'}])
    results = data['ResultsByTime']
    account_id = get_account_id()
    final_df = create_dataframe(results, account_id, consolidated_df)
    return final_df