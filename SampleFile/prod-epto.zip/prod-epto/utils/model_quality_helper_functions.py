import numpy as np
import logging

log = logging.getLogger(__name__)
logging.basicConfig(format='%(asctime)s :: %(message)s', level=logging.INFO)
logging.info("info")


def rsqr_calc(y_actual,y_pred):
    """
    Methods helps to calculate Rsquared score of the inputs provided
    :param y_actual: Series of column with actual value
    :param y_pred: Series of column with predicted value
    :return: string : Rsquared score of the inputs provided
    """
    y_bar = y_actual.mean()
    ss_tot = ((y_actual-y_bar)**2).sum()
    ss_res = ((y_actual-y_pred)**2).sum()
    rsqr_score=1 - (ss_res/ss_tot)
    rsqr_score= "{:.2f}".format(rsqr_score)
    log.info('Rsqr_score value is :',rsqr_score)
    return rsqr_score
    
def rmse_calc(y_actual,y_pred):
    """
    Methods helps to calculate Root mean square error score of the inputs provided
    :param y_actual: Series of column with actual value
    :param y_pred: Series of column with predicted value
    :return: string : Root mean square error score of the inputs provided
    """
    rmse=np.sqrt((np.square(y_actual - y_pred)).mean())
    rmse= "{:.2f}".format(rmse)
    log.info('RMSE value is :',rmse)
    return rmse