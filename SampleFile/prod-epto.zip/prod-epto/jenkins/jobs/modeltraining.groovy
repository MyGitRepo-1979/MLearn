multibranchPipelineJob('MSIL_Analytics_ACE/prod-epto/modelops-model-step-function-orchestrator') {

    branchSources {
        branchSource {
            source {
                github {
                     id('modelops-model-step-function-orchestrator')
                     repositoryUrl ('prod-epto')
                     repository('prod-epto')
                     credentialsId('msil-github')
                     configuredByUrl(false)
                     repoOwner('MSIL-Analytics-ACE')
                      traits {
                           headWildcardFilter {
                            includes('main production uat')
                            excludes('release')
                           }
                            gitHubBranchDiscovery {
                                strategyId(1)
                            }
                        }
                    }
                strategy {
                defaultBranchPropertyStrategy {
                    props {
                        noTriggerBranchProperty()
                    }
                }
            }
        }
    }

configure {
    it / factory(class: 'org.jenkinsci.plugins.workflow.multibranch.WorkflowBranchProjectFactory') {
        owner(class: 'org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject', reference: '../..')
        scriptPath('jenkins/pipelines/ModelTraining.Jenkinsfile')
    }
}
    orphanedItemStrategy {
        discardOldItems {
            numToKeep(20)
        }
    }
  }
}