import boto3
import json
from datetime import datetime
import pprint
import re


class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, datetime):
            return o.isoformat()
        return super().default(o)

session = boto3.Session(profile_name="sprs-msil")
glue_client = session.client('glue')
# Read the file containing Glue job names
wf_file_path = 'glue_wf.txt'  # Replace with your file path
wf_output_file_path = 'glue_wf.config.json'  # Replace with your desired output file path



def render_glue_workflow_config(wf_name, output_file):
    try:
        response = glue_client.get_workflow(Name=wf_name ,  IncludeGraph=True)


        trigger_dict ={}
        wf_dict = {}
        cnt = 0 
        

        if 'Description' in response['Workflow'].keys():
            wf_dict["description"] = response['Workflow']['Description']
        else:
            wf_dict["description"] = ''

        wf_dict["default_run_properties"] = response['Workflow']['DefaultRunProperties']
        wf_dict["max_concurrent_runs"] = ''

        if 'MaxConcurrentRuns' in response['Workflow'].keys():
            wf_dict["max_concurrent_runs"] = response['Workflow']['MaxConcurrentRuns']
        else:
            wf_dict["max_concurrent_runs"] = 1


        for i in response['Workflow']['Graph']['Nodes']:
            

            if i['Type'] == 'TRIGGER':
                # print("========================================================")
                # print(type(i))
                # pprint.pprint(i)
                # print("000000000000000000000000000000000000000000000000000000000")
                cnt+=1
                print (f"Trigger msg for {cnt}: {trigger_dict}")

                triggerkey = i["TriggerDetails"]["Trigger"]['Name']
                value = i["TriggerDetails"]["Trigger"]

                print(value)

                # print(i["TriggerDetails"]["Trigger"])
                internal_dict = {}
                wf_dict["triggers"] = trigger_dict
                
                internal_dict["type"] = i["TriggerDetails"]["Trigger"]["Type"]
                if i["TriggerDetails"]["Trigger"]["Type"] == 'SCHEDULED':
                    internal_dict["schedule"] = i["TriggerDetails"]["Trigger"]["Schedule"]
                    internal_dict["enabled"] = "false"
                elif i["TriggerDetails"]["Trigger"]["Type"] == 'CONDITIONAL':   
                    
                    # internal_dict["predicate"] = i["TriggerDetails"]["Trigger"]['Predicate']
                    new_action_content_dict = {}
                    for (predicatekey, predicatevalue) in i["TriggerDetails"]["Trigger"]['Predicate'].items():
                        new_predicate_dict = {}
                        print(f"predicatekey: {predicatekey}")
                        new_predicate_key = re.sub(r'(?<!^)(?=[A-Z])', '_', predicatekey).lower()
                        print(f"new_predicate_key: {new_predicate_key}")
                        new_action_content_dict[new_predicate_key] = predicatevalue
                        print(f"New predicate dictionary : {new_action_content_dict}")

                    internal_dict["predicate"] = new_action_content_dict
                    if 'conditions' in new_action_content_dict.keys():
                        

                        predicate_condition_lst = []
                        for condition_lst in new_action_content_dict["conditions"]:
                            
                            print(f" Internal of  Actions content  : {j}")
                            new_internal_condition_dict = {}
                            for (conditionkey, conditionvalue) in condition_lst.items():
                                
                                print(f"conditionkey: {conditionkey}")
                                new_condition_key = re.sub(r'(?<!^)(?=[A-Z])', '_', conditionkey).lower()
                                print(f"new predicate condition key: {new_condition_key}")
                                new_internal_condition_dict[new_condition_key] = conditionvalue
                                print(f"New predicate condiiton dictionary : {new_internal_condition_dict}")

                                
                            print("appending predicate condition list")
                            predicate_condition_lst.append(new_internal_condition_dict)
                            print(f"actions_list: {actions_list}")
                        new_action_content_dict['conditions'] = predicate_condition_lst


                
                
                # internal_dict["actions"] = i["TriggerDetails"]["Trigger"]["Actions"]
                actions_list = []

                for j in i["TriggerDetails"]["Trigger"]["Actions"]:
                    print(type(j))
                    print(f" Internal of  Actions content  : {j}")
                    new_action_content_dict = {}
                    for (key, value) in j.items():
                        
                        print(f"key: {key}")
                        new_key = re.sub(r'(?<!^)(?=[A-Z])', '_', key).lower()
                        print(f"new_key: {key}")
                        new_action_content_dict[new_key] = value
                        print(f"New dictionary ")

                        print(new_action_content_dict)
                    print("appending actino_list")
                    actions_list.append(new_action_content_dict)
                    print(f"actions_list: {actions_list}")
                    

                    
                # internal_dict["actions"] = i["TriggerDetails"]["Trigger"]["Actions"]
                internal_dict["actions"] = actions_list

                print(f"internal_dict: {internal_dict}")

                # pprint.pprint({key:value} )

                # print(internal_dict)
                trigger_dict.update({triggerkey:internal_dict})

                

                # print(type(i["TriggerDetails"]["Trigger"]))

            
        


        final_dict= {wf_name : wf_dict}

        # final_dict.update

        # print("======================FinalData==================")
        # pprint.pprint(final_dict)

        # pprint.pprint({"workflows":final_dict})


        output_file.write(json.dumps({wf_name : wf_dict}, indent=2, cls=DateTimeEncoder))
        output_file.write("\n\n")
        print(f"Configuration for Glue wf '{wf_name}' has been appended to the output file in JSON format.")
    except glue_client.exceptions.EntityNotFoundException:
        output_file.write(f"Glue workflow '{wf_name}' not found.\n")
    except Exception as e:
        output_file.write(f"An error occurred while fetching the configuration of Glue wf '{wf_name}': {str(e)}\n")



with open(wf_file_path, 'r') as job_file, open(wf_output_file_path, 'w') as output_file:
    workflow_names = [line.strip() for line in job_file]

    final_dict = {}
    # Render the configuration for each Glue job and append it to the output file in JSON format
    for wf_name in workflow_names:
        render_glue_workflow_config(wf_name, output_file)

print("All Glue job configurations have been appended to the output file in JSON format.")
