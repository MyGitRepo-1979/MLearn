import boto3
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os

# AWS SES Configuration
SENDER_EMAIL = "happiestminds_ramakrishna.rayudu@maruti.co.in"  # Must be a verified identity in SES
RECIPIENT_EMAIL = "happiestminds_ramakrishna.rayudu@maruti.co.in"  # Replace with actual recipient
AWS_REGION = "ap-south-1"  # Change based on your SES region
SUBJECT = f"SonarQube Quality Gate Report - {PROJECT_KEY}"
BODY_TEXT = f"""Hello,

The SonarQube quality gate report for project '{PROJECT_KEY}' is attached.

Best Regards,
DevOps Team
"""

# Create the email
msg = MIMEMultipart()
msg["From"] = SENDER_EMAIL
msg["To"] = RECIPIENT_EMAIL
msg["Subject"] = SUBJECT

# Attach the body text
msg.attach(MIMEText(BODY_TEXT, "plain"))

# Attach the Excel report
attachment_path = f"{PROJECT_KEY}_quality_report.xlsx"
if os.path.exists(attachment_path):
    with open(attachment_path, "rb") as attachment:
        part = MIMEBase("application", "octet-stream")
        part.set_payload(attachment.read())
        encoders.encode_base64(part)
        part.add_header("Content-Disposition", f"attachment; filename={os.path.basename(attachment_path)}")
        msg.attach(part)

# Send email using AWS SES
ses_client = boto3.client("ses", region_name=AWS_REGION)

try:
    response = ses_client.send_raw_email(
        Source=SENDER_EMAIL,
        Destinations=[RECIPIENT_EMAIL],
        RawMessage={"Data": msg.as_string()},
    )
    print("Email sent successfully! Message ID:", response["MessageId"])
except Exception as e:
    print("Error sending email:", str(e))
