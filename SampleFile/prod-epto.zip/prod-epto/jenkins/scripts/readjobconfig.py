import boto3
import json
from datetime import datetime
import re


class DateTimeEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, datetime):
            return o.isoformat()
        return super().default(o)

session = boto3.Session(profile_name="sprs-msil")
glue_client = session.client('glue')
# Read the file containing Glue job names
file_path = 'glue_jobs.txt'  # Replace with your file path
output_file_path = 'glue_job_configs.json'  # Replace with your desired output file path


def render_glue_job_config(job_name, output_file,overall_result):
    try:

        job_name = job_names.pop(0)
        response = glue_client.get_job(JobName=job_name)


        final_dict = {}
        
        final_dict["file_name"] = response['Job']["Name"]+ ".py"
        final_dict["description"]= response['Job']["Description"]
        final_dict["glue_version"]= response['Job']["GlueVersion"]
        final_dict["role_arn"]= response['Job']["Role"]
        final_dict["number_of_workers"]= response['Job']["NumberOfWorkers"]
        final_dict["worker_type"]= response['Job']["WorkerType"]
        final_dict["timeout"]= response['Job']["Timeout"]
        
        final_dict["type"] =response['Job']["Command"]["Name"]
        final_dict["python_version"] =response['Job']["Command"]["PythonVersion"]
        if "Connections" in response["Job"].keys():
            print("Enterd connection string")
            final_dict["connections"]=  response['Job']["Connections"]["Connections"]
        final_dict["default_arguments"]= response['Job']["DefaultArguments"]

        job_name = job_name.replace("ACE-SparePricingRecommendation_", "").replace("SparePricingRecommendation_","").replace("-","_").lower() 
        overall_result.update({job_name: final_dict})
        print(f"Configuration for Glue job '{job_name}' has been appended to the output file in JSON format.")
        if len(job_names) >0:
            render_glue_job_config(job_names, output_file , overall_result)

        else:
            output_file.write(json.dumps({"jobs":overall_result}, indent=2, cls=DateTimeEncoder))
            output_file.write("\n\n")
            
    except glue_client.exceptions.EntityNotFoundException:
        output_file.write(f"Glue job '{job_name}' not found.\n")
        output_file.write(json.dumps({"jobs":overall_result}, indent=2, cls=DateTimeEncoder))
    except Exception as e:
        output_file.write(f"An error occurred while fetching the configuration of Glue job '{job_name}': {str(e)}\n")
        output_file.write(json.dumps({"jobs":overall_result}, indent=2, cls=DateTimeEncoder))



with open(file_path, 'r') as job_file, open(output_file_path, 'w') as output_file:
    job_names = [line.strip() for line in job_file]

    overall_result = {}
    render_glue_job_config(job_names, output_file , overall_result)


print("All Glue job configurations have been appended to the output file in JSON format.")
