import requests
import json
import argparse
import pandas as pd
import boto3
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import os

# Argument parser for command-line arguments
parser = argparse.ArgumentParser(description="Fetch data from SonarQube API and generate an Excel report")
parser.add_argument("sonarqube_url", help="SonarQube server URL")
parser.add_argument("sonarqube_token", help="SonarQube personal access token")
parser.add_argument("project_key", help="SonarQube project key")
parser.add_argument("sender_email", help="Sender email (Must be verified in AWS SES)")
parser.add_argument("recipient_email", help="Recipient email")
parser.add_argument("aws_region", help="AWS region for SES")
args = parser.parse_args()

# SonarQube Server Details
SONARQUBE_URL = args.sonarqube_url
SONARQUBE_TOKEN = args.sonarqube_token
PROJECT_KEY = args.project_key

# AWS SES Email Configuration
SENDER_EMAIL = args.sender_email
RECIPIENT_EMAIL = args.recipient_email
AWS_REGION = args.aws_region

# API Endpoints
QUALITY_GATES_API = f"{SONARQUBE_URL}/api/qualitygates/project_status?projectKey={PROJECT_KEY}"
ISSUES_API = f"{SONARQUBE_URL}/api/issues/search?componentKeys={PROJECT_KEY}&types=BUG,VULNERABILITY,CODE_SMELL"
SECURITY_HOTSPOTS_API = f"{SONARQUBE_URL}/api/hotspots/search?projectKey={PROJECT_KEY}"

# Function to fetch data from SonarQube API without pagination
def fetch_quality_gate_data(api_url):
    print(f"Fetching data from: {api_url}")
    response = requests.get(api_url, auth=(SONARQUBE_TOKEN, ''))
    print(f"Response Code: {response.status_code}")
    
    if response.status_code == 200:
        return response.json()
    else:
        print(f"Error fetching data: {response.status_code} - {response.text}")
        return None

# Function to fetch data from SonarQube API with pagination
def fetch_sonarqube_data(api_url):
    print(f"Fetching data from: {api_url}")
    page = 1
    page_size = 100
    all_data = []
    
    while True:
        paged_url = f"{api_url}&p={page}&ps={page_size}"
        response = requests.get(paged_url, auth=(SONARQUBE_TOKEN, ''))
        print(f"Response Code: {response.status_code} for page {page}")
        
        if response.status_code == 200:
            data = response.json()
            items = data.get("issues", []) or data.get("hotspots", [])
            all_data.extend(items)
            
            if len(items) < page_size:
                break  # No more pages left
            page += 1
        else:
            print(f"Error fetching data: {response.status_code} - {response.text}")
            break
    
    return all_data

# Fetch Quality Gate Status
print("Fetching Quality Gate status...")
quality_gates_data = fetch_quality_gate_data(QUALITY_GATES_API)

# Convert Quality Gate Data to DataFrame
if quality_gates_data:
    print("Processing Quality Gate data...")
    quality_gate_status = quality_gates_data.get("projectStatus", {})
    conditions = quality_gate_status.get("conditions", [])
    
    # Extract quality gate conditions into separate columns
    quality_gate_dict = {"Overall Status": quality_gate_status.get("status", "N/A")}
    for condition in conditions:
        metric = condition.get("metricKey", "Unknown")
        status = condition.get("status", "Unknown")
        quality_gate_dict[metric] = status
    
    quality_gate_df = pd.DataFrame([quality_gate_dict])
    print("Quality Gate data processed successfully.")
else:
    print("No Quality Gate data found.")
    quality_gate_df = pd.DataFrame()

# Check Quality Gate status
if quality_gates_data and quality_gates_data.get("projectStatus", {}).get("status") != "OK":
    
    print("Quality Gate failed. Fetching issues and security hotspots...")
    # Fetch Issues and Security Hotspots if Quality Gate fails
    issues_list = fetch_sonarqube_data(ISSUES_API)
    security_hotspots_list = fetch_sonarqube_data(SECURITY_HOTSPOTS_API)
    
    # Convert Issues Data to DataFrame
    issues_df = pd.DataFrame(issues_list)
    print(f"Fetched {len(issues_list)} issues.")
    
    # Convert Security Hotspots Data to DataFrame
    hotspots_df = pd.DataFrame(security_hotspots_list)
    print(f"Fetched {len(security_hotspots_list)} security hotspots.")
    
    # Save data to Excel file with project key as prefix
    report_file = f"{PROJECT_KEY}_quality_report.xlsx"
    print(f"Saving report to {report_file}...")
    with pd.ExcelWriter(report_file) as writer:
        quality_gate_df.to_excel(writer, sheet_name="Quality Gate", index=False)
        issues_df.to_excel(writer, sheet_name="Issues", index=False)
        hotspots_df.to_excel(writer, sheet_name="Security Hotspots", index=False)
    
    print(f"Quality gate report saved to {report_file}")

    # Send email with report as attachment
    def send_email_with_attachment():
        msg = MIMEMultipart()
        msg["From"] = SENDER_EMAIL
        msg["To"] = RECIPIENT_EMAIL
        msg["Subject"] = f"SonarQube Quality Gate Report - {PROJECT_KEY}"
        
        body = f"""Hello,

The SonarQube quality gate report for project '{PROJECT_KEY}' is attached.

Best Regards,
DevOps Team
"""
        msg.attach(MIMEText(body, "plain"))

        # Attach the report
        if os.path.exists(report_file):
            with open(report_file, "rb") as attachment:
                part = MIMEBase("application", "octet-stream")
                part.set_payload(attachment.read())
                encoders.encode_base64(part)
                part.add_header("Content-Disposition", f"attachment; filename={os.path.basename(report_file)}")
                msg.attach(part)

        # Send email using AWS SES
        ses_client = boto3.client("ses", region_name=AWS_REGION)
        try:
            response = ses_client.send_raw_email(
                Source=SENDER_EMAIL,
                Destinations=[RECIPIENT_EMAIL],
                RawMessage={"Data": msg.as_string()},
            )
            print("Email sent successfully! Message ID:", response["MessageId"])
        except Exception as e:
            print("Error sending email:", str(e))

    send_email_with_attachment()
    
    # Exit with non-zero status to indicate failure
    exit(1)

else:
    print("Quality Gate is OK. No issues found.")

print("Script execution completed.")

# Note: Column Names
# - Quality Gate Sheet: "Overall Status" and various metric keys indicating status
# - Issues Sheet: Contains details such as issue type (BUG, VULNERABILITY, CODE_SMELL), severity, component, message, etc.
# - Security Hotspots Sheet: Contains details about security risks, component affected, and review status
