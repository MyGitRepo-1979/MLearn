# 1. ModelOps - Template for DAPM (Dynamic and Parallel MLOps) framework

This repository implements ModelOps with DAPM (Dynamic and Parallel MLOps) framework

- [1. ModelOps - Template for DAPM (Dynamic and Parallel MLOps) framework](#1-modelops---template-for-dapm-dynamic-and-parallel-mlops-framework)
  - [1.1. Objective](#11-objective)
  - [1.2. Personas](#12-personas)
  - [1.3. Decision flow](#13-decision-flow)
  - [1.4. Naming Convention](#14-naming-convention)
  - [1.5. Prerequisites](#15-prerequisites)
    - [1.5.1. People](#151-people)
    - [1.5.2. AWS Accounts](#152-aws-accounts)
    - [1.5.3. Implementation of account bootstrapping (Owner: ITIP)](#153-implementation-of-account-bootstrapping-owner-itip)
    - [1.5.4. Source Control Access (Owner: Project manager)](#154-source-control-access-owner-project-manager)
    - [1.5.5. Build Tool Access](#155-build-tool-access)
  - [1.6. Getting Started](#16-getting-started)
    - [1.6.1. DataOps](#161-dataops)
    - [1.6.2. MLOps](#162-mlops)
  - [1.7. Use Cases On boarding](#17-use-cases-on-boarding)
    - [1.7.1. Prerequisite to run batch framework](#171-prerequisite-to-run-batch-framework)
    - [1.7.2. Workflow](#172-workflow)
    - [1.7.3. Branching Strategy](#173-branching-strategy)
      - [1.7.3.1. Promotion to Higher Environment](#1731-promotion-to-higher-environment)
      - [1.7.3.2. Steps to promote to uat env](#1732-steps-to-promote-to-uat-env)
    - [1.7.4. Prerequisite to run ETL data quality jobs](#174-prerequisite-to-run-etl-data-quality-jobs)
    - [1.7.5. Prerequisite to run feature store jobs](#175-prerequisite-to-run-feature-store-jobs)
    - [1.7.6. Prerequisite to run Dashboard data quality (data drift) jobs](#176-prerequisite-to-run-dashboard-data-quality-data-drift-jobs)
    - [1.7.7. Prerequisite to run Dashboard model quality jobs](#177-prerequisite-to-run-dashboard-model-quality-jobs)
  - [1.8. EAP shared core](#18-eap-shared-core)
  - [1.9. *Quicksight Dashboard:*](#19-quicksight-dashboard)
  - [1.10. Glossary and Refrence](#110-glossary-and-refrence)

## 1.1. Objective

The purpose of this document is to cover the people, process and technology aspects of ModelOps project. ModelOps project aims at standardizing the productionisation of Machine Learning use cases. This Runbook elaborates conventions, team structure, approach, decision flow, process and technology to help *Analytics* teams at Maruti Suzuki India limited (MSIL) to adopt MLOps for their ML use cases.

## 1.2. Personas

This section lists the Persona which are recommended for MLOps and their Roles and Responsiblities.
Typically, AWS ProServe recommends [AWS whitepaper Personas for an ML platform](https://docs.aws.amazon.com/whitepapers/latest/build-secure-enterprise-ml-platform/personas-for-an-ml-platform.html)

However, based on ModelOps engagement, AWS Proserve has modified the persons and listed the same below, in-principle the below persona aligns with AWS whitepaper Personas for an ML platform , just that, these are more aligned to MSIL Org Structure.

1. Project manager
    1. Identifying dependencies on external teams, planning dependency resolution.
2. Data/ML Architect
    1. Evaluate business requirement, brainstorm the same with Team, Pro-Con analysis , Architecture Decisions.
    2. Design MLOps solutions
3. Infra Architect
    1. Evaluate Infrastructure requirements and design Account Structure
    2. Design Infrastructure components : VPC, Subnets, IAM Roles etc.
4. DevOps Architect
    1. Evaluate DevOps requirements and design DevOps solution
    2. Design Source control Repository structure
    3. Design resource naming convention
    4. Design Integration across Infrastructure-as-code, Source Control , Build Pipeline and Deploy Pipeline
    5. Design constructs or IaC modules to modularization reusable IaC modules
5. Data Scientist
    1. Define Preprocessing, Training, Evaluation, Inferencing, Monitoring Logic
6. ML Engineer
    1. Build components to automate ML Training, Model Approval, Model Deployment , Model Monitoring
7. Data Engineer
    1. Build Data ingestion and processing workflows for ML Input
    2. Build Data Quality and Model Quality Modules
    3. Build Dashboards to monitor ML Model and Data Quality
8. DevOps Engineer
    1. Build IaC for resources , build Jenkins config for Build and Deploy pipelines

## 1.3. Decision flow

![MSIL MLOps Architecture-Decision Flow.drawio.png](docs/images/MSIL-MLOps-Architecture-Decision-Flow.drawio.png)

## 1.4. Naming Convention

This section specifies the naming convention for AWS Accounts, AWS Resources, Git Repositories. Naming convention are important to maintain naming uniformity and easy identification and relate-ability with Objects.

Name of use case repository and Jenkins project folder should be same and follow convention:

`<business-unit>-<use-case-name>`

Name of AWS Resources follow below convention

`<use-case-name>-<env>-<region>-<functionality>`

**Note:**
Below are the pre-defiend values for each qualifier

1. `<business-unit>`
    1. qa - Quality
    2. paccl - Parts
    3. mns - Marketing and Sales
2. `<use-case-names>`
    1. dcp - Defect correlation and prediction
    2. tv - True Value
    3. wcf - Warranty and Claims Forecast
    4. sprs - spare parts
3. `<region>`
    1. apsouth1 - AWS Mumbai region
4. `<env>`
    1. dev
    2. uat
    3. prod
5. `<functionality>` This can be a multi word separated by hyphen to describe the funcitonality of the resource example : ‘approval-event’ , ‘model-quality’ etc

For onboarding new use cases or new business units, PMs will have to define their values in above format to use for resource names.

## 1.5. Prerequisites

### 1.5.1. People

For every ML use case, setup an ML team as per section *People*.

Below are pre-defined teams , TBC : Teams for DCP

1. DCP, SPRS , WCF and TV

|Role |Member |
|--- |--- |
|PM |Ankit |
|Data/ML Architect |TBC |
|Infra Devops Architect |Ramakrishna |
|Data Engineer |Mahendra |
|Data Scientist/MLE |Sandeep |

### 1.5.2. AWS Accounts

1. Project manager would ensure if the ML use case belongs to a Business Unit (BU) which is already onboarded to ModelOps then reuse the existing accounts.
2. INFO : Account of a BU can be identified by AWS Account Name prefix,
    1. QA – Quality
    2. PCCAL - `<to be filled by MSIL>`
    3. If the ML use case belongs to a BU which has not been on-boarded to ModelOps then Project Manager should request the ITIP team to create AWS Accounts.
3. Project Manager is responsible to co-ordinate with ITIP team to create AWS Accounts for the BU.
4. INFO: Each ML use case requires 4 AWS Accounts
    1. 3 use case specific account, to be created once for each BU
        1. Dev
        2. UAT
        3. Prod
    2. 3 Monitoring Accounts to be created once for ModelOps.
        1. Dev
        2. UAT
        3. Prod
5. INFO: ML Teams will require below types of access to AWS Account:
    1. Dev Account console access for ML Dev Team
    2. UAT Account console access for ML UAT Team
    3. Prod Account console access for ML Prod Team
6. Project Manager should coordinate with ITIP team to create below Infra resources (This step is done with the help of provided terraform automation explained subsequently )

               a. Connected VPC with x.x.x.x/22 CIDR range, Subnets and Route tables.
                   There would be 3 Public subnet, 3 Private Subnets and 2 Route Tables, 1 for Private subnet (in which s3 and dynamoDB VPC endpoint would be attached) and 1 for public subnets.  VPC configuration is as follows.

|Subnet Address |Public/Private |Availability Zone |Hosts |
|--- |--- |--- |--- |
|x.x.x.x/24 |Private |ap-south-1a |254 |
|x.x.x.x/24 |Private |ap-south-1b |254 |
|x.x.x.x/24 |Private |ap-south-1c |254 |
|x.x.x.x/26 |Public |ap-south-1a |62 |
|x.x.x.x/26 |Pubic |ap-south-1b |62 |
|x.x.x.x/26 |Public |ap-south-1c |62 |

            b.  Jenkins Automation Role.

                 Project Manager should coordinate with ITIP team to create Role for all the MLOPS accounts to have Jenkins-Assume-Role-ProServe-CrossAccount-Role. The role should have the following two policies.

1. **general-policy**: This policy is permanently applied to Jenkins and used for code-sync
2. **elevated-infra-privileges-policy**: This policy is attached on need basis by ITIP team to run infra pipeline.

Workflow is defined in section 3.6.

|Policy Name |Service |APIs |
|--- |--- |--- |
|general-policy | | |
|--- |--- |--- |
| |ec2 |DescribeSecurityGroups, DescribeSubnets, DescribeVpcs |
| |batch |all |
| |s3 |all |
| |[*states*](file:///Applications/Quip.app/Contents/Resources/Web/states) |all |
| |ssm |all |
| |ecr |all |
| |secretsmanager |all |
| |kms |ListAliases, Get* |
| |sts |AssumeRole |
| |logs |all |
| |sagemaker |all |
| |*dynamodb* |all |
| |autoscaling |all |
| |*quicksight* |all |
| |events |all |
| |codeartifact |all |
| |*apigateway* |all |
| |lambda |all |
| |cloudwatch |all |
| |ecs |all |
| |athena |all |
| |glue |all |
| |lambda |all |
| |*sns* |all |
| |resource-groups |all |
|elevated-infra-privileges-policy | | |
| |ec2 |all |
| |iam |*CreateAccountAlias**,* *ListPolicies**,* *ListRoles**,* *CreatePolicy**,* *CreatePolicyVersion**,* *DeletePolicy**,* *DeletePolicyVersion**,* *TagPolicy**,* *TagRole**,* *CreateRole**,* *AddRoleToInstanceProfile**,* *CreateInstanceProfile**,* *CreateServiceLinkedRole**,* *DeleteRole**,* *PassRole**,* *UpdateRole**,* *RemoveRoleFromInstanceProfile**,* *GetRole**,* *GetPolicy**,* *GetPolicyVersion**,* *GetRolePolicy**,* *GetInstanceProfile**,* *ListRoles**,* *ListInstanceProfiles**,* *ListIntanceProfilesForRole**,* *ListAttachedRolePolicies**,* *ListRolePolicies* |
| |cloudtrail |*all* |
| |kms |*all* |

The role most have trust relationship with Jenkins EC2 Roles. (Owned by ITIP Team)

"arn:aws:iam::594180354821:role/EC2JenkinsSlave-AssumeRole"
"arn:aws:iam::594180354821:role/JenkinsCrossAccountRole"

EC2JenkinsSlave-AssumeRole must allow Jenkins-AssumeRole-ProServe-CrossAccount-Role to assume itself. (Owned by DevOps tool team – Nagaro)

### 1.5.3. Implementation of account bootstrapping (Owner: ITIP)

Account level prerequisites (VPC and Jenkins Role)  defined above are deployed with the help of terraform code available in below repository.

[terraform-awsproserve-modelops-account-bootstrap](https://github.com/MSIL-Analytics-ACE/terraform-awsproserve-modelops-account-bootstrap/tree/main)

Please refer to example [here](https://github.com/MSIL-Analytics-ACE/terraform-awsproserve-modelops-account-bootstrap/blob/main/examples/basic)

1. Set provider config

  ```hcl

      provider "aws" {
          region = var.region

          default_tags {
              tags = {
                  environment  = var.env
                  deployed_by  = "TFProviders"
                  developed_by = "AWSProserve"
                  project      = var.use_case_name
              }
          }
      }

      terraform {
          required_version = ">= 0.15, < 2.0.0"
          required_providers {
              aws = {
                  source  = "hashicorp/aws"
                  version = ">= 4.61.0"
              }
              awscc = {
                  source  = "hashicorp/awscc"
                  version = ">= 0.49.0"
              }
          }

          backend "s3" {
              region         = "ap-south-1"
              bucket         = "commong-s3-bucket-name"
              dynamodb_table = "locking-ddb-name"
              encrypt        = true
              kms_key_id     = "kms_key_arn"
              role_arn       = "terraform-access-role-arn"
          }
      }
  ```

1. Set terraform.tfvars file for the every environment of usecase. Check example above.
2. Ensure you environment is pointing to appropriate account. You can also leverage `assume_role` feature in terraform if you want to maintain Centralised terraform deployments
3. Run `terraform init`
4. Run `terraform plan` & review the resources.
5. Create resources in account by running `terraform apply`

### 1.5.4. Source Control Access (Owner: Project manager)

1. GitHub has been identified as the official source control tool for MSIL ModelOps.
2. Project Manager should create a team for every project.
3. Project Manager should add project members to there respective team for MSIL GitHub Organization [*https://github.com/MSIL-Analytics-ACE*](https://github.com/MSIL-Analytics-ACE) to create git repositories and accessing templates for project.

### 1.5.5. Build Tool Access

1. Jenkins has been identified as the official build tool for MSIL ModelOps.
2. Project Manager should coordinate with Jenkins platform team for access to ML Team, to create project folder under Jenkins root folder [*https://jenkins.msildevopsportal.co.in/job/MSIL_Analytics_ACE*](https://jenkins.msildevopsportal.co.in/job/MSIL_Analytics_ACE).
3. DevOps Engineer should ensure Jenkins has Jenkins-AssumeRole-ProServe-CrossAccount-Role.
4. Project Manager should request  DevOps engineer to create project folder under Jenkins root folder.

           [MSIL_Analytics_ACE](https://jenkins.msildevopsportal.co.in/job/MSIL_Analytics_ACE).

DevOps Engineer is responsible to create sonarqube project and to create a sonar-project.properties files which will be kept in root of the project GitHub Repository. Update `<project-name>` to name of Github Repository.

INFO: Path for Sonar property template : `https://github.com/MSIL-Analytics-ACE/template-bu-use-case-dapm-framework/blob/main/sonar-project.properties`

![Image: image.png](docs/images/sonar1.png)
![Image: image.png](docs/images/sonar2.png)

INFO:  At this points , followings things are done :

1. AWS Accounts has been created
2. Infrastructure components like VPC , Subnet etc are available
3. Git Repos access are provisioned
4. Jenkins Access is provisioned and Jenkins configured

## 1.6. Getting Started

INFO: Folders inside the DAPM template Repo

1. infra: It contains the terraform code which creates whole infrastructures including all the resources required for use cases.
2. Common: Its module folder inside infra, it contains terraform code for common resources which common for entire use case.
3. jenkins: It contains CICD code for jenkins jobs, jenkins pipeline (to deploy infra) and scripts
4. env: It contains variable files as per the environments, dev, uat and production.

Project manager should request access for entire team to ITIP for below git repositories.

    1. [template-bu-use-case-dapm-framework](https://github.com/MSIL-Analytics-ACE/template-bu-use-case-dapm-framework)
    2. [terraform-awsproserv-dapm-framework](https://github.com/MSIL-Analytics-ACE/terraform-awsproserv-dapm-framework)
    3. [terraform-common-modules](https://github.com/MSIL-Analytics-ACE/terraform-common-modules)

1. Project Manager should create github repo `<business-unit>-<use-case-name>` in [*https://github.com/MSIL-Analytics-ACE*](https://github.com/MSIL-Analytics-ACE)  by forking [*https://github.com/MSIL-Analytics-ACE/template-bu-use-case-dapm-framework*](https://github.com/MSIL-Analytics-ACE/template-bu-use-case-dapm-framework)
2. Project Manager should provide access to DevOps Engineer and ML team on newly created repo.
3. DevOps Engineer should follow instructions in readme.md to setup up source code in newly created use-case repository. readme.md file is available in the root of repository – refer screenshot below.
4. DevOps Engineer should configure Jenkins seed job in newly created use-case project folder. The seed job should point to Jenkins/jobs folder of use-case github repo.
5. Once done, hit *Build Now*
6. This will create three new pipelines
    1. terraform-infra-deploy
    2. aws-code-sync
    3. modelops-model-step-function-orchestration
7. Project team should run pipelines **in order, as specified below:**
    1. terraform-infra-deploy
    2. aws-code-sync
    3. modelops-model-step-function-orchestration

### 1.6.1. DataOps

Refer to [analytics-etl](analytics-etl/README.md)

### 1.6.2. MLOps

Refer to [model](model/README.md)

## 1.7. Use Cases On boarding

Follow the steps to onboard all the above usecases

### 1.7.1. Prerequisite to run batch framework

- ETL Athena DB (dq_table) and S3 bucket.
- Sample data path in [training_job/preprocessing](https://github.com/MSIL-Analytics-ACE/quality-dcp/blob/main/model/training_job/preprocessing/preprocessing.py)

### 1.7.2. Workflow

- Update environment json file. ex: [env/dev.tfvars.json](https://github.com/MSIL-Analytics-ACE/quality-dcp/blob/main/env/dev.tfvars.json). All folder paths must be relative from root of repository.
- Configure seed job in jenkins. Follow above steps in getting started section no 4.
- Deploy infra from [infra/terraform](https://github.com/MSIL-Analytics-ACE/quality-dcp/blob/main/infra) using Jenkins `terraform-infra-deploy pipeline`.
- Sync model code with ECR and Glue job by running `aws-model-code-sync pipeline`.
- Trigger training step-function by running `ModelOps-model-training pipeline`.
- Approve model from sagemaker studio to execute inference. Alternatively inference will also run on scheduled basis.

### 1.7.3. Branching Strategy

- `main` brach represents development environment for trunk based development.
- promote code to `production` branch ← `UAT` branch ← `main` branch. Use `PR` to promote code

#### 1.7.3.1. Promotion to Higher Environment

Branching strategy to promote to higher environment. DevOps engineer will create 3 branch to create infra for environments

- main: main branch is for Dev env.
- uat: uat branch is for UAT
- production: production is for Production

Note: At this point dev is deployed and tested.

#### 1.7.3.2. Steps to promote to uat env

1. Create a branch uat from main
2. Create a environment folder inside env folder similar to dev
3. Update the dev.tfvars.json to uat.tfvars.json
4. Now update the uat.tfvars.json according to uat parameters for example “env“, ”account_number“, vpc details along with subnet_ids if applicable, bucket arns etc.
5. Devops Engineer will go to jenkins server and go to inside the aws-code-sync folder
6. DevOps engineer will scan repository for usecase inside the aws-code-sync folder. After hitting **Scan Repository Now** button on left hand side, this job will scan newly created branch **uat** and create CICD pipeline for uat deployment. Logs can be seen in **Scan Repository Log.**
7. Infra deployment pipeline would be created automatically in terraform-infra-deploy folder.
8. DevOps engineer would go inside the uat and deploy the infra for env.

For promotion to Production environment, create **production** branch and  follow all the above steps in similar pattern.

### 1.7.4. Prerequisite to run ETL data quality jobs

- ETL Athena DB (dq_table)- `<usecase>_data_quality`
- Paramter should be created in parameter store - `/<usecasename>/<env>/workflow_name/expected_dq_job_cnt`
- Parameter to be updated in parameter store to specify the number of data quality jobs - `/<usecasename>/<env>/workflow_name/expected_dq_job_cnt`
- ETL glue jobs should have access to view parameter in paramter store

### 1.7.5. Prerequisite to run feature store jobs

- Feature store bucket in EAP account
- Feature group role needs to be defined in EAP account

### 1.7.6. Prerequisite to run Dashboard data quality (data drift) jobs

- S3 bucket with cross account bucket access and Glue database should already be created in the EAP account

### 1.7.7. Prerequisite to run Dashboard model quality jobs

- S3 bucket with cross account bucket access and Glue database should already be created in the EAP account.

## 1.8. EAP shared core

Steps to added new roles for EAP cross bucket and feature store
Update the configuration

1. Create a feature branch from `main`
2. Update configuration on the basis of environment. Ex, `Dev → env/dev/dev.tfvars.json`, `Production → env/prod/prod.tfvars.json`. ( Remember all changes are checked in main from feature. For higher environment, promotion process needs to followed)
3. To provide access to role to common bucket update below config and add details in key value format (“account-number”: [list of IAM role names] ).

```
"cross_account_bucket_access_roles": {
    "645520530156": [
      "dcpd-dapm-apsouth1-dapf-monitoring-glue-job-role",
      "dcpd-dapm-apsouth1-dapf-training-glue-job-role",
      "dcpd-dapm-apsouth1-dapf-inferencing-glue-job-role",
      "dcpd-dapm-apsouth1-dapf-analytics-etl-glue-job-role"
    ],
    "905252802426": [
      "aws-glue-dq-role",
      "tv-dev-apsouth1-ref-monitoring-glue-job-role"
    ],
    "656820547032": [
      "sprs-dev-apsouth1-dapf-monitoring-glue-job-role",
      "sprs-dev-apsouth1-dapf-training-glue-job-role",
      "sprs-dev-apsouth1-dapf-inferencing-glue-job-role",
      "sprs-dev-apsouth1-dapf-analytics-etl-glue-job-role"
    ],
    "316770570250": [
      "wcf-dev-apsouth1-dapf-monitoring-glue-job-role",
      "wcf-dev-apsouth1-dapf-training-glue-job-role",
      "wcf-dev-apsouth1-dapf-inferencing-glue-job-role",
      "wcf-dev-apsouth1-dapf-analytics-etl-glue-job-role"
    ]
  },
```

1. After committing changes in repo, raise a PR.
2. Centralized DevOps team will approve the PR after review and trigger Jenkins pipeline for appropriate environment.

 URL of pipeline <https://jenkins.msildevopsportal.co.in/job/MSIL_Analytics_ACE/job/eap-shared-core/job/terraform-infra-deploy/job/main/>

**Testing :**

- Data Engineer to schedule Glue ETL workflows
- ML Engineer to execute traning
- ML Engineer to approve Model
- ML Engineer to execute/ schedule infrencing
- BI Engineer to validate Data quality and Model quality

## 1.9. *Quicksight Dashboard:*

- **Raise a Request to Open a QuickSight Account**:

If you don't already have access to Amazon QuickSight, you need to request an account from your AWS administrator or account manager.
Submit a request to open a QuickSight account by providing necessary details such as your AWS account information, region preference, and any specific requirements.

- **AWS Account Access**:

Ensure that you have an active AWS account. If not, sign up for an AWS account.

- **Permissions and IAM Role**:

Verify that you have the necessary permissions to create an Amazon QuickSight account. This often involves having the quicksight:CreateAccount permission.
Ensure that an Identity and Access Management (IAM) role exists with the required QuickSight permissions. If not, create an IAM role and attach the necessary policies.

- **Setup QuickSight Account:**

Log in to the AWS Management Console using your AWS credentials.
Navigate to the Amazon QuickSight console.
Follow the on-screen instructions to sign up for QuickSight.
Provide the required information, including your email address, region preference, and any other details.

- **QuickSight Subscription**:

Select the subscription type. QuickSight offers a Standard and an Enterprise edition. Choose the one that aligns with your needs.

- **Configure QuickSight Permissions**:

Define permissions for QuickSight users by assigning them roles and specifying their level of access.
Set up permissions for accessing data sources, creating analyses, and creating dashboards.

 QuickSight Signup : <https://docs.aws.amazon.com/quicksight/latest/user/signing-up.html>

## 1.10. Glossary and Refrence

Please find the links for services used in usecases
Stepfunction: <https://aws.amazon.com/step-functions/>
Sagemaker: <https://aws.amazon.com/pm/sagemaker/>
Glue: <https://docs.aws.amazon.com/glue/latest/dg/what-is-glue.html>
Workflow: <https://docs.aws.amazon.com/glue/latest/dg/workflows_overview.html>
Batch: <https://aws.amazon.com/batch/>
VPC: <https://docs.aws.amazon.com/vpc/latest/userguide/what-is-amazon-vpc.html>
